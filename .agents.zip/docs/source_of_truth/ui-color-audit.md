# SAMBUNG — Audit Warna UI v0.2

Dihitung dari [manifest token](assets/sambung-tokens.json) dengan skrip [build_ui_tokens.py](../plan/build_ui_tokens.py). CSS OKLCH pada [sambung-theme.css](assets/sambung-theme.css) dibangun dari sumber yang sama.

Hasil: **106/106 pasangan wajib memenuhi ambang**. Perbandingan memakai nilai penuh sebelum pembulatan angka laporan. Token OKLCH netral Jagains dipertahankan persis; warna bersumber HEX dikonversi ke OKLCH dan kembali ke kode sRGB 8-bit yang sama.

## Metode dan batas

sRGB diubah menjadi linear (ambang0,04045); luminans memakai bobot0,2126/0,7152/0,0722. Rasio=(luminans terang+0,05)/(luminans gelap+0,05). Ambang teks normal4,5:1 dan fokus3:1 mengikuti keputusan proyek; kontrol/grafik3:1 juga diperiksa untuk pasangan yang tercantum. Rumus mengacu pada [teknik G18 W3C](https://www.w3.org/WAI/WCAG21/Techniques/general/G18).

Audit ini memverifikasi pasangan token solid yang ditentukan, bukan seluruh kombinasi warna, komponen browser, gambar, keadaan disabled, warna semi-transparan, blending peta, render font atau kepatuhan aplikasi secara menyeluruh. Border dekoratif tidak dipakai sebagai batas kontrol. Fokus diberi offset sehingga berbatasan dengan permukaan, bukan isi tombol. Token border gelap beralpha diwarisi dari Jagains dan hanya dekoratif; tidak dimasukkan sebagai pasangan solid. Teks muted pada canvas/muted/secondary/accent tidak disahkan: gunakan foreground. Jika latar/opacity/state diubah, hitung ulang pasangan aktual. CSS belum dikompilasi dalam aplikasi.

## Pasangan yang diperiksa

| Mode | Foreground/garis | Latar | Minimum | Rasio | Hasil |
|---|---|---|---:|---:|---|
| light | `foreground` | `background` | 4.5:1 | 19.79:1 | Lulus |
| light | `card-foreground` | `card` | 4.5:1 | 19.79:1 | Lulus |
| light | `popover-foreground` | `popover` | 4.5:1 | 19.79:1 | Lulus |
| light | `primary-foreground` | `primary` | 4.5:1 | 7.70:1 | Lulus |
| light | `primary-foreground` | `primary-hover` | 4.5:1 | 9.88:1 | Lulus |
| light | `secondary-foreground` | `secondary` | 4.5:1 | 16.11:1 | Lulus |
| light | `accent-foreground` | `accent` | 4.5:1 | 16.42:1 | Lulus |
| light | `highlight-foreground` | `highlight` | 4.5:1 | 14.06:1 | Lulus |
| light | `destructive-foreground` | `destructive` | 4.5:1 | 7.16:1 | Lulus |
| light | `destructive` | `destructive-surface` | 4.5:1 | 5.91:1 | Lulus |
| light | `price-within` | `price-within-surface` | 4.5:1 | 6.11:1 | Lulus |
| light | `price-caution` | `price-caution-surface` | 4.5:1 | 6.31:1 | Lulus |
| light | `price-low` | `price-low-surface` | 4.5:1 | 5.91:1 | Lulus |
| light | `review` | `review-surface` | 4.5:1 | 6.53:1 | Lulus |
| light | `input` | `background` | 3.0:1 | 4.29:1 | Lulus |
| light | `ring` | `background` | 3.0:1 | 7.70:1 | Lulus |
| light | `foreground` | `card` | 4.5:1 | 19.79:1 | Lulus |
| light | `input` | `card` | 3.0:1 | 4.29:1 | Lulus |
| light | `ring` | `card` | 3.0:1 | 7.70:1 | Lulus |
| light | `foreground` | `popover` | 4.5:1 | 19.79:1 | Lulus |
| light | `input` | `popover` | 3.0:1 | 4.29:1 | Lulus |
| light | `ring` | `popover` | 3.0:1 | 7.70:1 | Lulus |
| light | `foreground` | `muted` | 4.5:1 | 18.15:1 | Lulus |
| light | `input` | `muted` | 3.0:1 | 3.94:1 | Lulus |
| light | `ring` | `muted` | 3.0:1 | 7.06:1 | Lulus |
| light | `foreground` | `secondary` | 4.5:1 | 17.99:1 | Lulus |
| light | `input` | `secondary` | 3.0:1 | 3.90:1 | Lulus |
| light | `ring` | `secondary` | 3.0:1 | 6.99:1 | Lulus |
| light | `foreground` | `accent` | 4.5:1 | 18.15:1 | Lulus |
| light | `input` | `accent` | 3.0:1 | 3.94:1 | Lulus |
| light | `ring` | `accent` | 3.0:1 | 7.06:1 | Lulus |
| light | `muted-foreground` | `background` | 4.5:1 | 4.73:1 | Lulus |
| light | `muted-foreground` | `card` | 4.5:1 | 4.73:1 | Lulus |
| light | `muted-foreground` | `popover` | 4.5:1 | 4.73:1 | Lulus |
| light | `sidebar-foreground` | `sidebar` | 4.5:1 | 18.96:1 | Lulus |
| light | `sidebar-accent-foreground` | `sidebar-accent` | 4.5:1 | 6.68:1 | Lulus |
| light | `input` | `sidebar` | 3.0:1 | 4.11:1 | Lulus |
| light | `ring` | `sidebar` | 3.0:1 | 7.37:1 | Lulus |
| light | `chart-1` | `background` | 3.0:1 | 7.70:1 | Lulus |
| light | `chart-1` | `card` | 3.0:1 | 7.70:1 | Lulus |
| light | `chart-1` | `popover` | 3.0:1 | 7.70:1 | Lulus |
| light | `chart-2` | `background` | 3.0:1 | 10.37:1 | Lulus |
| light | `chart-2` | `card` | 3.0:1 | 10.37:1 | Lulus |
| light | `chart-2` | `popover` | 3.0:1 | 10.37:1 | Lulus |
| light | `chart-3` | `background` | 3.0:1 | 5.57:1 | Lulus |
| light | `chart-3` | `card` | 3.0:1 | 5.57:1 | Lulus |
| light | `chart-3` | `popover` | 3.0:1 | 5.57:1 | Lulus |
| light | `chart-4` | `background` | 3.0:1 | 7.81:1 | Lulus |
| light | `chart-4` | `card` | 3.0:1 | 7.81:1 | Lulus |
| light | `chart-4` | `popover` | 3.0:1 | 7.81:1 | Lulus |
| light | `chart-5` | `background` | 3.0:1 | 4.74:1 | Lulus |
| light | `chart-5` | `card` | 3.0:1 | 4.74:1 | Lulus |
| light | `chart-5` | `popover` | 3.0:1 | 4.74:1 | Lulus |
| dark | `foreground` | `background` | 4.5:1 | 18.96:1 | Lulus |
| dark | `card-foreground` | `card` | 4.5:1 | 17.16:1 | Lulus |
| dark | `popover-foreground` | `popover` | 4.5:1 | 17.16:1 | Lulus |
| dark | `primary-foreground` | `primary` | 4.5:1 | 12.04:1 | Lulus |
| dark | `primary-foreground` | `primary-hover` | 4.5:1 | 13.73:1 | Lulus |
| dark | `secondary-foreground` | `secondary` | 4.5:1 | 14.26:1 | Lulus |
| dark | `accent-foreground` | `accent` | 4.5:1 | 14.48:1 | Lulus |
| dark | `highlight-foreground` | `highlight` | 4.5:1 | 14.06:1 | Lulus |
| dark | `destructive-foreground` | `destructive` | 4.5:1 | 8.44:1 | Lulus |
| dark | `destructive` | `destructive-surface` | 4.5:1 | 7.08:1 | Lulus |
| dark | `price-within` | `price-within-surface` | 4.5:1 | 7.24:1 | Lulus |
| dark | `price-caution` | `price-caution-surface` | 4.5:1 | 8.14:1 | Lulus |
| dark | `price-low` | `price-low-surface` | 4.5:1 | 8.20:1 | Lulus |
| dark | `review` | `review-surface` | 4.5:1 | 7.71:1 | Lulus |
| dark | `input` | `background` | 3.0:1 | 5.89:1 | Lulus |
| dark | `ring` | `background` | 3.0:1 | 12.04:1 | Lulus |
| dark | `foreground` | `card` | 4.5:1 | 17.16:1 | Lulus |
| dark | `input` | `card` | 3.0:1 | 5.33:1 | Lulus |
| dark | `ring` | `card` | 3.0:1 | 10.90:1 | Lulus |
| dark | `foreground` | `popover` | 4.5:1 | 17.16:1 | Lulus |
| dark | `input` | `popover` | 3.0:1 | 5.33:1 | Lulus |
| dark | `ring` | `popover` | 3.0:1 | 10.90:1 | Lulus |
| dark | `foreground` | `muted` | 4.5:1 | 14.48:1 | Lulus |
| dark | `input` | `muted` | 3.0:1 | 4.50:1 | Lulus |
| dark | `ring` | `muted` | 3.0:1 | 9.20:1 | Lulus |
| dark | `foreground` | `secondary` | 4.5:1 | 14.26:1 | Lulus |
| dark | `input` | `secondary` | 3.0:1 | 4.43:1 | Lulus |
| dark | `ring` | `secondary` | 3.0:1 | 9.06:1 | Lulus |
| dark | `foreground` | `accent` | 4.5:1 | 14.48:1 | Lulus |
| dark | `input` | `accent` | 3.0:1 | 4.50:1 | Lulus |
| dark | `ring` | `accent` | 3.0:1 | 9.20:1 | Lulus |
| dark | `muted-foreground` | `background` | 4.5:1 | 7.63:1 | Lulus |
| dark | `muted-foreground` | `card` | 4.5:1 | 6.91:1 | Lulus |
| dark | `muted-foreground` | `popover` | 4.5:1 | 6.91:1 | Lulus |
| dark | `sidebar-foreground` | `sidebar` | 4.5:1 | 17.16:1 | Lulus |
| dark | `sidebar-accent-foreground` | `sidebar-accent` | 4.5:1 | 7.53:1 | Lulus |
| dark | `input` | `sidebar` | 3.0:1 | 5.33:1 | Lulus |
| dark | `ring` | `sidebar` | 3.0:1 | 10.90:1 | Lulus |
| dark | `chart-1` | `background` | 3.0:1 | 12.04:1 | Lulus |
| dark | `chart-1` | `card` | 3.0:1 | 10.90:1 | Lulus |
| dark | `chart-1` | `popover` | 3.0:1 | 10.90:1 | Lulus |
| dark | `chart-2` | `background` | 3.0:1 | 18.96:1 | Lulus |
| dark | `chart-2` | `card` | 3.0:1 | 17.16:1 | Lulus |
| dark | `chart-2` | `popover` | 3.0:1 | 17.16:1 | Lulus |
| dark | `chart-3` | `background` | 3.0:1 | 9.55:1 | Lulus |
| dark | `chart-3` | `card` | 3.0:1 | 8.64:1 | Lulus |
| dark | `chart-3` | `popover` | 3.0:1 | 8.64:1 | Lulus |
| dark | `chart-4` | `background` | 3.0:1 | 13.35:1 | Lulus |
| dark | `chart-4` | `card` | 3.0:1 | 12.09:1 | Lulus |
| dark | `chart-4` | `popover` | 3.0:1 | 12.09:1 | Lulus |
| dark | `chart-5` | `background` | 3.0:1 | 7.85:1 | Lulus |
| dark | `chart-5` | `card` | 3.0:1 | 7.10:1 | Lulus |
| dark | `chart-5` | `popover` | 3.0:1 | 7.10:1 | Lulus |

## Pembatasan warna palet mentah

Pasangan berikut sengaja dicatat sebagai pembatas penggunaan, bukan pasangan teks yang disahkan:

| Warna pada Warm Cream | Rasio | Keputusan |
|---|---:|---|
| `olive` | 2.82:1 | Bukan teks normal kecil; gunakan foreground/varian semantik yang diuji |
| `sunflower` | 1.28:1 | Bukan teks normal kecil; gunakan foreground/varian semantik yang diuji |
| `honey` | 1.84:1 | Bukan teks normal kecil; gunakan foreground/varian semantik yang diuji |
| `terracotta` | 3.39:1 | Bukan teks normal kecil; gunakan foreground/varian semantik yang diuji |
