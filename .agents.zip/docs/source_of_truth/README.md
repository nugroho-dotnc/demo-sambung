# SAMBUNG — Source of Truth

Paket dokumentasi kebutuhan, struktur aplikasi dan aturan UI untuk MVP final lomba. Versi paket saat ini **0.4, revisi visual fase 3 untuk review**, 6 November 2026.

| Dokumen | Fungsi | Status |
|---|---|---|
| [Ringkasan fase 1](phase-1-summary.md) | Keputusan inti pengguna | Disetujui; fase 1 ditutup |
| [Catatan keputusan](decision-log.md) | Bukti 49 keputusan fase 1, 24 fase 2 dan revisi visual DEC-021a | Acuan keputusan; rincian belum dipilih tetap ditandai |
| [Laporan verifikasi](verification-report.md) | 33 temuan pada sumber awal, koreksi dan tindak lanjut | Audit selesai; bukan hasil pengujian aplikasi |
| [SRS](SRS_SAMBUNG.md) | Kebutuhan, aturan bisnis, data, NFR dan penerimaan | v0.2, disetujui sebagai dasar fase 3 |
| [Information Architecture](IA_SAMBUNG.md) | Sitemap, halaman, izin dan alur | v0.2, disetujui sebagai dasar fase 3 |
| [Ringkasan klarifikasi fase 2](phase-2-summary.md) | 24 keputusan tambahan, termasuk fitur di luar lingkup | v0.2 disetujui; fase 2 ditutup |
| [Glosarium](GLOSSARY.md) | Istilah domain bersama | Pendukung SRS/IA v0.2 |
| [Matriks ketertelusuran](traceability-matrix.md) | Sumber/keputusan → kebutuhan → halaman → penerimaan | v0.4; lengkap hingga UI-001…024 |
| [UI Guidelines](UI_GUIDELINES_SAMBUNG.md) | Delapan bagian, token, tipografi, layout, komponen dan keadaan UI | v0.2 untuk review; belum disetujui |
| [Audit warna](ui-color-audit.md) | 106 pasangan token solid dan batas pembuktiannya | 106/106 memenuhi ambang masing-masing |
| [Manifest token](assets/sambung-tokens.json) dan [kontrak CSS](assets/sambung-theme.css) | Nilai canonical dan pemetaan Tailwind v4 | Kontrak integrasi; belum dikompilasi dalam aplikasi |
| [Ringkasan fase 3](phase-3-summary.md) | Verifikasi paket dan batas bukti | Untuk review pengguna |

[UI Guidelines v0.2](UI_GUIDELINES_SAMBUNG.md) telah direvisi mengikuti [enam mockup](UI_GUIDELINES_SAMBUNG.md#14-referensi-mockup-dan-batas-adaptasinya) dan DEC-021a, untuk review fase 3. Formatnya mengikuti [contoh referensi](../ui_reference/contoh-ui-guidelines.md), dengan [palet pilihan pengguna](../ui_reference/sambung-color-reference.png). Identitas yang dipilih: layanan pertanian modern, base netral Jagains dan primary Forest Green; kuning/emas/olive/terracotta/cream sebagai aksen atau status, Plus Jakarta Sans dan Atkinson Hyperlegible Next, mode terang/gelap, shadcn/ui dan Tailwind CSS v4.



## Cara memakai paket

1. Baca ringkasan dan glosarium untuk memahami keputusan serta istilah.
2. Gunakan SRS sebagai acuan perilaku; periksa `OPN-*` sebelum mengimplementasikan bagian yang belum dipilih/tervalidasi.
3. Gunakan IA untuk menempatkan kebutuhan dalam halaman dan alur. Alias halaman bukan duplikasi objek atau data.
4. Gunakan UI Guidelines untuk penyajian; ubah nilai warna pada manifest lalu jalankan `python docs/plan/build_ui_tokens.py`. Periksa kembali pasangan yang berubah dan konteks komponen saat implementasi.
5. Telusuri setiap perubahan melalui matriks. Perubahan perilaku pada SRS harus diperiksa dampaknya ke IA, kriteria penerimaan dan UI Guidelines.

Default pada dokumen `docs/created/` adalah sumber historis dan tidak mengalahkan keputusan pengguna. Proposal tetap menjadi sumber komitmen yang belum diubah keputusan. Persetujuan fase 1 tidak menyatakan semua usulan rincian v0.1 telah disetujui. Target model/SUS bukan hasil yang sudah tercapai; prototipe React/Vite kini tersedia, tetapi kesesuaiannya dengan revisi panduan ini, dataset dan bukti uji tidak diaudit pada pekerjaan dokumentasi ini.

## Review dan penutupan fase 2

Pengguna telah memilih “Sesuai sebagai draf — lanjut membahas poin terbuka” untuk SRS/IA v0.1. Penerimaan draf ini mengizinkan klarifikasi OPN, bukan mengesahkan semua usulan pada daftar tersebut.

Pengguna telah menyetujui SRS dan IA v0.2 sebagai satu pasangan baseline fase 3 melalui pilihan A. Fase 2 selesai; keluaran fase 3 tersedia untuk review, belum menjadi baseline yang disetujui. Klarifikasi perilaku tawaran, privasi, katalog/CSV, ukuran/kinerja, presisi dan peta telah diintegrasikan; koreksi peran dikeluarkan dari MVP. Sisa SRS §7 terutama berupa rancangan/bukti data, model, autentikasi, penghapusan, protokol uji serta geometri/implementasi peta. Rincian tambahan yang belum ditetapkan tidak menjadi fitur wajib secara diam-diam. Jangan menutup pertanyaan itu melalui asumsi diam-diam.

Jejak pelaksanaan berada di [progres rencana](../plan/2026-11-06-source-of-truth-progress.md). Tidak ada perubahan aplikasi, pelatihan model atau deployment pada fase dokumentasi ini.
