# SAMBUNG — Ringkasan Keputusan Fase 1

**Status:** disetujui pengguna; fase 1 selesai dan ditutup. Ringkasan ini tidak menggantikan [catatan keputusan lengkap](decision-log.md) dan [laporan verifikasi](verification-report.md).

Tanggal pencatatan: 6 November 2026. Dasar: jawaban pengguna pada DEC-001 sampai kelompok DEC-012, termasuk subbutir yang sudah dijawab. Detail teknis yang belum dipilih tidak dianggap disepakati diam-diam.

## 1. Lingkup final dan pengguna

- Source of truth berfokus pada MVP final lomba26–28November2026; prototipe10November merupakan milestone, inkubasi dicatat terpisah.
- Seluruh fitur wajib dan prioritas tinggi proposal tetap menjadi target: data bersih, harga wajar, lampu harga, papan harga, kontrak simulasi/pemeriksa, SHAP, prakiraan, peta, dasbor produsen dan notifikasi.
- Seluruh fitur MVP gratis; transaksi tanpa komisi. Langganan produsen dan API berbayar merupakan rencana hilirisasi.
- Ruang kerja khusus untuk petani/kelompok tani, penggilingan/pengolah dan Admin. Warga, pendamping dan Dinas memakai informasi publik tanpa ruang kerja khusus.
- Satu peran per akun biasa; tidak ada pergantian penjual/pembeli dalam satu akun. Admin disediakan pengelola, tanpa pendaftaran publik.
- Katalog/detail tawaran memerlukan login. Papan harga, peta, prakiraan dan bantuan dapat diakses publik. Hak memesan tetap milik pembeli; akses baca tidak berarti hak bertindak atas transaksi orang lain.
- Transaksi simulasi tersedia untuk seluruh provinsi. Cakupan informasi harga/model mengikuti data valid, bukan dianggap lengkap untuk seluruh provinsi.

Acuan: DEC-001/002/002a/003/003a–c/009c.

## 2. Transaksi simulasi

- Seluruh kontrak final berlabel simulasi, tidak menjadi data latih. Transaksi nyata merupakan lingkup inkubasi.
- Pembelian parsial diperbolehkan: satu tawaran dapat memiliki beberapa kontrak. Volume dicadangkan saat pesanan berhasil diajukan; sisa volume tetap tersedia.
- Jika ditolak, dibatalkan atau kedaluwarsa, volume terkait kembali tersedia, tepat satu kali.
- Batas awal menunggu kesepakatan24jam sejak pengajuan; tidak diulang saat negosiasi. Admin dapat mengubah durasi, tetapi hanya untuk pesanan baru. Tenggat pesanan aktif tetap.
- Pembeli dapat memakai harga petani atau mengajukan harga lain. Tawaran balik tidak dibatasi jumlahnya selama belum kedaluwarsa.
- Pengajuan harga merupakan persetujuan pengaju; ketika pihak lain menerima harga aktif terakhir, kontrak menjadi Disetujui. Harga yang telah digantikan tidak dapat diterima sebagai harga aktif.
- Status Selesai membutuhkan konfirmasi petani dan pembeli. Satu konfirmasi belum menyelesaikan kontrak.
- Sebelum Selesai, salah satu pihak boleh membatalkan kontrak Disetujui dengan alasan wajib, notifikasi kepada pihak lain dan pengembalian volume.
- Saat menunggu, pembeli dapat membatalkan dan petani dapat menolak; alasan wajib dan dikirim dalam notifikasi kepada pihak lain.
- Admin mengelola operasional dan memantau; tidak boleh menawar, menyetujui, membatalkan atau menyelesaikan kontrak atas nama pengguna.

**Target lima langkah:** lima tindakan utama lintas kedua pihak pada alur normal: pilih tawaran → kirim pesanan → terima harga → konfirmasi selesai pihak pertama → konfirmasi selesai pihak kedua. Login, navigasi dan negosiasi tambahan dikecualikan. Jangan melaporkannya sebagai maksimal lima klik seluruh aplikasi.

Acuan: DEC-004/005a–k/003a.

## 3. Harga wajar dan lampu harga

- GKP dan GKG dapat ditawarkan dan dinilai harga wajarnya, dengan parameter berbeda.
- Estimator memakai harga beras produsen × rendemen jenis gabah × rasio historis. Batas bawah/atas memakai P10/P90 rasio historis valid per jenis gabah dan wilayah. Nilai rendemen serta dataset harus dibuktikan; tidak otomatis memakai rendemen GKP untuk GKG atau faktor tetap93–97% untuk semua wilayah.
- Mutu dicatat dan diberi peringatan, tanpa koreksi numerik harga pada MVP. Petani boleh memilih “Belum diukur” untuk kadar air dan kadar hampa/kotoran; tawaran tetap dapat terbit dan mutu tidak diketahui tidak diberi nilai nol.
- Jika acuan belum tersedia, tawaran tetap boleh terbit dengan label “Acuan harga belum tersedia”, tanpa lampu. Tidak membuat rentang ilustrasi sebagai pengganti data.
- Hijau: harga dalam rentang, termasuk kedua batas. Kuning: di bawah batas bawah tetapi masih dalam toleransi, atau seluruh harga di atas batas atas. Merah: lebih rendah daripada batas toleransi bawah.
- Toleransi awal3%, dapat diubah Admin. Tepat pada97% batas bawah masih kuning; kurang dari itu merah.
- Merah tidak memblokir, tetapi memerlukan alasan peringatan dan konfirmasi eksplisit sebelum melanjutkan aksi.
- Perubahan ambang berlaku pada pemeriksaan pengajuan/penerimaan berikutnya. Riwayat lama tetap tersimpan; kontrak Disetujui mempertahankan pemeriksaan saat kesepakatan.

Acuan: DEC-007a–f/006a–d.

## 4. Prakiraan, SHAP dan informasi harga

- Horizon keluaran dua dan empat pekan; riwayat masukan satu sampai delapan pekan bukan horizon keluaran.
- Keluaran mencakup prakiraan beras produsen per provinsi dan estimasi turunan GKP/GKG dengan label yang membedakannya dari prediksi langsung gabah.
- SHAP menjelaskan prakiraan serta perbedaan harga antarwilayah dari model yang relevan. Penjelasan komponen rumus estimator tidak disebut SHAP; kontribusi fitur tidak dianggap bukti sebab-akibat.
- Jika model belum memenuhi target, gunakan baseline yang telah dievaluasi dengan label “Prakiraan baseline”. Hasil model tetap dilaporkan. SHAP model lain tidak ditempel pada baseline seolah menjelaskan keluaran yang sama.
- Target proposal tetap menjadi acuan: MASE≤0,9, pembanding baseline/SARIMA, pita80% dengan cakupan empiris75–85%, serta evaluasi lonjakan recall≥70% dan precision≥60%. Ini target, bukan hasil yang telah dicapai. Peringatan dini otomatis dan retraining otomatis tetap lingkup inkubasi.
- Harga petani pada papan harga memakai data pengamatan. Harga GKP/GKG, ekuivalen beras dan estimasi harga wajar dipisahkan. Pengamatan yang tidak tersedia tidak diganti transaksi simulasi atau estimasi yang disamarkan sebagai observasi.
- Peta membandingkan harga provinsi dengan median provinsi valid pada komoditas, tingkat pasar dan periode sama: negatif lebih murah, positif lebih mahal. Disparitas maksimum terhadap minimum menjadi ringkasan terpisah.

Acuan: DEC-008a–d/009a–c/002/004; proposal §4.1 dan A.7/A.9.

## 5. Akun, privasi, notifikasi dan ekspor

- Petani/pembeli login dengan nomor HP dan OTP. Kanal serta penyedia pengiriman belum dipilih. Admin login email/kata sandi melalui halaman terpisah.
- Nomor HP saling terlihat setelah Disetujui, hanya bagi kedua pihak pada kontrak terkait. Ini tidak otomatis membuka kontak kepada pengguna lain atau Admin.
- Lokasi tawaran sampai kecamatan, kabupaten/kota dan provinsi, tanpa alamat lengkap atau titik rumah.
- Notifikasi transaksi untuk kedua pelaku melalui pusat notifikasi aplikasi saja; pilihan ini tidak menentukan kanal OTP.
- Ekspor CSV ringkasan harga publik dan pasokan tersedia tanpa nomor HP/data pribadi. Ekspor pasokan mengikuti batas login serta hak akses katalog.

Acuan: DEC-010a–f/003b.

## 6. UI Guidelines

- Arah visual baru: layanan pertanian modern, bersih dan ramah, dengan harga/tindakan utama jelas, tombol besar serta bahasa sederhana.
- Format tetap mengikuti delapan bagian utama contoh referensi; bukan menyalin kebutuhan Jagains.
- Forest Green `#3E5A3A` menjadi warna utama tombol/navigasi aktif; Warm Cream `#FFF3D6` untuk latar terang; kuning/emas menjadi aksen. Palet juga memuat Olive Green `#8A9A3A`, Sunflower Yellow `#FFD55A`, Honey Gold `#F4A62A` dan Terracotta `#C86B3C`.
- Font judul Plus Jakarta Sans; isi/kontrol Atkinson Hyperlegible Next. Harga memakai angka tabular.
- Mendukung mode terang dan gelap yang dapat dipilih. Kontras kedua mode belum dinyatakan lolos sebelum dihitung/diverifikasi.
- Menggunakan shadcn/ui dan Tailwind CSS v4. Pilihan ini merupakan kontrak implementasi berikutnya, bukan klaim paket sudah terpasang.
- Token status, ikon dan teks membedakan lampu harga dari warna merek. Nilai turunan, ukuran tipografi, spacing, radius, grafik/peta dan keadaan interaksi dirinci pada fase3.

Acuan: DEC-011a–f. [Gambar referensi warna](../ui_reference/sambung-color-reference.png) tersimpan utuh.

## 7. Penerimaan dan bukti yang belum tersedia

Uji kegunaan menargetkan minimal lima responden total yang mewakili petani dan pembeli, dengan SUS≥68. Hasil aktual, keberhasilan tugas dan masalah tetap dilaporkan apa adanya (DEC-012a).

Hal berikut **belum dianggap tervalidasi atau dipilih**:

| Kelompok | Yang masih perlu dibuktikan/dirinci | Perlakuan pada fase berikutnya |
|---|---|---|
| Estimator | Dataset, rendemen GKG, periode kalibrasi, ukuran sampel minimum, penyelarasan waktu/mutu, outlier dan ambang peringatan mutu | Catat sebagai ketergantungan data/validasi; jangan mengarang parameter atau menyebut estimasi tersedia sebelum syarat terpenuhi |
| Model | Dataset/fitur, rancangan SHAP wilayah, model/baseline/interval dan hasil evaluasi masing-masing horizon/hasil turunan | Spesifikasikan target dan protokol di SRS, pisahkan hasil aktual; fallback tidak menghapus kekurangan pencapaian target |
| Layanan | Kanal/penyedia OTP, biaya/integrasi, runtime model, backend dan basis data | Pilih pada rancangan teknis; Laravel, PostgreSQL dan ML offline pada draf lama belum menjadi keputusan pengguna |
| Data pribadi | Retensi, hapus akun, akses Admin atas data sensitif dan visibilitas kontak setelah pembatalan | Buat usulan eksplisit pada SRS untuk ditinjau; jangan menganggap hak akses tanpa batas |
| IA | Inventaris/ID final, rincian aksi, efek moderasi pada tawaran aktif, kategori peta dan alias halaman bersama | Turunkan dari keputusan di atas; perubahan perilaku substantif dibawa kembali untuk keputusan pengguna |
| UI | Token terang/gelap, kontras, font/fallback, ukuran/skala, versi/basis komponen dan API pustaka | Rinci/verifikasi pada fase3; jangan mengklaim sudah diuji di prototipe |
| Bukti sumber | Wireframe asli, kamus/brief tambahan, kode prototipe, laporan data/backtest/SUS | Tetap berstatus tidak tersedia dalam audit ini; jangan menganggap diagnosis lama sebagai fakta implementasi |

Rincian yang mengubah perilaku atau lingkup harus diajukan kembali, bukan ditetapkan diam-diam. Bukti teknis yang belum tersedia merupakan keterbatasan yang dicatat, bukan pertanyaan preferensi yang perlu ditebak oleh pengguna.

## 8. Konfirmasi pengguna

Pengguna menjawab “A” pada pilihan “Sesuai — fase pertama dapat ditutup” melalui chat ini pada 6 November 2026. Ringkasan diterima sebagai dasar penyusunan SRS/IA; pembahasan keputusan inti fase 1 ditutup. Daftar validasi dan rincian lanjutan pada bagian 7 tetap terbuka. Persetujuan ini bukan bukti bahwa data, model, aplikasi atau kontras telah lulus pengujian.

Status saat penutupan fase 1: fase 2 dan fase 3 belum dijalankan. Pembaruan 6 November 2026: pengguna kemudian meminta fase 2 dimulai; SRS/IA v0.1 sedang disiapkan untuk review. Isi keputusan fase 1 tetap sama dan sumber asli tidak ditimpa.

