# SAMBUNG — Catatan Keputusan dan Klarifikasi

Tanggal pembukaan: 6 November 2026. Status: fase 1 selesai; ringkasan keputusan disetujui pengguna. Acuan audit: [verification-report.md](verification-report.md).

“Direkomendasikan” berarti usulan penyusun, bukan jawaban pengguna. Setiap keputusan terkonfirmasi memuat pemberi keputusan, tanggal, jawaban dan dampak. Persetujuan satu butir tidak menyetujui rekomendasi lain.

## 1. Keputusan terkonfirmasi

### DEC-001 — Target source of truth

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Pertanyaan:** apakah source of truth berfokus pada MVP final lomba26–28 November2026, dengan inkubasi dicatat terpisah?
- **Jawaban:** “Ya, fokus MVP final lomba”.
- **Dampak:** SRS/IA/UI utama mengacu MVP final. Target prototipe10November menjadi milestone; fitur inkubasi diberi label terpisah. Keputusan ini tidak berarti menyetujui semua prioritas/default lama.
- **Sumber:** proposal §4.3, A.2 dan A.9; AUD-001.

### DEC-002 — Target fitur final

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — seluruh fitur wajib dan prioritas tinggi proposal menjadi target MVP final.
- **Cakupan:** data bersih, harga wajar, lampu harga, papan harga dua sisi, kontrak simulasi dan pemeriksa harga, SHAP dasar, prakiraan, peta publik, dasbor produsen, serta notifikasi.
- **Dampak:** tidak menurunkan fitur tersebut menjadi tambahan jika waktu memungkinkan. Metode AI, aturan transaksi, aktor, dan rincian prioritas implementasi masih perlu diklarifikasi. Retraining otomatis, peringatan dini dan multibahasa tetap dipisahkan sebagai lingkup inkubasi sesuai proposal.
- **Sumber:** pilihan A pada pertanyaan DEC-002; proposal A.9; AUD-001, AUD-009, AUD-013, AUD-023.

### DEC-003 — Aktor dan ruang kerja MVP final

- **Status:** terkonfirmasi untuk lingkup aktor; rincian izin per aksi masih akan diturunkan.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — ruang kerja khusus untuk petani/kelompok tani, penggilingan/pengolah, dan Admin.
- **Akses publik:** warga, pendamping dan Dinas dapat mengakses informasi publik tanpa ruang kerja khusus.
- **Dampak:** MVP final tidak mencakup ruang kerja Pendamping atau dasbor Dinas, maupun fungsi pendamping mengelola tawaran atas nama petani. Izin Admin dan visibilitas data pribadi tidak otomatis menjadi akses tanpa batas; rincian dibahas pada aturan akses.
- **Sumber:** pilihan A pada pertanyaan DEC-003; AUD-002, AUD-015, AUD-033.

### DEC-004 — Transaksi simulasi pada MVP final

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — seluruh transaksi MVP final merupakan simulasi.
- **Aturan:** kontrak diberi label simulasi; harga transaksi simulasi tidak digunakan untuk melatih model.
- **Dampak:** transaksi nyata menjadi lingkup inkubasi. Status selesai pada MVP membuktikan penyelesaian alur simulasi, bukan bukti pembayaran, pengiriman, atau harga transaksi nyata. Aturan negosiasi dan penyelesaian simulasi dibahas pada DEC-005.
- **Sumber:** pilihan A pada pertanyaan DEC-004; proposal A.9; AUD-005, AUD-012.

### DEC-005a — Pembelian sebagian volume

- **Status:** terkonfirmasi untuk pembelian parsial; aturan reservasi volume masih terbuka.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “B” — pembeli boleh membeli sebagian volume dari satu tawaran panen.
- **Aturan:** sisa volume tetap tersedia untuk pembeli lain; satu tawaran dapat memiliki beberapa kontrak.
- **Contoh:** dari tawaran 1.000 kg, pembelian 400 kg menyisakan 600 kg untuk pembeli lain. Kapan volume dianggap dipesan/dicadangkan dibahas pada DEC-005b.
- **Dampak:** menggantikan default Q-10 lama “satu listing = satu kontrak, tanpa pembelian parsial”. SRS/IA perlu membedakan volume total, dicadangkan, disepakati, dan tersedia sesuai aturan reservasi yang akan dipilih. Status satu kontrak tidak otomatis menentukan status seluruh tawaran.
- **Sumber:** pilihan B pada pertanyaan DEC-005a; AUD-003, AUD-025.

### DEC-005b — Reservasi volume saat pengajuan pesanan

- **Status:** terkonfirmasi untuk waktu reservasi dan pelepasannya; durasi menunggu masih terbuka.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — volume dicadangkan saat pesanan diajukan.
- **Aturan:** volume pesanan yang berhasil diajukan mengurangi volume tersedia bagi pembeli lain selama menunggu kesepakatan. Jika pesanan ditolak, dibatalkan, atau kedaluwarsa, volume cadangannya kembali tersedia.
- **Contoh:** tawaran tersedia 1.000 kg; pesanan 400 kg mencadangkan 400 kg dan menyisakan 600 kg untuk pembeli lain.
- **Dampak:** pengajuan pesanan harus memeriksa dan mencadangkan volume secara atomik agar pesanan bersamaan tidak mengambil volume yang sama. Pelepasan reservasi tidak boleh menggandakan volume. Volume yang telah disepakati diperlakukan terpisah dari reservasi menunggu; konsekuensi pembatalan setelah persetujuan akan dirinci pada aturan status.
- **Sumber:** pilihan A pada pertanyaan DEC-005b; DEC-005a; AUD-003, AUD-025.

### DEC-005c — Durasi menunggu kesepakatan yang dapat dikonfigurasi

- **Status:** terkonfirmasi untuk nilai awal, titik mulai, dan kewenangan konfigurasi; dampak perubahan terhadap pesanan aktif masih terbuka.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A, dengan catatan admin dapat merubah waktunya (dinamis)”.
- **Aturan:** nilai awal durasi menunggu kesepakatan adalah 24 jam, dihitung sejak pesanan diajukan dan tidak diulang saat negosiasi. Admin dapat mengubah parameter durasi tersebut; nilainya tidak boleh menjadi konstanta yang tidak dapat dikonfigurasi.
- **Dampak:** pesanan yang belum disepakati hingga batas waktunya kedaluwarsa dan reservasi volumenya dilepas sesuai DEC-005b. Dampak perubahan parameter terhadap batas waktu pesanan yang sedang berjalan akan diputuskan pada DEC-005d.
- **Sumber:** pilihan A beserta catatan pengguna pada pertanyaan DEC-005c; DEC-005b.

### DEC-005d — Perubahan durasi hanya untuk pesanan baru

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — perubahan durasi oleh Admin hanya berlaku untuk pesanan baru.
- **Aturan:** saat pesanan diajukan, batas waktunya ditetapkan memakai parameter durasi yang berlaku saat itu. Perubahan parameter berikutnya tidak mengubah batas waktu pesanan aktif. Negosiasi juga tidak mengulang hitungan waktu sesuai DEC-005c.
- **Contoh:** Admin mengubah durasi dari 24 menjadi 48 jam; pesanan yang sudah aktif tetap memiliki tenggat awalnya, sedangkan pesanan baru memakai 48 jam sejak pengajuan.
- **Dampak:** batas waktu setiap pesanan perlu disimpan terpisah dari parameter durasi global; pemeriksaan kedaluwarsa menggunakan tenggat pesanan tersebut.
- **Sumber:** pilihan A pada pertanyaan DEC-005d; DEC-005b dan DEC-005c.

### DEC-005e — Harga pesanan dan negosiasi

- **Status:** terkonfirmasi untuk harga pengajuan dan respons petani; batas negosiasi masih terbuka.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — pembeli boleh mengikuti harga petani atau mengajukan harga lain; petani dapat menerima, menolak, atau memberikan tawaran balik.
- **Dampak:** pesanan perlu menyimpan harga yang diajukan pembeli dan riwayat tawaran balik. Pengajuan harga lain tidak langsung mengubah harga pada tawaran panen petani. Batas jumlah perubahan harga serta persetujuan atas harga terakhir dibahas pada butir berikutnya. Tenggat tidak diulang saat negosiasi sesuai DEC-005c.
- **Sumber:** pilihan A pada pertanyaan DEC-005e; AUD-004.

### DEC-005f — Negosiasi tanpa batas jumlah tawaran balik

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — jumlah tawaran balik tidak dibatasi selama pesanan belum kedaluwarsa.
- **Aturan:** negosiasi berakhir saat kesepakatan tercapai, pesanan ditolak, dibatalkan, atau kedaluwarsa. Pengajuan tawaran balik tidak mengulang tenggat sesuai DEC-005c.
- **Dampak:** default lama maksimal dua putaran tidak digunakan. Riwayat tawaran tetap diperlukan, tetapi jumlah putaran bukan pembatas transaksi. Mekanisme persetujuan harga terakhir dibahas berikutnya.
- **Sumber:** pilihan A pada pertanyaan DEC-005f; DEC-005c dan DEC-005e; AUD-004.

### DEC-005g — Persetujuan atas harga terakhir

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — mengajukan harga berarti menyetujui harga tersebut; penerimaan pihak lain langsung menjadikan kontrak Disetujui.
- **Aturan:** tawaran balik menggantikan harga sebelumnya sebagai tawaran aktif. Persetujuan pengaju melekat pada harga yang diajukannya; penerimaan harus mengacu pada tawaran aktif terakhir, bukan harga yang sudah digantikan. Tidak diperlukan tombol persetujuan ulang dari pengaju setelah pihak lain menerima.
- **Dampak:** antarmuka pengajuan harga harus menjelaskan bahwa pengiriman merupakan persetujuan terhadap harga tersebut. Sistem harus mencegah penerimaan harga lama atau penerimaan setelah pesanan berakhir. Penawaran baru tidak mewarisi persetujuan pihak lawan atas harga sebelumnya.
- **Sumber:** pilihan A pada pertanyaan DEC-005g; DEC-005e dan DEC-005f; AUD-004.

### DEC-005h — Penyelesaian simulasi oleh kedua pihak

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — kedua pihak mengonfirmasi selesai.
- **Aturan:** setelah kontrak Disetujui, petani dan pembeli masing-masing dapat mengonfirmasi penyelesaian. Status menjadi Selesai hanya setelah kedua konfirmasi tercatat; konfirmasi satu pihak saja belum menyelesaikan kontrak.
- **Dampak:** simpan konfirmasi penyelesaian per pihak dan tampilkan pihak yang masih ditunggu. Konfirmasi berulang dari pihak yang sama tidak dihitung sebagai konfirmasi pihak lainnya. Status Selesai tetap merupakan penyelesaian simulasi sesuai DEC-004, bukan bukti transaksi nyata. Kedaluwarsa menunggu kesepakatan tidak otomatis berlaku pada tahap Disetujui.
- **Sumber:** pilihan A pada pertanyaan DEC-005h; DEC-004 dan DEC-005g; AUD-005, AUD-019.

### DEC-005i — Pembatalan sepihak setelah persetujuan

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “B” — sebelum kontrak Selesai, salah satu pihak dapat langsung membatalkan kontrak yang sudah Disetujui dengan alasan wajib.
- **Aturan:** pembatalan tidak memerlukan persetujuan pihak lain atau Admin. Pihak lain mendapat notifikasi; volume kontrak yang dibatalkan kembali tersedia. Kontrak berstatus Selesai tidak termasuk kewenangan pembatalan ini.
- **Dampak:** catat pelaku, alasan dan waktu pembatalan; lepaskan volume tepat satu kali. Jika satu pihak sudah mengonfirmasi selesai tetapi pihak lain belum, kontrak belum Selesai dan masih termasuk cakupan pembatalan ini. Konfirmasi selesai dan pembatalan yang bersamaan harus menghasilkan satu status akhir yang konsisten, tanpa menyelesaikan sekaligus membatalkan kontrak.
- **Sumber:** pilihan B pada pertanyaan DEC-005i; DEC-005b dan DEC-005h; AUD-004, AUD-025.

### DEC-005j — Alasan wajib saat pembatalan atau penolakan sebelum kesepakatan

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — pembatalan atau penolakan saat menunggu kesepakatan wajib disertai alasan.
- **Aturan:** pembeli dapat membatalkan pesanan yang masih menunggu kesepakatan; petani dapat menolaknya. Alasan wajib diisi, pihak lain menerima notifikasi beserta alasan, dan volume pesanan kembali tersedia sesuai DEC-005b.
- **Dampak:** pengiriman aksi tanpa alasan ditolak dengan pesan validasi. Catat pelaku, alasan dan waktu pengakhiran; pelepasan volume hanya sekali. Hak mengakhiri pesanan melekat pada peran petani/pembeli dan tidak bergantung pada siapa pengaju harga terakhir saat negosiasi.
- **Sumber:** pilihan A pada pertanyaan DEC-005j; DEC-005b dan DEC-005e; AUD-004, AUD-025.

### DEC-005k — Definisi target maksimal lima langkah

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — maksimal lima tindakan utama untuk alur normal kedua pihak.
- **Alur acuan:** pilih tawaran → kirim pesanan → terima harga → petani konfirmasi selesai → pembeli konfirmasi selesai. Urutan dua konfirmasi selesai dapat dipertukarkan; status Selesai tetap membutuhkan keduanya.
- **Batas pengukuran:** login, navigasi dan negosiasi tambahan tidak dihitung. Ini ukuran tindakan utama lintas kedua pihak, bukan maksimal lima klik seluruhnya atau lima langkah per pengguna. Alur acuan memakai harga yang langsung diterima tanpa tawaran balik.
- **Dampak:** kriteria penerimaan harus menguji alur sampai status Selesai, dengan titik awal pemilihan tawaran dari katalog yang sudah tersedia. Laporan uji wajib menjelaskan pengecualian hitungan ini dan tidak mengklaim seluruh interaksi hanya lima klik. Pembatalan, penolakan, negosiasi dan kedaluwarsa diuji sebagai alur alternatif terpisah.
- **Sumber:** pilihan A pada pertanyaan DEC-005k; proposal §4.1; DEC-005g/h; AUD-019.

### DEC-007a — Dukungan GKP dan GKG

- **Status:** terkonfirmasi untuk cakupan komoditas; metode estimasi dan parameter mutu masing-masing masih terbuka.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “B” — GKP (Gabah Kering Panen) dan GKG (Gabah Kering Giling) dapat ditawarkan dan dinilai harga wajarnya pada MVP final.
- **Aturan:** rentang harga wajar serta parameter mutu dibedakan menurut jenis gabah. GKG tidak dibatasi hanya sebagai data pembanding.
- **Dampak:** menggantikan default lama GKP saja/GKG ditunda. Jenis gabah harus konsisten pada tawaran, pesanan, kontrak, filter katalog dan pemeriksaan harga. Rendemen 0,5338 yang disebut proposal untuk GKP tidak otomatis berlaku pada GKG; sumber data, parameter dan metode estimator GKG perlu ditetapkan secara tersendiri. Perlu membedakan jenis gabah dari komoditas beras pada papan harga.
- **Sumber:** pilihan B pada pertanyaan DEC-007a; AUD-007, AUD-010, AUD-018; Q-04 lama.

### DEC-007b — Estimator harga wajar berbasis rumus historis

- **Status:** terkonfirmasi untuk pendekatan; nilai parameter, metode pembentukan rentang dan perlakuan mutu masih terbuka.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — harga wajar GKP dan GKG dihitung dengan rumus berbasis data historis.
- **Aturan:** harga beras produsen dikonversi menggunakan rendemen dan rasio historis yang dibedakan untuk GKP/GKG. Komponen perhitungan ditampilkan agar dapat dijelaskan. Prakiraan menggunakan model AI tersendiri; pemilihan estimator rumus tidak menghapus fitur prakiraan dan SHAP yang sudah menjadi target final.
- **Dampak:** sumber masukan estimator menggunakan harga beras tingkat produsen, menyelesaikan pilihan eceran vs produsen untuk pendekatan tahap awal. Jangan menyebut penjelasan komponen rumus sebagai SHAP. Nilai rendemen GKG, rasio historis dan cara pembentukan batas rentang harus memiliki sumber/versi, bukan disalin dari GKP atau diasumsikan 93–97% tanpa bukti.
- **Sumber:** pilihan A pada pertanyaan DEC-007b; DEC-007a; proposal A.7; AUD-007, AUD-009, AUD-028.

### DEC-007c — Mutu dicatat tanpa koreksi harga otomatis

- **Status:** terkonfirmasi untuk perlakuan mutu; rincian field dan ambang peringatan masih perlu ditentukan berbasis sumber.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — mutu gabah dicatat dan diberi peringatan, tetapi belum mengubah perhitungan harga wajar pada MVP final.
- **Aturan:** rentang harga tetap dibedakan untuk GKP/GKG menurut DEC-007a/b. Informasi mutu, misalnya kadar air dan kadar hampa/kotoran, tidak menjadi faktor koreksi numerik pada rentang. Antarmuka harus menjelaskan bahwa mutu belum diperhitungkan dalam estimasi harga.
- **Dampak:** jangan membuat tabel potongan atau faktor koreksi mutu yang tidak tervalidasi. Pencatatan/peringatan tidak menyatakan mutu telah diverifikasi fisik. Ambang peringatan, field wajib/opsional dan penanganan mutu yang belum diketahui harus ditentukan tersendiri; keputusan ini tidak otomatis mengesahkan ambang kadar air 25% pada draf lama.
- **Sumber:** pilihan A pada pertanyaan DEC-007c; DEC-007a/b; AUD-007 dan pemeriksaan F-20.

### DEC-007d — Mutu boleh belum diukur

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — petani boleh memilih “Belum diukur” untuk kadar air dan kadar hampa/kotoran, dan tetap menerbitkan tawaran.
- **Aturan:** informasi mutu yang belum diukur ditampilkan sebagai belum diketahui, bukan nol, memenuhi standar, atau hasil pengukuran. Nilai yang diisi petani tetap berupa deklarasi, bukan verifikasi fisik platform.
- **Dampak:** form menyediakan pilihan belum diukur untuk masing-masing informasi mutu. Detail tawaran yang dilihat pembeli mempertahankan label tersebut. Tidak mengisi angka mutu tidak boleh menghalangi penerbitan; data yang tersedia tetap mengikuti DEC-007c tanpa koreksi numerik harga.
- **Sumber:** pilihan A pada pertanyaan DEC-007d; DEC-007c; pemeriksaan F-20.

### DEC-007e — Tawaran tetap dapat terbit tanpa acuan harga

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — jika data jenis gabah atau wilayah belum cukup untuk menghasilkan acuan harga, tawaran tetap boleh diterbitkan.
- **Aturan:** tampilkan “Acuan harga belum tersedia” dan jangan memberikan lampu harga. Pembeli tetap dapat melihat tawaran dan bernegosiasi. Tidak tersedianya acuan tidak boleh dianggap sebagai harga wajar, lampu hijau, atau nilai nol.
- **Dampak:** estimasi dan pemeriksaan harga harus mendukung keadaan tidak tersedia yang berbeda dari hijau/kuning/merah. Informasi ini harus tetap jelas pada tawaran serta pemeriksaan harga pesanan/kontrak terkait. Jangan menggantikan data yang hilang dengan rentang ilustrasi atau memakai parameter jenis gabah lain tanpa dasar. Aturan kualitas/kecukupan data masih perlu ditetapkan berbasis bukti.
- **Sumber:** pilihan A pada pertanyaan DEC-007e; DEC-007a/b; AUD-006, AUD-007, AUD-030.

### DEC-006a — Lampu merah memerlukan konfirmasi, bukan blokir

- **Status:** terkonfirmasi untuk konsekuensi peringatan; ambang dan perilaku harga di atas rentang masih terbuka.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — transaksi dengan harga jauh di bawah rentang wajar tetap boleh dilanjutkan setelah konfirmasi eksplisit.
- **Aturan:** tampilkan alasan peringatan dan minta pengguna mengonfirmasi bahwa ia memahami harga tersebut sebelum melanjutkan aksi terkait. Lampu merah tidak mewajibkan kenaikan harga dan tidak menjadi larangan permanen menerbitkan tawaran atau menyepakati kontrak.
- **Dampak:** konfirmasi harus terkait harga yang sedang diproses, bukan persetujuan umum untuk semua harga berikutnya. Selaraskan pemeriksaan ini dengan DEC-005g: pengajuan harga merupakan persetujuan pengaju, sehingga peringatan yang relevan perlu muncul sebelum pengiriman harga maupun penerimaan oleh pihak lain. Acuan tidak tersedia mengikuti DEC-007e, bukan diberi lampu merah.
- **Sumber:** pilihan A pada pertanyaan DEC-006a; DEC-005g dan DEC-007e; AUD-006.

### DEC-006b — Harga di atas rentang tetap kuning

- **Status:** terkonfirmasi; nilai ambang bawah untuk merah masih terbuka.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — harga di atas rentang wajar tetap kuning dengan alasan “Di atas rentang wajar”.
- **Aturan:** merah khusus harga yang jauh di bawah batas bawah rentang wajar. Harga di atas batas atas tidak menjadi merah meskipun selisihnya besar. Arti status tidak dibalik menurut peran pembeli atau penjual.
- **Dampak:** pemeriksaan harga memakai aturan asimetris; penjelasan harus menyebut posisi harga terhadap rentang agar kuning di atas tidak disalahartikan sebagai harga yang berada di dalam rentang. Konfirmasi eksplisit lampu merah mengikuti DEC-006a; keputusan ini tidak menetapkan konfirmasi tambahan untuk kuning.
- **Sumber:** pilihan A pada pertanyaan DEC-006b; AUD-006; Q-01 lama.

### DEC-006c — Ambang awal lampu harga 3%, dapat diubah Admin

- **Status:** terkonfirmasi sebagai konfigurasi awal MVP, bukan ambang yang telah tervalidasi empiris.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — ambang awal 3%, dapat diubah Admin.
- **Aturan:** dengan L batas bawah, U batas atas, P harga dan δ toleransi awal 0,03: hijau untuk L ≤ P ≤ U; kuning untuk L×(1−δ) ≤ P < L; merah untuk P < L×(1−δ); seluruh P > U kuning sesuai DEC-006b. Kedua batas rentang termasuk hijau; tepat pada ambang bawah toleransi termasuk kuning.
- **Contoh:** jika L = Rp7.000/kg, harga Rp6.790/kg hingga kurang dari Rp7.000/kg kuning; harga kurang dari Rp6.790/kg merah. Contoh ini ilustrasi hitungan, bukan data harga pasar.
- **Dampak:** parameter persentase dapat dikonfigurasi Admin. Jangan menyatakan 3% sebagai ambang resmi atau tervalidasi. Konfirmasi eksplisit untuk merah mengikuti DEC-006a. Dampak perubahan parameter pada pemeriksaan yang sudah tercatat dan kontrak aktif belum diputuskan.
- **Sumber:** pilihan A pada pertanyaan DEC-006c; DEC-006a/b; AUD-006.

### DEC-006d — Perubahan ambang berlaku pada pemeriksaan berikutnya

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — ambang baru dipakai pada pemeriksaan berikutnya saat harga diajukan atau diterima.
- **Aturan:** hasil pemeriksaan sebelumnya tetap disimpan sebagai riwayat. Kontrak yang sudah Disetujui mempertahankan hasil pemeriksaan saat kesepakatan; perubahan ambang tidak menghitung ulang hasil tersebut secara retroaktif.
- **Dampak:** setiap pemeriksaan perlu menyimpan harga, rentang acuan dan versi/nilai ambang yang digunakan agar hasil historis dapat dijelaskan. Penerimaan harga yang masih menunggu kesepakatan memakai ambang yang berlaku pada pemeriksaan penerimaan itu; jika hasilnya merah, konfirmasi eksplisit DEC-006a tetap diperlukan. Aturan ini tidak mengubah harga kesepakatan atau tenggat pesanan.
- **Sumber:** pilihan A pada pertanyaan DEC-006d; DEC-006a/c; AUD-006.

### DEC-008a — Horizon prakiraan dua dan empat pekan

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — prakiraan MVP final ditampilkan untuk dua dan empat pekan ke depan.
- **Aturan:** kedua horizon merupakan keluaran yang ditampilkan dan dievaluasi; keluaran mingguan satu/tiga pekan bukan kewajiban MVP berdasarkan keputusan ini. Riwayat masukan satu sampai delapan pekan pada proposal A.7 tidak dimaknai sebagai horizon keluaran.
- **Dampak:** label, filter, grafik, penjelasan prakiraan, model data dan kriteria penerimaan harus menggunakan horizon dua/empat pekan. Draf lama yang menyebut keluaran satu sampai empat pekan perlu diselaraskan. Keputusan ini belum menentukan tingkat pasar/komoditas target prakiraan maupun cakupan penjelasan SHAP.
- **Sumber:** pilihan A pada pertanyaan DEC-008a; proposal A.7; AUD-008.

### DEC-008b — Prakiraan beras produsen dan estimasi turunan GKP/GKG

- **Status:** terkonfirmasi untuk keluaran produk; parameter konversi dan evaluasi hasil turunan masih memerlukan bukti.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “B” — tampilkan prakiraan harga beras tingkat produsen per provinsi beserta estimasi turunan GKP/GKG untuk dua dan empat pekan ke depan.
- **Aturan:** hasil prakiraan beras dikonversi menggunakan parameter yang dibedakan untuk GKP dan GKG. Hasil gabah diberi label “estimasi turunan”, bukan prediksi langsung harga gabah. Komponen konversi dapat dijelaskan sesuai DEC-007b.
- **Dampak:** bedakan keluaran model beras dari keluaran konversi gabah dalam data, grafik dan laporan evaluasi. Jangan menyatakan akurasi atau cakupan interval model beras otomatis berlaku pada gabah; hasil turunan memerlukan evaluasi terhadap data gabah yang tersedia. Jika parameter/data jenis gabah atau wilayah belum memadai, tampilkan ketidaktersediaan dengan jelas, bukan mengarang estimasi. Mutu belum menjadi koreksi numerik sesuai DEC-007c.
- **Sumber:** pilihan B pada pertanyaan DEC-008b; DEC-007a/b/c, DEC-008a; AUD-007, AUD-008, AUD-009.

### DEC-008c — SHAP untuk prakiraan dan perbedaan harga antarwilayah

- **Status:** terkonfirmasi untuk lingkup penjelasan; rancangan model, fitur dan validasi masih memerlukan bukti.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — SHAP digunakan untuk menjelaskan prakiraan dan perbedaan harga antarwilayah pada MVP final.
- **Aturan:** kedua penjelasan bersumber dari kontribusi fitur model yang relevan, bukan teks umum yang diberi label SHAP. Estimator gabah berbasis rumus tetap dijelaskan melalui komponen perhitungannya, bukan disebut SHAP.
- **Dampak:** tidak menggunakan default draf lama yang membatasi SHAP pada prakiraan dan mengganti penjelasan wilayah dengan teks statis saja. Untuk perbandingan wilayah, model, target harga, periode, baseline penjelasan dan metode perbandingan kontribusi perlu konsisten serta divalidasi. Kontribusi model tidak boleh disebut bukti sebab-akibat. Jika keluaran model/penjelasan belum tersedia, tampilkan keterbatasan secara jujur, bukan membuat faktor atau bobot fiktif.
- **Sumber:** pilihan A pada pertanyaan DEC-008c; proposal §4.2; DEC-002, DEC-007b, DEC-008b; AUD-009.

### DEC-008d — Fallback prakiraan baseline yang telah dievaluasi

- **Status:** terkonfirmasi untuk kebijakan fallback; protokol evaluasi/publikasi masih perlu dirinci.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — jika model prakiraan belum memenuhi target evaluasi, gunakan baseline pembanding yang sudah dievaluasi dengan label “Prakiraan baseline”.
- **Aturan:** hasil model yang belum memenuhi target tetap dicatat dalam laporan. SHAP hanya ditampilkan untuk model yang benar-benar dijelaskannya; penjelasan model lain tidak boleh ditempel pada prakiraan baseline seolah menjelaskan keluaran yang sama.
- **Dampak:** identitas metode/model, versi dan hasil evaluasi harus jelas. Fallback tidak membuktikan target model AI telah tercapai dan tidak menghapus kebutuhan SHAP DEC-008c. Pita ketidakpastian baseline memerlukan evaluasi/kalibrasi tersendiri; jangan menyalin interval atau klaim cakupan model lain. Jika baseline atau intervalnya belum dapat dievaluasi, tampilkan keterbatasan/ketidaktersediaan secara jujur. Evaluasi dibedakan menurut horizon dan cakupan data, termasuk hasil konversi gabah DEC-008b.
- **Sumber:** pilihan A pada pertanyaan DEC-008d; proposal §4.1/A.7; DEC-008a/b/c; AUD-009 dan pemeriksaan F-06.

### DEC-009a — Harga petani menggunakan data pengamatan

- **Status:** terkonfirmasi untuk pemisahan sumber; detail tingkat pasar, periode dan perhitungan bagian petani masih terbuka.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — harga petani pada papan harga menggunakan data gabah yang benar-benar diamati, bukan estimasi harga wajar.
- **Aturan:** harga GKP/GKG dan ekuivalen beras dibedakan; estimasi harga wajar ditampilkan terpisah. Jika data pengamatan belum tersedia, tampilkan tidak tersedia dan jangan menggantinya dengan transaksi simulasi. Contoh sumber yang dapat dipertimbangkan adalah BPS atau transaksi nyata terverifikasi, dengan sumber, wilayah dan periode yang jelas.
- **Dampak:** ekuivalen beras merupakan hasil konversi dari harga gabah pengamatan, bukan observasi langsung harga beras petani; label harus menjelaskan perbedaan ini. Transaksi nyata terverifikasi tetap lingkup inkubasi sesuai DEC-004, sehingga penyebutannya sebagai jenis sumber tidak mengaktifkan transaksi nyata pada MVP final. Perbandingan antar tingkat pasar harus memperhatikan kesetaraan mutu, wilayah, satuan dan periode data.
- **Sumber:** pilihan A pada pertanyaan DEC-009a; DEC-004, DEC-007a/b; AUD-010.

### DEC-009b — Peta membandingkan harga terhadap median provinsi berdata valid

- **Status:** terkonfirmasi untuk pembanding dan arah selisih; pengelompokan visual serta cakupan wilayah masih perlu dirinci.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — harga tiap provinsi dibandingkan dengan median harga provinsi yang datanya valid, memakai komoditas, tingkat pasar dan periode yang sama.
- **Aturan:** tampilkan persentase lebih murah atau lebih mahal dari median tersebut. Disparitas keseluruhan, yaitu selisih provinsi termahal terhadap termurah, ditampilkan sebagai ringkasan terpisah.
- **Definisi hitungan:** jika harga provinsi P dan median M, selisih bertanda = (P−M)/M × 100%; nilai negatif berarti lebih murah, positif berarti lebih mahal, dan nol berarti sama dengan median. Disparitas keseluruhan = (harga maksimum−harga minimum)/harga minimum × 100%. Perhitungan memerlukan pembanding positif dan data valid; tidak mengisi data kosong dengan nol. Median dihitung atas harga provinsi valid yang setara, bukan rata-rata berbobot penduduk/volume.
- **Dampak:** tampilkan komoditas, tingkat pasar, periode dan cakupan/jumlah provinsi pembentuk pembanding. Dua metrik tersebut tidak boleh memakai label atau legenda yang saling tertukar. Kategori A–D lama tidak otomatis sesuai dengan selisih bertanda dan perlu diganti/didefinisikan tanpa batas tumpang tindih.
- **Sumber:** pilihan A pada pertanyaan DEC-009b; AUD-011 dan AUD-026.

### DEC-009c — Cakupan transaksi seluruh provinsi

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “B” — transaksi MVP final tersedia untuk seluruh provinsi, bukan dibatasi Jawa Timur.
- **Aturan:** papan harga dan peta menampilkan seluruh provinsi yang memiliki data valid. Ketersediaan acuan harga tidak menjadi syarat wilayah boleh bertransaksi; jika acuan belum tersedia, tawaran tetap dapat diterbitkan dengan keterangan jelas dan tanpa lampu harga sesuai DEC-007e.
- **Dampak:** default Q-11 lama yang memusatkan transaksi hanya di Jawa Timur tidak digunakan sebagai batas layanan. Pemilihan wilayah tawaran, profil dan katalog perlu mendukung seluruh provinsi pada data referensi wilayah yang digunakan. Cakupan transaksi nasional tidak berarti semua wilayah sudah memiliki data harga, keluaran AI, mitra, atau hasil validasi pengguna. Semua transaksi tetap simulasi sesuai DEC-004.
- **Sumber:** pilihan B pada pertanyaan DEC-009c; DEC-007e; AUD-011; Q-11 lama.

### DEC-010a — Login petani dan pembeli menggunakan nomor HP dan OTP

- **Status:** terkonfirmasi untuk metode login; kanal pengiriman, penyedia dan detail operasional OTP belum ditentukan.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — petani dan pembeli masuk menggunakan nomor HP dan kode OTP, tanpa kata sandi untuk alur ini.
- **Dampak:** autentikasi membutuhkan layanan pengiriman kode dan mekanisme verifikasi. Jangan menganggap kanal SMS/WhatsApp atau penyedia tertentu sudah dipilih. Keputusan ini tidak mengesahkan OTP statis sebagai autentikasi pengguna sebenarnya. Metode login Admin serta visibilitas nomor HP kepada pihak lain belum diputuskan oleh butir ini.
- **Sumber:** pilihan A pada pertanyaan DEC-010a; AUD-014; Q-03 lama.

### DEC-010b — Kontak saling terlihat setelah kontrak Disetujui

- **Status:** terkonfirmasi untuk pembukaan kontak antar pelaku; kebijakan akses Admin dan penyimpanan data dibahas terpisah.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — nomor HP petani dan pembeli baru dapat saling dilihat setelah kontrak Disetujui.
- **Aturan:** nomor hanya terlihat oleh kedua pihak dalam kontrak terkait. Nomor tidak dipublikasikan melalui katalog atau dibuka kepada pihak lawan saat pesanan masih menunggu kesepakatan.
- **Dampak:** otorisasi kontak harus memeriksa hubungan pengguna dengan kontrak, bukan sekadar status login atau peran. Nomor pada profil autentikasi tidak otomatis menjadi informasi publik. Keputusan ini menetapkan saat pembukaan kontak; penanganan visibilitas setelah pembatalan, penghapusan akun dan kebutuhan akses Admin masih perlu dirinci dalam kebijakan data. Menyembunyikan kembali nomor tidak menjamin pihak yang sudah melihatnya dapat melupakan atau menghapus salinannya.
- **Sumber:** pilihan A pada pertanyaan DEC-010b; DEC-005g; AUD-015.

### DEC-010c — Notifikasi di dalam aplikasi

- **Status:** terkonfirmasi untuk kanal dan penerima notifikasi transaksi.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — notifikasi petani dan pembeli dikirim di dalam aplikasi saja.
- **Aturan:** pusat notifikasi menampilkan peristiwa pesanan, tawaran balik, persetujuan, pembatalan, kedaluwarsa dan konfirmasi selesai kepada pihak yang relevan. Tidak ada kewajiban pengiriman notifikasi transaksi melalui WhatsApp atau SMS pada MVP final.
- **Dampak:** notifikasi perlu terkait objek transaksi serta dibatasi kepada penerima yang berhak. Kebutuhan notifikasi berlaku bagi petani dan pembeli, memperbaiki draf FR yang hanya menyebut petani. Kanal pengiriman OTP tetap terpisah dan belum dipilih oleh keputusan ini. Peringatan dini lonjakan otomatis tetap terpisah sebagai lingkup inkubasi, bukan otomatis ditambahkan oleh daftar peristiwa transaksi.
- **Sumber:** pilihan A pada pertanyaan DEC-010c; DEC-002; AUD-013; Q-09 lama.

### DEC-003a — Admin operasional tanpa kewenangan bertindak atas kontrak

- **Status:** terkonfirmasi untuk batas intervensi kontrak; rincian visibilitas data pribadi dan login Admin masih perlu dirinci.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — Admin mengelola operasional dan memantau transaksi tanpa mengambil tindakan kontrak atas nama pengguna.
- **Aturan:** Admin mengelola data harga, parameter, pengguna, moderasi tawaran dan log audit. Admin tidak boleh menawar, menyetujui, membatalkan atau menyelesaikan kontrak atas nama pengguna; tidak memiliki kewenangan pembatalan kontrak bermasalah yang ditawarkan pada pilihan B.
- **Dampak:** moderasi tawaran atau pengelolaan akun tidak boleh diperlakukan sebagai izin terselubung untuk mengubah kesepakatan/status kontrak. Pemantauan kontrak tidak otomatis memberikan akses tanpa batas pada nomor HP atau data pribadi. Aksi administratif dan perubahan parameter harus dapat diaudit. Akses baca serta konsekuensi moderasi terhadap tawaran/pesanan aktif perlu dijelaskan pada matriks izin dan aturan status.
- **Sumber:** pilihan A pada pertanyaan DEC-003a; DEC-003; AUD-002, AUD-015.

### DEC-002a — Seluruh fitur MVP final gratis

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — seluruh fitur MVP final dapat digunakan tanpa pembayaran.
- **Aturan:** transaksi tetap tanpa komisi; akses fitur MVP tidak memerlukan langganan berbayar. Langganan produsen dan API berbayar dicatat sebagai rencana hilirisasi, bukan gerbang akses atau mekanisme penagihan MVP final.
- **Dampak:** tidak membangun alur aktivasi pelanggan berbayar atau pembayaran langganan sebagai kebutuhan final. Perbedaan hak akses tetap mengikuti peran dan kepemilikan data, bukan status pembayaran. Gratis untuk pengguna tidak berarti layanan operasional seperti OTP atau hosting tidak memiliki biaya.
- **Sumber:** pilihan A pada pertanyaan DEC-002a; DEC-002; proposal §3/A.10; AUD-016.

### DEC-011a — Arah visual baru, format tetap mengikuti contoh

- **Status:** terkonfirmasi untuk pendekatan; karakter visual, palet, font dan rincian komponen masih terbuka.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “C, namun tetap dengan format seperti contoh referensi”.
- **Aturan:** tentukan arah visual baru untuk SAMBUNG. UI Guidelines tetap disusun mengikuti format `docs/ui_reference/contoh-ui-guidelines.md`, termasuk urutan dan tujuan delapan bagian utama yang dipetakan pada rencana.
- **Dampak:** arah “Papan Harga Pasar”, palet kertas hangat/biru tinta dan font Atkinson Hyperlegible Next/Source Serif 4 pada draf lama tidak otomatis menjadi identitas final. Pilihan ini juga tidak mengadopsi palet, font, domain atau aturan bisnis Jagains. Karakter visual baru akan dibahas sebelum nilai token dan rincian UI ditetapkan pada fase3. Aturan fungsional yang telah disepakati, seperti arti lampu harga, tetap menjadi batas desain.
- **Sumber:** pilihan C beserta catatan pengguna pada pertanyaan DEC-011a; SRC-05; AUD-020–022, AUD-031.

### DEC-011b — Layanan pertanian modern dengan palet referensi pengguna

- **Status:** terkonfirmasi untuk karakter dan palet dasar; peran warna, font dan token semantik masih perlu dirinci.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A, colornya seperti di gambar yak”, disertai gambar referensi warna.
- **Karakter:** layanan pertanian modern: bersih, ramah, tombol besar, bahasa sederhana, harga serta tindakan utama mudah ditemukan.
- **Palet dasar:** mengikuti kode heksadesimal yang tertulis pada gambar, bukan mengambil sampel piksel foto: Forest Green `#3E5A3A`, Olive Green `#8A9A3A`, Sunflower Yellow `#FFD55A`, Honey Gold `#F4A62A`, Terracotta `#C86B3C`, Warm Cream `#FFF3D6`.
- **Referensi tersimpan:** [sambung-color-reference.png](../ui_reference/sambung-color-reference.png), disalin utuh dari lampiran pengguna agar tidak bergantung pada berkas sementara.
- **Dampak:** palet biru tinta draf lama tidak menjadi identitas final. Format delapan bagian contoh tetap dipertahankan sesuai DEC-011a. Pilihan palet tidak berarti foto, bunga matahari, simbol atau tulisan pada gambar diadopsi sebagai logo/konten SAMBUNG. Warna teks, status, grafik, fokus dan pasangan kontras akan ditetapkan serta diverifikasi pada fase3; tidak semua warna palet harus dipakai bersamaan pada satu layar. Aturan lama yang mencadangkan seluruh hijau hanya untuk lampu perlu diselaraskan dengan pilihan warna merek ini, tanpa mengubah makna lampu harga yang sudah disepakati.
- **Sumber:** pilihan A beserta lampiran pengguna pada pertanyaan DEC-011b; DEC-011a; AUD-020 dan AUD-031.

### DEC-011c — Forest Green sebagai warna utama

- **Status:** terkonfirmasi untuk peran warna dasar; pasangan teks, varian dan kontras masih perlu diverifikasi pada fase3.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — Forest Green `#3E5A3A` menjadi warna utama SAMBUNG.
- **Aturan:** Forest Green digunakan untuk tombol utama dan navigasi aktif; Warm Cream `#FFF3D6` menjadi latar, dengan kuning/emas dari palet DEC-011b sebagai aksen. Warna lampu harga dibedakan melalui token, ikon dan teks status.
- **Dampak:** tidak menggunakan Sunflower Yellow atau Olive Green sebagai warna utama berdasarkan pilihan alternatif yang tidak dipilih. Nilai palet merupakan dasar identitas; pasangan foreground/background, permukaan, hover/fokus, grafik dan status perlu disusun serta diperiksa kontrasnya pada fase3. Hijau merek tidak boleh membuat tombol utama terbaca sebagai penilaian harga hijau.
- **Sumber:** pilihan A pada pertanyaan DEC-011c; DEC-011a/b; AUD-020, AUD-031.

### DEC-011d — Plus Jakarta Sans dan Atkinson Hyperlegible Next

- **Status:** terkonfirmasi untuk pilihan font; ukuran, bobot, pemuatan dan fallback akan dirinci pada fase3.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “C” — Plus Jakarta Sans untuk judul, Atkinson Hyperlegible Next untuk isi dan kontrol.
- **Aturan:** tampilan angka harga menggunakan angka tabular agar mudah dibandingkan.
- **Dampak:** Source Serif 4 dari draf lama dan Inter dari contoh referensi tidak menjadi font utama berdasarkan keputusan ini. Skala tipografi tetap mengikuti struktur tabel pada format referensi, dengan nilai responsif, keterbacaan, font numerik serta dukungan tabular diverifikasi saat menyusun guideline. Lisensi, berkas font, pemuatan dan fallback harus diperiksa sebelum klaim kesiapan implementasi.
- **Sumber:** pilihan C pada pertanyaan DEC-011d; DEC-011a/b/c; AUD-017, AUD-021, AUD-022, AUD-031.

### DEC-011e — Mode terang dan gelap

- **Status:** terkonfirmasi untuk dukungan mode; nilai token dan perilaku pilihan awal akan dirinci pada fase3.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “B” — MVP final mendukung mode terang dan gelap, dan pengguna dapat memilih mode.
- **Aturan:** UI Guidelines menyediakan token serta pasangan kontras untuk kedua mode. Identitas palet DEC-011b/c dipertahankan melalui adaptasi peran warna; Warm Cream sebagai latar mode terang tidak berarti latar mode gelap juga harus terang.
- **Dampak:** cakupan komponen, grafik, peta, status harga, fokus dan keadaan interaksi harus diperiksa pada kedua mode. Keputusan ini tidak membuktikan kontras telah lolos; nilai turunan perlu dihitung dan diverifikasi pada fase3. Penyimpanan preferensi, mode awal dan penggunaan preferensi sistem masih rincian implementasi yang harus ditulis eksplisit sebelum diterapkan.
- **Sumber:** pilihan B pada pertanyaan DEC-011e; DEC-011b/c; AUD-017 dan AUD-031.

### DEC-007f — Batas rentang dari persentil rasio historis

- **Status:** terkonfirmasi untuk metode pembentukan batas; dataset, rendemen, periode kalibrasi dan kriteria kecukupan masih memerlukan bukti.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — batas bawah/atas menggunakan persentil ke-10 dan ke-90 dari rasio historis valid, dibedakan menurut GKP/GKG dan wilayah.
- **Definisi:** untuk jenis gabah g dan wilayah w, rasio historis q = harga gabah pengamatan / (harga beras produsen × rendemen g), dengan observasi yang diselaraskan periode, satuan dan kualitas datanya. Batas bawah L = harga beras produsen saat acuan × rendemen g × P10(q); batas atas U memakai P90(q). Nilai rendemen dan dataset tidak diasumsikan tersedia hanya karena metode telah dipilih.
- **Aturan:** rentang mengikuti sebaran data historis yang valid; jika data belum cukup, acuan dinyatakan belum tersedia sesuai DEC-007e. Faktor tetap 93–97% pada contoh lama tidak otomatis menjadi batas untuk semua jenis gabah atau wilayah.
- **Dampak:** dokumentasikan sumber, periode, ukuran sampel, parameter/versi dan penyelarasan data. Rentang P10–P90 rasio historis tidak otomatis membuktikan cakupan 80% atas harga gabah masa depan; evaluasi estimator dan interval prakiraan dipisahkan. Kriteria kecukupan, penanganan outlier serta kalibrasi memerlukan pemeriksaan dataset yang belum tersedia dalam workspace audit.
- **Sumber:** pilihan A pada pertanyaan DEC-007f; DEC-007a/b/e; AUD-007, AUD-028.

### DEC-012a — Target uji kegunaan minimal lima responden dan SUS 68

- **Status:** terkonfirmasi sebagai target proyek; pelaksanaan serta hasil pengujian belum tersedia.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — minimal lima responden yang mewakili petani dan pembeli, dengan target skor SUS ≥68.
- **Aturan:** hasil aktual dilaporkan apa adanya. Jumlah minimum berlaku untuk total responden, dengan keterwakilan kedua kelompok; bukan lima responden untuk masing-masing kelompok.
- **Dampak:** rencana uji harus mencatat profil/peran responden, tugas yang diberikan, hasil tugas, jawaban kuesioner dan cara perhitungan skor. Skor 68 adalah ambang target yang disepakati proyek, bukan klaim hasil uji atau kepatuhan universal. Jika target tidak tercapai, laporkan selisih dan perbaikan yang diperlukan tanpa mengubah hasil atau mengklaim lulus. Pengujian alur normal hingga Selesai mengikuti DEC-005k; kelengkapan skenario dirinci pada fase2.
- **Sumber:** pilihan A pada pertanyaan DEC-012a; proposal §4.3/A.2; Q-15 lama; AUD-017, AUD-019.

### DEC-010d — Ekspor CSV ringkasan harga dan pasokan

- **Status:** terkonfirmasi untuk format dan lingkup isi; kolom serta izin unduhan per peran dirinci pada fase2.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — MVP menyediakan CSV ringkasan harga dan pasokan.
- **Aturan:** ekspor harga hanya memuat data publik; ringkasan pasokan tidak menyertakan nomor HP atau data pribadi.
- **Dampak:** tentukan daftar kolom yang diizinkan secara eksplisit, beserta satuan, periode, wilayah dan label sumber/estimasi yang relevan. Izin unduhan tidak otomatis membuka akses ke data yang tidak boleh dilihat di aplikasi; pembatasan peran/kepemilikan tetap berlaku. Jangan menambahkan kolom pribadi, identitas kontak atau rincian kontrak ke CSV hanya karena tersedia di basis data. Format CSV tidak berarti API berbayar diaktifkan pada MVP.
- **Sumber:** pilihan A pada pertanyaan DEC-010d; DEC-002a, DEC-010b; AUD-010, AUD-015, AUD-016; Q-13 lama.

### DEC-010e — Login Admin terpisah dengan email dan kata sandi

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — Admin masuk melalui halaman Admin terpisah menggunakan email dan kata sandi.
- **Aturan:** akun Admin dibuat oleh pengelola dan tidak memiliki pendaftaran publik. Metode ini terpisah dari login nomor HP dan OTP bagi petani/pembeli pada DEC-010a.
- **Dampak:** pendaftaran pengguna biasa tidak boleh menyediakan pilihan untuk memperoleh peran Admin. Otorisasi fungsi Admin tetap mengikuti DEC-003a; halaman login terpisah tidak menggantikan pemeriksaan izin pada server. Pengelolaan kredensial dan pemulihan akses dirinci sebagai kebutuhan keamanan pada fase2.
- **Sumber:** pilihan A pada pertanyaan DEC-010e; DEC-003a dan DEC-010a; AUD-014.

### DEC-003b — Katalog memerlukan login

- **Status:** terkonfirmasi untuk batas akses publik; aksi tiap peran tetap mengikuti matriks izin.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “B” — katalog hanya dapat dilihat pengguna yang sudah login.
- **Aturan:** katalog dan detail tawaran tidak dibuka untuk publik tanpa login. Informasi publik mencakup papan harga, peta, prakiraan dan bantuan. Mengajukan pesanan tetap memerlukan peran pembeli; akses baca tidak otomatis memberi hak memesan.
- **Dampak:** tautan langsung, pencarian, unduhan pasokan dan respons data katalog harus mematuhi batas autentikasi, bukan hanya menyembunyikan menu. Ekspor pasokan DEC-010d tidak boleh menjadi jalur publik untuk melewati batas katalog. Nomor HP tetap mengikuti pembatasan kontak DEC-010b meskipun pengguna sudah login. Hak baca katalog lintas peran dibedakan dari pengelolaan tawaran sendiri dan pemantauan Admin.
- **Sumber:** pilihan B pada pertanyaan DEC-003b; DEC-003, DEC-010b/d; AUD-002, AUD-033.

### DEC-003c — Satu peran per akun

- **Status:** terkonfirmasi untuk peran akun pengguna biasa.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — satu akun memiliki satu peran, dipilih saat mendaftar: petani/kelompok tani atau penggilingan/pengolah.
- **Aturan:** tidak menyediakan pergantian ruang kerja penjual/pembeli dalam satu akun pada MVP final. Hak akses dan navigasi mengikuti peran akun tersebut. Peran Admin tetap diberikan oleh pengelola melalui mekanisme terpisah DEC-010e.
- **Dampak:** login tidak menjadi kesempatan memilih peran lain untuk memperoleh izin tambahan. Keputusan ini tidak otomatis menentukan prosedur koreksi peran atau mengizinkan pembuatan akun ganda dengan nomor HP yang sama; rincian pengelolaan identitas harus dinyatakan pada SRS tanpa memperluas hak transaksi yang sudah dipilih.
- **Sumber:** pilihan A pada pertanyaan DEC-003c; DEC-003, DEC-003b, DEC-010a/e; AUD-002.

### DEC-010f — Lokasi tawaran sampai kecamatan

- **Status:** terkonfirmasi untuk rincian lokasi yang ditampilkan pada tawaran.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — lokasi petani pada tawaran ditampilkan sampai kecamatan, beserta kabupaten/kota dan provinsi.
- **Aturan:** alamat lengkap atau titik rumah tidak ditampilkan pada tawaran. Keputusan ini tidak membuka detail tambahan setelah kontrak Disetujui; pilihan C tidak dipilih. Kontak kedua pihak tetap mengikuti DEC-010b.
- **Dampak:** tampilan katalog/detail, pencarian/filter dan ekspor harus menjaga tingkat rincian lokasi ini serta batas autentikasi DEC-003b. Jangan mengasumsikan fitur urut terdekat membutuhkan koordinat rumah; bila ada perbandingan kedekatan wilayah, sifat perkiraannya perlu dijelaskan. Tidak ada kewajiban mengambil lokasi GPS rumah berdasarkan keputusan ini.
- **Sumber:** pilihan A pada pertanyaan DEC-010f; AUD-015; Q-03 lama.

### DEC-011f — shadcn/ui dan Tailwind CSS v4

- **Status:** terkonfirmasi sebagai pilihan untuk UI Guidelines dan implementasi berikutnya; bukan klaim stack sudah terpasang.
- **Pemberi keputusan:** pengguna, melalui chat ini pada 6 November 2026.
- **Jawaban:** “A” — UI Guidelines mengikat penggunaan shadcn/ui dan Tailwind CSS v4.
- **Aturan:** guideline memuat token, varian komponen dan contoh penerapan sesuai format referensi, memakai identitas SAMBUNG yang dipilih pada DEC-011a–e.
- **Dampak:** pilihan pustaka tidak otomatis mengadopsi domain, warna, font, atau nilai aksesibilitas bermasalah pada contoh Jagains. Basis komponen, versi paket, API yang dipakai dan dependensi perlu diperiksa pada implementasi; kode aplikasi belum tersedia dalam sumber audit. Bagian implementasi CSS merupakan spesifikasi penerapan, bukan laporan perubahan pada app.css yang sudah ada.
- **Sumber:** pilihan A pada pertanyaan DEC-011f; DEC-011a–e; AUD-029, AUD-031.

### Konfirmasi draf fase 2 — pembahasan poin terbuka

- **Status:** SRS dan IA v0.1 diterima sebagai draf untuk melanjutkan klarifikasi, bukan baseline final tanpa pertanyaan terbuka.
- **Pemberi konfirmasi:** pengguna melalui jawaban “A” pada pilihan “Sesuai sebagai draf — lanjut membahas poin terbuka”.
- **Dampak:** lanjutkan pembahasan OPN pada SRS §7 satu per satu dengan pilihan jawaban di chat. Usulan OPN belum otomatis disetujui; bukti dataset/model tetap memerlukan validasi teknis. Fase 3 belum dimulai.

### DEC-013a — Perubahan harga dan volume tawaran aktif (OPN-003a)

- **Status:** terkonfirmasi untuk perubahan harga/volume; tarik tawaran, perubahan jenis/lokasi dan moderasi masih terbuka.
- **Pemberi keputusan:** pengguna melalui jawaban “A” pada pertanyaan OPN-003a.
- **Aturan:** petani boleh mengubah harga dan volume total tawaran untuk pesanan berikutnya saja. Harga dan volume setiap pesanan/kontrak yang sudah ada tetap, termasuk yang masih Menunggu Kesepakatan. Volume total baru tidak boleh lebih kecil dari jumlah volume yang sedang dicadangkan, Disetujui dan Selesai.
- **Dampak:** validasi perubahan volume dan pengajuan pesanan yang bersamaan harus menjaga batas volume secara atomik. Perubahan harga tawaran panen bukan tawaran harga baru pada kontrak aktif dan tidak mengubah tenggatnya. Pemeriksaan harga/konfirmasi merah tetap berlaku pada perubahan harga yang akan dipublikasikan.
- **Sumber:** pilihan A pada OPN-003a; DEC-005a/b/e/g dan DEC-006a; SRS BR-003/004.

### DEC-013b — Penarikan tawaran membatalkan pesanan Menunggu (OPN-003b)

- **Status:** terkonfirmasi untuk penarikan oleh petani pemilik; moderasi Admin dan perubahan jenis/lokasi masih terbuka.
- **Pemberi keputusan:** pengguna melalui jawaban “B” pada pertanyaan OPN-003b.
- **Aturan:** petani dapat menarik tawaran dari katalog. Pesanan terkait yang masih Menunggu Kesepakatan otomatis menjadi Dibatalkan, pembeli menerima notifikasi dan reservasi volumenya dilepas. Kontrak yang sudah Disetujui tetap berjalan sampai diakhiri/diselesaikan menurut aturan sebelumnya; kontrak terminal tidak diubah.
- **Dampak:** penarikan menghentikan pesanan baru. Volume yang dilepas kembali tercatat sebagai tidak terikat pada tawaran, tetapi tawaran Ditarik tidak dapat dipesan; pelepasan tidak menerbitkan ulang tawaran. Catat pemilik yang menarik, waktu dan alasan otomatis “Tawaran ditarik oleh petani”, dengan referensi peristiwa penarikan pada setiap pembatalan. Efek otomatis bukan kewenangan Admin membatalkan kontrak. Pemeriksaan tenggat tetap didahulukan: pesanan yang sudah melewati tenggat menjadi Kedaluwarsa, bukan dibatalkan ulang. Aksi penarikan/pemesanan/penerimaan yang bersamaan harus menghasilkan status dan volume yang konsisten.
- **Sumber:** pilihan B pada OPN-003b; DEC-005b/c/h/i; SRS BR-003/005.

### DEC-013c — Admin hanya menandai dan meminta tindak lanjut (OPN-003c)

- **Status:** terkonfirmasi untuk moderasi tawaran; pengelolaan akun dan perubahan jenis/lokasi masih terbuka.
- **Pemberi keputusan:** pengguna melalui jawaban “B” pada pertanyaan OPN-003c.
- **Aturan:** Admin hanya menandai masalah dan meminta petani memperbaiki atau menarik tawaran. Tawaran tetap terlihat sampai petani menindaklanjuti. Admin tidak menyembunyikan tawaran, menghentikan pesanan baru, atau membatalkan kontrak melalui aksi moderasi ini.
- **Dampak:** simpan masalah yang ditandai, permintaan tindak lanjut, pelaku dan waktu, lalu sampaikan kepada petani melalui notifikasi aplikasi. Status penandaan bukan status Ditarik dan tidak mengubah volume atau status kontrak. Jika petani sendiri menarik tawaran, berlaku DEC-013b, termasuk pembatalan otomatis pesanan Menunggu. Keputusan ini tidak menetapkan publikasi tanda masalah kepada pembeli atau kewenangan pembekuan akun.
- **Sumber:** pilihan B pada OPN-003c; DEC-003a dan DEC-013b; FR-021/022.

### DEC-013d — Jenis gabah dan lokasi terkunci setelah pernah menerima pesanan (OPN-003d)

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna melalui jawaban “A” pada pertanyaan OPN-003d.
- **Aturan:** setelah tawaran pernah menerima pesanan, jenis gabah dan lokasinya tidak boleh diubah. Perubahan GKP↔GKG atau lokasi harus dibuat sebagai tawaran baru. Harga dan volume total tetap dapat diubah mengikuti DEC-013a.
- **Dampak:** penguncian berlaku berdasarkan riwayat pernah menerima pesanan yang berhasil dibuat, bukan hanya ada kontrak aktif; pesanan yang kemudian ditolak, dibatalkan, kedaluwarsa atau selesai tidak membuka kunci. Lokasi mengikuti hierarki provinsi/kabupaten-kota/kecamatan pada tawaran. Pengecekan perubahan dan pengajuan pesanan bersamaan harus konsisten. Pembuatan tawaran baru tidak memindahkan, menyalin atau membatalkan pesanan lama secara otomatis; sisa pasokan perlu dikelola pemilik tanpa dianggap sebagai volume tambahan yang terverifikasi.
- **Sumber:** pilihan A pada OPN-003d; DEC-007a, DEC-010f dan DEC-013a/b; FR-004.

### DEC-013e — Tawaran Ditarik tidak dapat diterbitkan kembali (OPN-003e)

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna melalui jawaban “B” pada pertanyaan OPN-003e.
- **Aturan:** tawaran yang sudah Ditarik tidak boleh diterbitkan kembali. Untuk menawarkan sisa panen, petani membuat tawaran baru dengan identitas baru.
- **Dampak:** riwayat dan pesanan lama tetap terkait tawaran asal; tidak disalin, dipindahkan atau diaktifkan kembali. Kontrak Disetujui pada tawaran asal tetap berjalan sesuai DEC-013b. Tawaran baru tidak otomatis menambah atau melepaskan volume pada kontrak lama; pemilik harus mengisi sisa pasokan yang belum terikat. Larangan penerbitan ulang berlaku walaupun tidak ada kontrak aktif atau semua kontrak telah terminal.
- **Sumber:** pilihan B pada OPN-003e; DEC-013b/d; FR-004.

### DEC-013f — Penanda masalah terlihat oleh pembeli (OPN-003f)

- **Status:** terkonfirmasi untuk keterlihatan penanda; prosedur penutupan temuan moderasi masih perlu dirinci.
- **Pemberi keputusan:** pengguna melalui jawaban “B” pada pertanyaan OPN-003f.
- **Aturan:** selain Admin dan petani pemilik, pembeli dapat melihat penanda “Sedang diminta perbaikan” beserta ringkasan masalah tanpa data pribadi. Tawaran tetap dapat dipesan sesuai ketersediaan volume dan aturan sebelumnya.
- **Dampak:** penanda tampil pada katalog dan detail tawaran bagi pembeli yang sudah login, tanpa membuka katalog kepada publik. Ringkasan yang ditampilkan kepada pembeli dibedakan dari catatan internal dan tidak memuat nomor HP, alamat rinci atau data pribadi. Penanda moderasi bukan lampu harga dan tidak menyatakan harga merah atau mutu telah terverifikasi. Penanda tidak mengubah status kontrak, volume, tenggat, maupun kewenangan Admin; DEC-013c tetap berlaku.
- **Sumber:** pilihan B pada OPN-003f; DEC-003b, DEC-013c; FR-006/021.

### DEC-013g — Admin menutup temuan setelah meninjau perbaikan (OPN-003g)

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna melalui jawaban “A” pada pertanyaan OPN-003g.
- **Aturan:** petani dapat menandai “Sudah diperbaiki”. Temuan kemudian menunggu peninjauan Admin; penanda tetap terlihat sampai Admin menutup temuan. Riwayat temuan dan tindak lanjut tetap tersimpan.
- **Dampak:** alur temuan adalah Terbuka → Menunggu Peninjauan → Ditutup. Petani tidak dapat menutup temuan sendiri; penandaan sudah diperbaiki tidak menghilangkan penanda secara otomatis. Penutupan hanya mengakhiri temuan yang ditinjau; jika masih ada temuan lain yang belum ditutup pada tawaran yang sama, penanda/ringkasan masalah terkait tetap ada. Penutupan dicatat pelaku/waktu dan tidak mengubah kontrak, volume atau status publikasi. Peninjauan hanya terkait informasi tawaran, bukan verifikasi mutu fisik gabah.
- **Sumber:** pilihan A pada OPN-003g; DEC-013c/f; FR-017/021/022.

### DEC-013h — Tanggal ketersediaan opsional (OPN-003h)

- **Status:** terkonfirmasi untuk pencatatan tanggal ketersediaan tawaran.
- **Pemberi keputusan:** pengguna melalui jawaban “B” pada pertanyaan OPN-003h.
- **Aturan:** tanggal gabah mulai siap tersedia bersifat opsional. Petani boleh memilih “Belum ditentukan”; tawaran tetap dapat diterbitkan. Pembeli dapat memastikan jadwal melalui komunikasi setelah kesepakatan.
- **Dampak:** tidak menentukan tanggal secara otomatis jika petani belum mengisinya. Tanggal ini bukan tanggal kedaluwarsa tawaran dan tidak menggantikan tenggat menunggu kesepakatan. Pilihan ini tidak menetapkan jadwal kontrak yang mengikat atau memperkenalkan perubahan otomatis pada kontrak lama.
- **Sumber:** pilihan B pada OPN-003h; FR-004; DEC-005c dan DEC-010b.

### DEC-014a — Kontak disembunyikan setelah kontrak Dibatalkan (OPN-004a)

- **Status:** terkonfirmasi untuk kontrak Dibatalkan; kontak setelah Selesai dan akses sensitif Admin masih terbuka.
- **Pemberi keputusan:** pengguna melalui jawaban “A” pada pertanyaan OPN-004a.
- **Aturan:** setelah kontrak Dibatalkan, nomor HP pihak lawan disembunyikan kembali di aplikasi untuk kontrak tersebut. Riwayat kontrak tetap ada, tetapi tidak lagi menampilkan nomor HP melalui kontrak Dibatalkan.
- **Dampak:** berlaku pada detail, respons data, bukti/cetakan yang dihasilkan setelah pembatalan, dan tampilan terkait agar bukan sekadar menyembunyikan teks di layar. Ini perubahan visibilitas, bukan keputusan menghapus seluruh akun/riwayat atau menetapkan retensi. Hak akses yang mungkin sah melalui kontrak lain dinilai terpisah; kontrak Dibatalkan tidak menjadi jalur membuka kontak. Salinan yang sebelumnya dicatat pihak lain tidak dapat ditarik kembali oleh perubahan tampilan ini.
- **Sumber:** pilihan A pada OPN-004a; DEC-010b dan DEC-005i; FR-026/027, BR-018.

### DEC-014b — Kontak disembunyikan setelah kontrak Selesai (OPN-004b)

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna melalui jawaban “A” pada pertanyaan OPN-004b.
- **Aturan:** nomor HP pihak lawan hanya ditampilkan melalui kontrak yang saat itu berstatus Disetujui dan belum berakhir. Setelah Selesai, kontak disembunyikan kembali; riwayat transaksi tetap ada. Ini melengkapi penyembunyian setelah Dibatalkan pada DEC-014a.
- **Dampak:** satu konfirmasi selesai masih berstatus Disetujui sehingga akses kontak tetap mengikuti status tersebut; dua konfirmasi mengubah status menjadi Selesai dan menutup akses kontak melalui kontrak itu. Berlaku pada detail, respons dan bukti baru, bukan sekadar teks layar. Kontrak lain dinilai terpisah menurut hak/statusnya; salinan kontak yang sudah dicatat tidak dapat ditarik kembali. Bukan keputusan menghapus akun atau menetapkan retensi.
- **Sumber:** pilihan A pada OPN-004b; DEC-005h, DEC-010b dan DEC-014a; FR-026/027, BR-018.

### DEC-014c — Nomor HP tersamar pada panel Admin (OPN-004c)

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna melalui jawaban “A” pada pertanyaan OPN-004c.
- **Aturan:** Admin tidak dapat melihat nomor HP lengkap melalui panel Admin. Nomor ditampilkan tersamar; pemantauan akun dan transaksi menggunakan identitas akun.
- **Dampak:** tidak menyediakan tombol buka nomor lengkap dengan alasan pada panel karena pilihan B tidak dipilih. Pembatasan berlaku pada respons data, pencarian/detail akun, pemantauan kontrak, log, unduhan dan bukti yang diakses sebagai Admin; menyamarkan teks saja tidak cukup jika nilai lengkap masih dikirim. Identitas akun tetap dapat dipakai menelusuri peristiwa tanpa membuka kontak. Keputusan ini mengatur akses aplikasi Admin, bukan mengklaim nomor tidak pernah diproses untuk OTP atau menetapkan kewenangan akses infrastruktur/retensi yang belum dibahas. Hak pihak kontrak tetap terpisah menurut DEC-014a/b.
- **Sumber:** pilihan A pada OPN-004c; DEC-003a, DEC-010a/b dan DEC-014a/b; FR-021/026/027/028.

### DEC-014d — Penutupan akun menunggu transaksi aktif berakhir (OPN-004d)

- **Status:** terkonfirmasi untuk urutan penutupan akses; kebijakan retensi/penghapusan data pada saat keputusan ini dibuat masih terbuka dan kemudian dilengkapi DEC-014f.
- **Pemberi keputusan:** pengguna melalui jawaban “A” pada pertanyaan OPN-004d.
- **Aturan:** jika masih ada pesanan atau kontrak aktif, permintaan penutupan akun dicatat dan diproses setelah seluruh transaksi aktif berakhir. Pengguna tetap dapat mengakses akun untuk menyelesaikan atau membatalkan transaksinya menurut izin peran/status yang sudah disepakati.
- **Dampak:** Menunggu Kesepakatan dan Disetujui (termasuk satu konfirmasi selesai) dihitung sebagai aktif; Ditolak, Dibatalkan, Kedaluwarsa dan Selesai tidak aktif. Permintaan tidak otomatis membatalkan kontrak, melepas volume atau memberikan Admin kewenangan transaksi. Pemeriksaan ketiadaan transaksi aktif harus konsisten dengan aksi transaksi bersamaan agar penutupan tidak meninggalkan kontrak tanpa akses pihaknya. Kebijakan pesanan/tawaran baru selama permintaan tertunda kemudian ditetapkan pada DEC-014e. Keputusan ini menutup akses akun, bukan menghapus seluruh riwayat secara otomatis atau menyatakan kepatuhan hukum.
- **Sumber:** pilihan A pada OPN-004d; DEC-003a, DEC-005h/i/j; FR-021/027, OPN-004/010.

### DEC-014e — Tidak ada transaksi baru selama penutupan akun tertunda (OPN-004e)

- **Status:** terkonfirmasi.
- **Pemberi keputusan:** pengguna melalui jawaban “A” pada pertanyaan OPN-004e.
- **Aturan:** selama permintaan penutupan akun menunggu transaksi aktif berakhir, pengguna tidak boleh membuat tawaran atau pesanan baru. Tawaran milik akun tersebut tidak menerima pesanan baru. Transaksi yang sudah ada tetap dapat ditindaklanjuti menurut peran/statusnya.
- **Dampak:** larangan mencakup penerbitan draf menjadi tawaran baru dan pengajuan pesanan lewat respons/API, bukan hanya tombol layar. Validasi pesanan memeriksa status pemohon dan pemilik tawaran secara atomik terhadap permintaan penutupan. Larangan ini tidak mengubah publikasi tawaran menjadi Ditarik dan tidak otomatis membatalkan pesanan Menunggu atau kontrak Disetujui; tenggat, negosiasi, penerimaan dan penyelesaian transaksi lama tetap sesuai aturan. Status akun penutupan tertunda dipisahkan dari status publikasi/volume tawaran. Pesan kepada pembeli dapat menyatakan tawaran tidak menerima pesanan baru tanpa mengungkap rincian pribadi pemilik.
- **Sumber:** pilihan A pada OPN-004e; DEC-014d, DEC-013b dan DEC-005b/c; FR-004/007/027.

### DEC-014f — Penghapusan data pribadi dan anonimisasi riwayat saat penutupan (OPN-004f)

- **Status:** terkonfirmasi sebagai kebijakan produk; bukti pelaksanaan anonimisasi dan penghapusan tetap diperlukan.
- **Pemberi keputusan:** pengguna melalui jawaban “A” pada pertanyaan OPN-004f.
- **Aturan:** setelah penutupan akun dapat diproses sesuai DEC-014d/e, hapus data kontak/profil pribadi dan anonimkan identitas pada riwayat. Data transaksi nonpribadi seperti jenis gabah, volume, harga, waktu dan status tetap disimpan. Pilihan menyimpan data pribadi selama masa retensi tambahan tidak dipilih.
- **Dampak:** kebijakan berlaku pada profil dan salinan data pribadi yang mungkin ada pada kontrak, temuan/notifikasi, audit, berkas ekspor/bukti tersimpan, indeks/cache dan data terkait. Pemeliharaan riwayat pihak lain tidak menjadi alasan menampilkan kembali identitas/kontak akun tertutup. Mengganti nama dengan ID yang masih dapat ditautkan ke profil bukan bukti anonimisasi; pastikan data yang dipertahankan benar-benar nonpribadi, termasuk menilai teks bebas dan kombinasi atribut. Rincian pemrosesan cadangan/provider, waktu penyelesaian teknis dan periode simpan data nonpribadi perlu dirancang/divalidasi; keputusan ini bukan klaim penghapusan sudah berjalan, pemenuhan hukum sudah terbukti, atau dapat menarik salinan yang telah diunduh pihak lain.
- **Sumber:** pilihan A pada OPN-004f; DEC-014a–e; FR-002/021/022/026/027 dan NFR-002/010.

### DEC-014g — Persetujuan eksplisit saat pendaftaran (OPN-004g)

- **Status:** terkonfirmasi untuk perilaku pendaftaran; isi kebijakan dan peninjauan hukumnya tetap memerlukan validasi.
- **Pemberi keputusan:** pengguna melalui jawaban “A” pada pertanyaan OPN-004g.
- **Aturan:** sebelum akun pengguna baru dibuat, ketentuan layanan dan pemberitahuan pemrosesan data tersedia untuk dibaca dan pengguna memberikan persetujuan eksplisit. Kotak persetujuan tidak dicentang otomatis. Catat versi dokumen yang disetujui dan waktu persetujuan.
- **Dampak:** penolakan atau tidak mengisi persetujuan menghentikan penyelesaian pendaftaran; verifikasi nomor melalui OTP tidak dengan sendirinya merupakan persetujuan. Pencatatan harus terkait versi yang benar-benar ditampilkan, bukan versi terkini yang kemudian menimpa riwayat. Proses ini tidak menjadi persetujuan umum untuk tujuan pemrosesan baru atau klaim kepatuhan hukum otomatis. Kebutuhan bukti persetujuan harus diselaraskan dengan penghapusan/anonimisasi DEC-014f, tanpa diam-diam membuat masa retensi tambahan data pribadi.
- **Sumber:** pilihan A pada OPN-004g; FR-001/002; DEC-014f dan OPN-004.

### DEC-015a — Petani tidak mengakses katalog tawaran petani lain (OPN-005a)

- **Status:** terkonfirmasi untuk akses katalog; kolom/tingkat agregasi ekspor pasokan masih terbuka.
- **Pemberi keputusan:** pengguna melalui jawaban “B” pada pertanyaan OPN-005a.
- **Aturan:** katalog dan detail tawaran dalam katalog hanya untuk pembeli serta pemantauan Admin. Petani hanya melihat tawarannya sendiri dan informasi harga publik; tidak dapat membaca katalog tawaran petani lain walaupun sudah login.
- **Dampak:** hapus usulan navigasi baca katalog dari ruang kerja petani. Terapkan larangan pada halaman, tautan langsung, respons data, filter/pencarian dan ekspor pasokan petani lain; login saja tidak cukup. Petani tetap dapat membuka tawaran sendiri melalui Tawaran Saya dan detail kontrak sendiri sesuai izin, serta CSV harga publik. Keputusan ini tidak menambah ekspor data pasokan milik orang lain atau menjadikan data katalog terbuka melalui agregasi yang belum disetujui.
- **Sumber:** pilihan B pada OPN-005a; DEC-003b/c, DEC-010d; FR-006/018, AUD-033.

### DEC-015b — CSV pasokan berupa agregasi jenis gabah dan wilayah (OPN-005b)

- **Status:** terkonfirmasi untuk bentuk dan kolom inti ekspor pasokan.
- **Pemberi keputusan:** pengguna melalui jawaban “A” pada pertanyaan OPN-005b.
- **Aturan:** CSV pasokan untuk pembeli/Admin berisi ringkasan per jenis gabah dan wilayah: jumlah tawaran, total volume tersedia serta rentang harga. Tidak mengekspor baris/identitas setiap tawaran atau data pribadi penjual. Hanya data yang boleh diakses pengguna tersebut yang dihitung.
- **Dampak:** rentang merupakan minimum–maksimum harga minta dari tawaran dalam kelompok, bukan rentang harga wajar AI atau harga transaksi pengamatan. Jumlah tawaran dihitung per identitas tawaran, bukan banyaknya kontrak/versi harga. Volume merupakan tersedia setelah reservasi/kesepakatan/selesai, bukan total awal. Gunakan snapshot/filter yang konsisten dan nyatakan waktu ekspor serta satuannya. Tidak memisahkan kelompok berdasarkan nama, nomor, ID akun/tawaran, mutu individual atau tanggal individual. Periksa bahwa agregasi/teks tidak membuka data pribadi; hak petani tidak diperluas lewat agregasi sesuai DEC-015a.
- **Sumber:** pilihan A pada OPN-005b; DEC-010d, DEC-015a dan BR-003/018; FR-018.

### DEC-016a — Target ukuran dan aksesibilitas dasar (OPN-006a)

- **Status:** terkonfirmasi sebagai target proyek; belum ada hasil uji implementasi.
- **Pemberi keputusan:** pengguna melalui jawaban “B” pada pertanyaan OPN-006a.
- **Aturan:** teks isi minimal 16 px dan area sentuh minimal 44 × 44 px. Uji navigasi keyboard, zoom 200%, kontras teks normal minimal 4,5:1 serta indikator fokus minimal 3:1.
- **Dampak:** menggantikan usulan teks isi 17 px/area sentuh 48 px pada SRS v0.1. Kedua mode terang/gelap mengikuti target yang sama dan status tetap dibedakan lewat ikon/teks. Batas ini untuk teks isi/target interaksi, bukan memaksa seluruh judul, metadata dan angka memakai satu ukuran. Skala rinci dan nilai token tetap fase 3; angka target tidak menjadi klaim aksesibilitas sudah lulus atau kepatuhan menyeluruh.
- **Sumber:** pilihan B pada OPN-006a; DEC-011d/e/f; NFR-008 dan AC-035.

### DEC-016b — Target halaman utama siap digunakan maksimal lima detik (OPN-006b)

- **Status:** terkonfirmasi sebagai target proyek; protokol rinci dan hasil pengujian belum tersedia.
- **Pemberi keputusan:** pengguna melalui jawaban “B” pada pertanyaan OPN-006b.
- **Aturan:** halaman utama ditargetkan siap digunakan dalam maksimal 5 detik. “Siap” berarti konten utama dan tombol tindakan utama dapat digunakan. Profil perangkat, jaringan dan data uji dicatat.
- **Dampak:** menggantikan usulan maksimal 3 detik dalam draf awal, bukan klaim hasil sudah tercapai. Protokol harus menetapkan halaman yang diuji, titik awal pengukuran, kondisi cache/muat awal, ukuran data, pengulangan dan aturan agregasi sebelum memberi kesimpulan lulus. Konten utama/tombol yang belum tersedia tidak dianggap siap hanya karena kerangka halaman sudah muncul. Kegagalan layanan atau data AI tak tersedia harus tetap dibedakan dari hasil waktu muat yang sukses.
- **Sumber:** pilihan B pada OPN-006b; NFR-009 dan AC-036.

### DEC-018a — Batas rentang dibulatkan sebelum penilaian lampu (OPN-008a)

- **Status:** terkonfirmasi untuk pembulatan batas rentang harga wajar yang dipakai lampu.
- **Pemberi keputusan:** pengguna melalui jawaban “A” pada pertanyaan OPN-008a.
- **Aturan:** bulatkan batas bawah dan atas hasil estimator ke rupiah terdekat terlebih dahulu; pecahan 0,5 dibulatkan ke atas. Nilai operasional yang sama digunakan untuk tampilan rentang dan klasifikasi lampu. Hasil hitung asal tetap disimpan untuk penelusuran.
- **Dampak:** simpan batas asal dan batas operasional pada versi acuan/snapshot pemeriksaan; jangan menilai harga menggunakan batas asal yang tersembunyi sementara menampilkan batas berbeda. Toleransi tetap dihitung menurut BR-011 dari batas bawah operasional; parameter persentase tidak diubah oleh pembulatan ini. Jika ambang toleransi perlu ditampilkan, presisinya harus cukup untuk menjelaskan hasil. Keputusan ini tidak menetapkan pembulatan interval prakiraan, metode interpolasi kuantil, presisi masukan harga atau volume.
- **Sumber:** pilihan A pada OPN-008a; DEC-006c/d, DEC-007f; FR-005/008/014 dan OPN-008.

### DEC-018b — Harga rupiah bulat dan volume dua desimal (OPN-008b)

- **Status:** terkonfirmasi untuk presisi masukan harga per kilogram dan volume.
- **Pemberi keputusan:** pengguna melalui jawaban “A” pada pertanyaan OPN-008b.
- **Aturan:** harga per kilogram diisi dalam rupiah bulat; volume dalam kilogram boleh maksimal dua angka desimal. Contoh Rp7.000/kg dan 125,50 kg. Isian yang melebihi presisi harus diperbaiki pengguna, bukan dibulatkan diam-diam.
- **Dampak:** berlaku pada harga minta, harga awal pesanan, tawaran balik serta volume tawaran/pesanan dan perubahan volume. Harga/volume tetap positif; harga minimum yang dapat direpresentasikan Rp1/kg dan volume minimum 0,01 kg, bukan rekomendasi harga/volume komersial. Validasi yang sama berlaku di server dan perhitungan/reservasi harus mempertahankan presisi agar tidak kehilangan atau menggandakan pecahan volume. Aturan ini tidak membulatkan observasi historis, parameter rasio, hasil evaluasi model atau nilai total turunan secara diam-diam; batas acuan lampu mengikuti DEC-018a.
- **Sumber:** pilihan A pada OPN-008b; DEC-005a/b, DEC-018a; FR-004/007/009, BR-002/003/004.

### DEC-017a — Publikasi prakiraan per provinsi dan horizon (OPN-007a)

- **Status:** terkonfirmasi untuk unit pemilihan metode; protokol perhitungan/evaluasi masih perlu bukti teknis.
- **Pemberi keputusan:** pengguna melalui jawaban “A” pada pertanyaan OPN-007a.
- **Aturan:** pilih metode per provinsi dan horizon. Jika model memenuhi target akurasi serta interval pada hasil tersebut, publikasikan model; hasil lainnya memakai baseline yang telah dievaluasi atau ditandai belum tersedia. Metode yang digunakan diberi label untuk setiap keluaran.
- **Dampak:** satu provinsi dapat memakai model pada horizon2pekan dan baseline pada horizon4pekan, tanpa mengubah kelayakan wilayah/horizon lain. Catat versi, waktu terbit/cutoff, target, metrik dan alasan pemilihan; hasil agregat nasional tidak menggantikan penilaian unit yang gagal. Baseline tetap metode pembanding berlabel, tidak dianggap memenuhi target keunggulan model hanya karena telah dievaluasi. Estimasi gabah turunan mengikuti metode keluaran beras asalnya dan memerlukan parameter/evaluasi terpisah; SHAP hanya untuk model yang benar-benar dijelaskan. Tidak ada model/baseline valid berarti hasil terkait belum tersedia, bukan angka rekaan.
- **Sumber:** pilihan A pada OPN-007a; DEC-008a–d, FR-015/016/031, NFR-005.

### DEC-019a — Skala peta kontinu berpusat pada nol (OPN-009a)

- **Status:** terkonfirmasi untuk cara penyajian selisih; sumber geometri/pemetaan dan nilai token warna tetap memerlukan validasi.
- **Pemberi keputusan:** pengguna melalui jawaban “A” pada pertanyaan OPN-009a.
- **Aturan:** selisih harga terhadap median memakai skala warna kontinu dengan titik tengah0%. Bedakan arah lebih murah dan lebih mahal, tampilkan nilai persentase, dan gunakan penanda netral tersendiri untuk provinsi tanpa data.
- **Dampak:** tidak menggunakan kategori A–D lama atau lima kategori tetap beserta ambang yang belum dipilih. Nilai0% yang valid tidak boleh terlihat sama dengan data tidak tersedia; legenda menjelaskan arah, titik tengah dan jangkauan skala yang digunakan. Tabel alternatif mempertahankan angka/filter/himpunan data yang sama. Warna peta menyatakan selisih terhadap median, bukan lampu harga wajar atau bukti kausalitas; pilihan palet/token dan kontras dirinci pada fase3.
- **Sumber:** pilihan A pada OPN-009a; DEC-009b; FR-012/029, BR-017; AUD-026.

### DEC-020a — Koreksi peran di luar lingkup MVP (OPN-010a)

- **Status:** diputuskan di luar lingkup MVP final.
- **Pemberi keputusan:** pengguna melalui jawaban “out of scope” pada pertanyaan OPN-010a.
- **Aturan:** tidak menyediakan fitur koreksi peran oleh Admin pada MVP. Akun biasa tetap memakai satu peran yang dipilih saat pendaftaran; tidak ada pergantian peran mandiri atau alur Admin mengubah peran.
- **Dampak:** pilihan A/B tentang kapan koreksi diperbolehkan tidak diambil. Hapus koreksi peran dari daftar keputusan yang wajib diselesaikan untuk MVP dan dari aksi pengelolaan pengguna. Ini bukan larangan melakukan kajian di masa depan atau persetujuan fitur lain seperti perubahan nomor/reset/pembekuan akun; fitur tambahan yang belum ditetapkan tidak menjadi kewajiban hanya karena draf menyebutnya sebagai pertanyaan.
- **Sumber:** jawaban pengguna pada OPN-010a; DEC-003c/003a; FR-001/021/027/028.

## 2. Status kelompok keputusan

Keputusan inti berikut telah dijawab melalui butir utama/subbutir. Status kelompok tidak berarti semua bukti teknis atau detail penerapannya tersedia. Ringkasan lintas kelompok telah dikonfirmasi pengguna pada [phase-1-summary.md](phase-1-summary.md).

| Kelompok | Jawaban yang menjadi acuan | Sisa pekerjaan |
|---|---|---|
| DEC-001/002/002a | Fokus final; seluruh fitur wajib/tinggi; gratis, tanpa komisi | Ketertelusuran kebutuhan dan tahap inkubasi |
| DEC-003/003a–c | Tiga ruang kerja, batas Admin, katalog login, satu peran per akun | Matriks izin rinci dan data sensitif |
| DEC-004 | Seluruh transaksi simulasi, bukan data latih | Label dan pemisahan data |
| DEC-005a–k | Parsial/reservasi, tenggat dinamis24jam untuk pesanan baru, negosiasi tanpa batas, persetujuan harga terakhir, selesai dua pihak, pembatalan dan lima tindakan utama | Mesin status/volume, alur alternatif dan walkthrough IA |
| DEC-006a–d | Asimetris, toleransi3% dapat diubah Admin, merah konfirmasi, riwayat pemeriksaan tidak ditulis ulang | Validasi konfigurasi dan penerapan UI |
| DEC-007a–f | GKP/GKG, rumus harga produsen dan P10/P90 rasio, mutu tanpa koreksi, boleh belum diukur/tanpa acuan | Bukti data/rendemen/kalibrasi/kecukupan dan peringatan mutu |
| DEC-008a–d | Horizon2/4pekan, beras dan gabah turunan, SHAP prakiraan/wilayah, fallback baseline terevaluasi | Rancangan model/fitur dan bukti evaluasi |
| DEC-009a–c | Harga petani pengamatan, median provinsi valid dan disparitas terpisah, transaksi seluruh provinsi | Pemetaan sumber/periode dan kategori peta |
| DEC-010a–f | OTP petani/pembeli; Admin email/sandi; kontak setelah setuju; notifikasi aplikasi; CSV; lokasi kecamatan | Kanal/provider OTP, kebijakan data dan kolom/izin ekspor |
| DEC-011a–f | Format contoh, layanan pertanian modern, palet pengguna/Forest Green, Plus Jakarta/Atkinson, terang/gelap, shadcn/Tailwindv4 | Token, kontras, ukuran, font/dependensi dan API komponen |
| DEC-012a | Minimal5responden mewakili kedua peran, targetSUS≥68 | Protokol/hasil uji; target model tetap mengikuti proposal |

## 3. Perlakuan rincian yang belum diputuskan

- Semua jawaban A/B/C di bagian1 dan riwayat di bagian4 tetap merupakan bukti keputusan; usulan lama yang berbeda tidak berlaku sebagai default terselubung.
- Detail teknis yang dapat dibuktikan dari dataset, implementasi atau dokumentasi pustaka diperiksa oleh pelaksana, bukan ditebak oleh pengguna.
- Pilihan yang mengubah perilaku/lingkup, termasuk kebijakan data sensitif, diajukan kembali bila belum diputuskan. Jangan menyebutnya terkonfirmasi hanya karena kelompok induknya telah dijawab.
- Pengguna mengonfirmasi ringkasan fase 1 melalui jawaban “A” pada 6 November 2026. Fase 1 ditutup. Pembaruan 6 November 2026: pengguna meminta fase 2 dimulai; SRS/IA v0.1 disiapkan untuk review, fase 3 belum dimulai.

## 4. Jalannya klarifikasi

| Putaran | Butir | Hasil |
|---|---|---|
| 1 | DEC-001 | Pengguna memilih fokus MVP final lomba |
| 2 | DEC-002 | Pengguna memilih A: seluruh fitur wajib dan prioritas tinggi proposal tetap target final |
| 3 | DEC-003 | Pengguna memilih A: tiga ruang kerja khusus; pendamping dan Dinas memakai akses publik |
| 4 | DEC-004 | Pengguna memilih A: seluruh transaksi simulasi dan tidak menjadi data latih |
| 5 | DEC-005a | Pengguna memilih B: pembelian parsial diperbolehkan; sisa volume tersedia dan satu tawaran dapat memiliki beberapa kontrak |
| 6 | DEC-005b | Pengguna memilih A: volume dicadangkan saat pengajuan pesanan; dilepas jika ditolak, dibatalkan atau kedaluwarsa |
| 7 | DEC-005c | Pengguna memilih A dengan catatan: awal 24 jam, dapat diubah Admin; dihitung sejak pengajuan tanpa reset saat negosiasi |
| 8 | DEC-005d | Pengguna memilih A: perubahan durasi Admin hanya berlaku untuk pesanan baru; tenggat pesanan aktif tetap |
| 9 | DEC-005e | Pengguna memilih A: pembeli boleh memakai harga petani atau mengajukan harga lain; petani dapat menerima, menolak atau menawar balik |
| 10 | DEC-005f | Pengguna memilih A: tawaran balik tanpa batas jumlah selama belum kedaluwarsa; negosiasi tidak mengulang tenggat |
| 11 | DEC-005g | Pengguna memilih A: pengajuan harga merupakan persetujuan pengaju; penerimaan harga terakhir oleh pihak lain langsung menjadikan kontrak Disetujui |
| 12 | DEC-005h | Pengguna memilih A: kontrak menjadi Selesai setelah petani dan pembeli masing-masing mengonfirmasi selesai |
| 13 | DEC-005i | Pengguna memilih B: sebelum Selesai, salah satu pihak dapat membatalkan kontrak Disetujui dengan alasan wajib; pihak lain diberi notifikasi dan volume kembali tersedia |
| 14 | DEC-005j | Pengguna memilih A: alasan wajib untuk pembatalan oleh pembeli atau penolakan oleh petani saat menunggu kesepakatan; pihak lain menerima notifikasi beserta alasan dan volume dilepas |
| 15 | DEC-005k | Pengguna memilih A: maksimal lima tindakan utama lintas kedua pihak pada alur normal hingga Selesai; login, navigasi dan negosiasi tambahan tidak dihitung |
| 16 | DEC-007a | Pengguna memilih B: GKP dan GKG dapat ditawarkan serta dinilai harga wajarnya, dengan rentang harga dan parameter mutu dibedakan |
| 17 | DEC-007b | Pengguna memilih A: estimator berupa rumus harga beras produsen, rendemen dan rasio historis terpisah untuk GKP/GKG; komponen ditampilkan, prakiraan tetap model AI tersendiri |
| 18 | DEC-007c | Pengguna memilih A: mutu dicatat dan diberi peringatan tanpa koreksi harga otomatis; keterbatasan estimasi dijelaskan |
| 19 | DEC-007d | Pengguna memilih A: kadar air dan kadar hampa/kotoran boleh Belum diukur; tawaran tetap dapat diterbitkan dengan mutu belum diketahui |
| 20 | DEC-007e | Pengguna memilih A: tawaran tetap boleh terbit tanpa acuan harga, dengan label Acuan harga belum tersedia dan tanpa lampu; pembeli tetap dapat melihat dan bernegosiasi |
| 21 | DEC-006a | Pengguna memilih A: harga jauh di bawah rentang boleh dilanjutkan setelah alasan peringatan ditampilkan dan konfirmasi eksplisit diberikan |
| 22 | DEC-006b | Pengguna memilih A: seluruh harga di atas rentang tetap kuning; merah hanya untuk harga jauh di bawah rentang |
| 23 | DEC-006c | Pengguna memilih A: toleransi awal 3%, dapat diubah Admin; harga tepat pada ambang toleransi kuning dan kedua batas rentang hijau |
| 24 | DEC-006d | Pengguna memilih A: ambang baru dipakai saat pemeriksaan pengajuan/penerimaan berikutnya; riwayat tetap dan kontrak Disetujui menyimpan hasil saat kesepakatan |
| 25 | DEC-008a | Pengguna memilih A: keluaran prakiraan dua dan empat pekan ke depan, mengikuti proposal A.7 |
| 26 | DEC-008b | Pengguna memilih B: prakiraan beras produsen per provinsi beserta estimasi turunan GKP/GKG, dengan label berbeda dari prediksi langsung gabah |
| 27 | DEC-008c | Pengguna memilih A: SHAP menjelaskan prakiraan dan perbedaan harga antarwilayah; estimator rumus dijelaskan melalui komponen hitung |
| 28 | DEC-008d | Pengguna memilih A: model yang belum memenuhi target digantikan baseline yang telah dievaluasi dengan label jelas; hasil model tetap dilaporkan dan SHAP tidak salah diatribusikan |
| 29 | DEC-009a | Pengguna memilih A: harga petani bersumber data pengamatan; GKP/GKG, ekuivalen beras dan estimasi harga wajar dibedakan; data tidak tersedia tidak diganti simulasi |
| 30 | DEC-009b | Pengguna memilih A: peta menampilkan selisih bertanda terhadap median provinsi valid pada komoditas/tingkat pasar/periode sama; disparitas maksimum–minimum terpisah |
| 31 | DEC-009c | Pengguna memilih B: transaksi simulasi tersedia untuk seluruh provinsi; papan harga/peta mengikuti data valid, tanpa acuan harga tawaran tetap dapat terbit |
| 32 | DEC-010a | Pengguna memilih A: login petani dan pembeli memakai nomor HP serta OTP; kanal dan penyedia belum ditentukan |
| 33 | DEC-010b | Pengguna memilih A: nomor HP saling terlihat hanya setelah kontrak Disetujui dan hanya bagi kedua pihak dalam kontrak terkait |
| 34 | DEC-010c | Pengguna memilih A: notifikasi transaksi untuk petani dan pembeli di dalam aplikasi saja; kanal OTP terpisah |
| 35 | DEC-003a | Pengguna memilih A: Admin mengelola operasional dan memantau, tanpa menawar/menyetujui/membatalkan/menyelesaikan kontrak atas nama pengguna |
| 36 | DEC-002a | Pengguna memilih A: seluruh fitur MVP final gratis, transaksi tanpa komisi; langganan produsen/API berbayar menjadi rencana hilirisasi |
| 37 | DEC-011a | Pengguna memilih C dengan catatan: arah visual baru, tetapi format UI Guidelines tetap seperti contoh referensi |
| 38 | DEC-011b | Pengguna memilih A dengan palet gambar: layanan pertanian modern, Forest/Olive Green, Sunflower Yellow, Honey Gold, Terracotta dan Warm Cream |
| 39 | DEC-011c | Pengguna memilih A: Forest Green #3E5A3A untuk tombol utama/navigasi aktif, latar Warm Cream dan aksen kuning/emas |
| 40 | DEC-011d | Pengguna memilih C: Plus Jakarta Sans untuk judul, Atkinson Hyperlegible Next untuk isi/kontrol; angka harga tabular |
| 41 | DEC-011e | Pengguna memilih B: mode terang dan gelap dapat dipilih; guideline menyediakan token serta pasangan kontras keduanya |
| 42 | DEC-007f | Pengguna memilih A: batas rentang memakai P10/P90 rasio historis valid per jenis gabah/wilayah; acuan tidak tersedia bila data belum cukup |
| 43 | DEC-012a | Pengguna memilih A: minimal lima responden mewakili petani/pembeli, target SUS≥68; hasil aktual dilaporkan apa adanya |
| 44 | DEC-010d | Pengguna memilih A: CSV ringkasan harga publik dan pasokan tanpa nomor HP/data pribadi |
| 45 | DEC-010e | Pengguna memilih A: Admin memakai halaman login terpisah, email dan kata sandi; akun dibuat pengelola tanpa pendaftaran publik |
| 46 | DEC-003b | Pengguna memilih B: katalog/detail tawaran memerlukan login; publik dapat mengakses papan harga, peta, prakiraan dan bantuan |
| 47 | DEC-003c | Pengguna memilih A: satu peran per akun biasa, dipilih saat pendaftaran; tanpa pergantian ruang kerja penjual/pembeli |
| 48 | DEC-010f | Pengguna memilih A: lokasi tawaran sampai kecamatan/kabupaten-kota/provinsi, tanpa alamat lengkap atau titik rumah |
| 49 | DEC-011f | Pengguna memilih A: UI Guidelines menggunakan shadcn/ui dan Tailwind CSS v4, dengan token/varian/contoh penerapan |

Konfirmasi penutup: pengguna memilih “A — Sesuai, fase pertama dapat ditutup” pada 6 November 2026. Ringkasan fase 1 disetujui. Persetujuan ini tidak menutup bukti teknis dan rincian lanjutan yang secara eksplisit masih terbuka pada ringkasan.





## Konfirmasi penutup fase 2

Pengguna memilih “A — Sesuai, tetapkan v0.2 sebagai dasar fase ketiga” pada 6 November 2026. SRS dan IA v0.2 disetujui sebagai baseline kebutuhan/struktur untuk penyusunan UI Guidelines, didukung matriks dan glosarium yang selaras. Fase 2 selesai dan ditutup; fase 3 belum dimulai. Catatan bukti/rancangan teknis yang belum tersedia tetap berlaku, bukan dianggap sudah diuji atau menjadi fitur tambahan terselubung. Ini konfirmasi pasangan dokumen, bukan perubahan atas 73 keputusan produk yang telah dicatat.

## Revisi visual fase 3

### DEC-021a — Mockup sebagai acuan komposisi dan base netral Jagains

- **Status:** instruksi eksplisit pengguna; bukan persetujuan keseluruhan draf UI.
- **Sumber:** pengguna meminta memeriksa `docs/ui_reference/mockup/*`, menyesuaikan UI Guidelines, memakai base Jagains, mempertahankan primary saat ini, serta menjadikan kuning dan warna pendukung pada gambar palet sebagai aksen atau status.
- **Aturan:** enam mockup menjadi acuan shell/topbar/sidebar, hierarki, panel, form/ringkasan, action bar, tabel/grafik/peta. Base netral mengikuti token Jagains; primary tetap Forest Green terang dan adaptasi hijau muda gelap yang sudah disusun. Warna kuning/emas/olive/terracotta/cream dibatasi sebagai aksen/status; Warm Cream tidak lagi menjadi latar umum.
- **Menggantikan:** bagian latar Warm Cream pada DEC-011c dan penerapannya pada draf UI v0.1. DEC-011c tetap menjadi riwayat keputusan; primary, font, dua mode, format delapan bagian dan target aksesibilitas tetap berlaku.
- **Dampak:** UI Guidelines/manifest/CSS/audit v0.2; indeks/matriks paket v0.4. Nilai OKLCH base Jagains dipertahankan persis. Input/ring memakai override solid berkontras dan helper gray dibatasi permukaannya agar target NFR-008 tetap terpenuhi. Rincian ukuran shell adalah adaptasi desain, bukan klaim CSS asli mockup sudah tersedia.
- **Batas:** mockup adalah sumber visual. Horizon 3–4 pekan, interval 90%, tiga centang, status/periode contoh, peran Produsen dan legenda A–D pada gambar tidak menggantikan SRS/IA. SRS/IA v0.2 tidak diubah perilakunya; seluruh draf UI masih untuk review.
