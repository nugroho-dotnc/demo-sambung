# SAMBUNG — Ringkasan Fase 2 setelah Klarifikasi

**Versi 0.2 — disetujui sebagai dasar fase ketiga; fase 2 selesai.** Pengguna telah menerima v0.1 sebagai draf, kemudian memberikan 24 keputusan tambahan. Pengecualian koreksi peran adalah keputusan lingkup, bukan pilihan A/B yang diasumsikan. Fase 3 belum dimulai.

Dokumen utama: [SRS](SRS_SAMBUNG.md), [IA](IA_SAMBUNG.md), [matriks](traceability-matrix.md), [catatan keputusan](decision-log.md), [glosarium](GLOSSARY.md). Keputusan fase 1 tetap menjadi dasar; penyesuaian berikut mengatasi bagian yang sebelumnya terbuka.

## 1. Tawaran panen dan moderasi

| Keputusan | Hasil |
|---|---|
| DEC-013a | Harga dan volume total tawaran boleh diubah untuk pesanan berikutnya. Kontrak lama tetap; total tidak kurang dari volume dicadangkan + Disetujui + Selesai |
| DEC-013b | Petani menarik tawaran: pesanan Menunggu yang belum kedaluwarsa otomatis Dibatalkan, pembeli diberi notifikasi, reservasi dilepas sekali. Disetujui tetap berjalan. Tawaran yang ditarik tidak menerima pesanan baru |
| DEC-013c | Admin hanya menandai dan meminta perbaikan/penarikan; tidak menyembunyikan, memblokir pesanan baru atau membatalkan kontrak melalui moderasi |
| DEC-013d | Jenis gabah dan lokasi terkunci setelah tawaran pernah menerima pesanan, termasuk jika pesanan sudah terminal. Perubahan keduanya memerlukan tawaran baru |
| DEC-013e | Tawaran Ditarik tidak dapat diterbitkan kembali. Sisa panen melalui tawaran baru dengan identitas baru, tanpa memindahkan riwayat/kontrak asal |
| DEC-013f | Pembeli login melihat penanda “Sedang diminta perbaikan” dan ringkasan masalah tanpa data pribadi. Tawaran tetap dapat dipesan |
| DEC-013g | Petani menyatakan “Sudah diperbaiki”; penanda tetap sampai Admin meninjau dan menutup temuan. Riwayat tidak dihapus; temuan lain yang belum ditutup tetap tampil |
| DEC-013h | Tanggal ketersediaan opsional, boleh “Belum ditentukan”, tidak otomatis mengekspirasi tawaran |

Penarikan oleh pemilik berbeda dari permintaan penutupan akun: penarikan membatalkan pesanan Menunggu, sedangkan penutupan tertunda tidak membatalkan transaksi lama. Tenggat tetap didahulukan atas aksi pada pesanan Menunggu; yang sudah kedaluwarsa tidak dibatalkan ulang. Konkurensi dan replay diuji pada kriteria penerimaan.

## 2. Kontak, penutupan akun dan data

| Keputusan | Hasil |
|---|---|
| DEC-014a | Setelah kontrak Dibatalkan, kontak pihak lawan disembunyikan kembali pada kontrak itu; riwayat tetap |
| DEC-014b | Setelah Selesai, kontak juga disembunyikan. Kontak hanya terbuka pada kontrak yang saat itu Disetujui; satu konfirmasi selesai masih Disetujui |
| DEC-014c | Panel Admin hanya menampilkan nomor tersamar, tanpa tombol membuka lengkap; pembatasan berlaku pada respons, pencarian, log, ekspor dan bukti pemantauan |
| DEC-014d | Permintaan penutupan akun dicatat dan diproses setelah semua transaksi aktif berakhir. Pengguna tetap dapat menindaklanjuti transaksi lama sesuai peran/status |
| DEC-014e | Selama penutupan tertunda, tidak boleh membuat tawaran/pesanan baru dan tawaran pemilik tidak menerima pesanan baru. Ini tidak otomatis menjadikan tawaran Ditarik atau membatalkan kontrak lama |
| DEC-014f | Setelah penutupan diproses, kontak/profil pribadi dihapus dan identitas riwayat dianonimkan; data transaksi nonpribadi tetap. Jangan menyebut mengganti nama dengan ID sebagai bukti anonimisasi |
| DEC-014g | Sebelum akun baru dibuat, ketentuan/pemberitahuan dapat dibaca dan persetujuan eksplisit wajib, tanpa centang otomatis; versi dan waktu dicatat. OTP bukan persetujuan |

Penghapusan/anonimisasi harus memiliki bukti penerapan pada salinan, teks bebas, indeks/cache, cadangan dan provider yang relevan. Keputusan ini bukan klaim proses sudah diterapkan atau kepatuhan hukum sudah terbukti; tidak ada masa simpan tambahan data pribadi yang disetujui diam-diam. Bukti persetujuan dan audit harus diselaraskan dengan kebijakan penutupan.

## 3. Akses dan ekspor

| Keputusan | Hasil |
|---|---|
| DEC-015a | Petani tidak membaca katalog/detail/ekspor pasokan petani lain. Hanya tawaran sendiri dan informasi harga publik. Katalog untuk pembeli dan pemantauan Admin |
| DEC-015b | CSV pasokan hanya agregasi per jenis gabah/wilayah: jumlah tawaran unik, total volume tersedia, minimum–maksimum harga minta serta satuan/waktu snapshot. Tanpa baris/identitas individual/data pribadi |

CSV harga publik tetap tersedia. Ekspor bukan jalan untuk melewati hak akses; reservasi/kontrak tidak menggandakan hitungan tawaran. Rentang harga minta bukan rentang harga wajar AI atau harga transaksi pengamatan.

## 4. Target pengujian dan data harga

| Keputusan | Hasil |
|---|---|
| DEC-016a | Teks isi minimal 16 px; area sentuh minimal 44×44 px; keyboard, zoom 200%; kontras teks normal minimal 4,5:1 dan fokus minimal 3:1, kedua mode. Menggantikan usulan 17 px/48 px |
| DEC-016b | Halaman utama siap digunakan maksimal 5 detik: konten utama/tombol dapat dipakai. Profil perangkat/jaringan/data/cache/pengulangan/penilaian harus dicatat sebelum kesimpulan lulus |
| DEC-017a | Pilih model/baseline/tidak tersedia per provinsi dan horizon berdasarkan evaluasi. Label metode/versi benar; SHAP dan gabah turunan mengikuti keluaran terkait. Skor agregat tidak meloloskan unit gagal |
| DEC-018a | Batas L/U dibulatkan ke rupiah terdekat sebelum tampilan/lampu; pecahan 0,5 ke atas; hasil asal tetap tersimpan |
| DEC-018b | Masukan harga/kg rupiah bulat, volume maksimal dua desimal; presisi berlebih diminta diperbaiki, bukan dibulatkan diam-diam |
| DEC-019a | Peta skala kontinu berpusat 0%, arah/nilai selisih jelas, tanpa data memiliki penanda tersendiri; tidak memakai kategori A–D atau batas kategori tetap |

Semua angka di atas adalah target atau aturan yang disepakati, bukan hasil pengujian yang telah tercapai. Presisi parameter/model, hasil pengamatan dan interval prakiraan tidak otomatis mengikuti pembatasan masukan pengguna.

## 5. Batas lingkup

**DEC-020a:** koreksi peran di luar MVP. Tidak ada alur pengguna atau Admin mengganti peran. Jawaban “out of scope” tidak diubah menjadi persetujuan atas salah satu alternatif koreksi.

Perubahan nomor, reset/pembekuan akun dan aksi opsional lain yang hanya muncul sebagai rincian belum dipilih tidak menjadi fitur wajib hanya karena disebut draf. Rancangan keamanan/pemulihan autentikasi dasar tetap perlu disiapkan sesuai metode login yang sudah dipilih; fitur tambahan yang mengubah lingkup diajukan kembali bila diperlukan.

## 6. Yang masih memerlukan rancangan atau bukti teknis

| Bidang | Tindak lanjut |
|---|---|
| OTP/keamanan | Kanal/provider, konfigurasi umur/kirim ulang/percobaan, integrasi dan pemulihan autentikasi dasar; tidak memakai OTP statis sebagai autentikasi nyata tanpa keputusan khusus |
| Estimator/data | Dataset, sumber/versi rendemen perjenis, kecukupan sampel, outlier, penyelarasan periode/mutu, umur data dan ambang peringatan mutu; data belum cukup tetap tidak tersedia |
| Model | Denominator MASE, cutoff/split, baseline/interval, protokol evaluasi perunit, SHAP wilayah, evaluasi gabah turunan; tidak mengarang hasil atau parameter |
| Data pribadi | Isi kebijakan, penghapusan/anonimisasi lintas salinan/cadangan/provider, perlakuan bukti persetujuan, waktu pemrosesan dan masa simpan nonpribadi; bukan retensi pribadi tambahan terselubung |
| Operasi/peta | Profil uji kinerja, deployment/backup/recovery, geometri/lisensi/pemetaan wilayah dan protokol penyajian |
| Fase 3 | Token, tipografi rinci, kontras terhitung, komponen/versi API, grafik/peta dan implementasi mode terang/gelap, mengikuti identitas dan format yang telah dipilih |

Bagian ini tidak berisi keputusan produk yang diam-diam dianggap disetujui. Fakta teknis dicari/divalidasi pelaksana; perubahan lingkup atau perilaku substantif diajukan kembali. Tidak ada kode aplikasi/dataset/laporan uji dalam sumber audit, sehingga belum dapat dinyatakan siap produksi atau semua validasi lulus.

## 7. Review pasangan dokumen

Pengguna memilih “A — Sesuai, tetapkan v0.2 sebagai dasar fase ketiga” pada 6 November 2026. SRS/IA v0.2 disetujui sebagai baseline kebutuhan dan struktur untuk UI Guidelines; fase 2 selesai dan ditutup. Fase 3 belum dimulai. Daftar bukti/rancangan teknis pada bagian 6 tetap terbuka; persetujuan ini bukan hasil uji aplikasi, model, anonimisasi atau kontras.
