# Role-Based Panel Content Specification — SAMBUNG

Status: Draft untuk acuan UI/UX MVP final lomba  
Scope: Landing page, Petani, Produsen, dan Admin

Dokumen ini menetapkan isi, prioritas, dan batasan panel utama untuk setiap role. Dokumen ini melengkapi SRS dan Information Architecture dengan menjawab pertanyaan: informasi apa yang harus terlihat, aksi apa yang harus diprioritaskan, dan elemen apa yang tidak boleh memenuhi ruang layar.

## Prinsip umum

- Setiap halaman memiliki satu tujuan utama dan satu CTA utama.
- Panel harus membantu pengguna mengambil keputusan, bukan sekadar menampilkan data.
- Informasi paling penting muncul di area pertama tanpa mengharuskan scrolling.
- Maksimal 4 panel utama dalam satu viewport desktop.
- Panel sekunder ditampilkan hanya jika mendukung tugas utama.
- Status menggunakan badge ringkas, bukan kartu besar.
- Setiap panel wajib memiliki state loading, empty, error, dan success/warning bila relevan.
- Hindari panel dekoratif, jargon internal, kode requirement, dan penjelasan kebijakan yang tidak dibutuhkan untuk tindakan saat itu.
- Gunakan Lucide icons secara konsisten; jangan gunakan emoji.

## 1. Landing Page / Pengunjung Publik

### Tujuan utama

Membantu pengunjung memahami masalah yang diselesaikan SAMBUNG, memeriksa harga yang wajar, dan memilih tindakan berikutnya: melihat papan harga, memeriksa peta, atau masuk/daftar.

### Hierarki panel

| Prioritas | Panel | Isi wajib | Aksi |
|---|---|---|---|
| P0 | Hero | Value proposition singkat, konteks gabah/beras, satu kalimat manfaat | Lihat Papan Harga |
| P0 | Quick Price Check | Komoditas, lokasi, harga input, hasil lampu harga | Cek Harga |
| P1 | Ringkasan Pasar | 2–3 metrik publik: harga petani, produsen, eceran atau tren | Buka Papan Harga |
| P1 | Jalur Pengguna | Penjelasan singkat manfaat untuk petani dan produsen | Masuk/Daftar |
| P2 | Kepercayaan | Sumber data, periode data, privasi secara ringkas | Lihat Bantuan & Privasi |

### Panel yang tidak boleh muncul

- Dashboard internal pengguna.
- Audit log, parameter model, dan informasi moderasi.
- Kartu berisi kode fitur seperti `PB-02`.
- Penjelasan transaksi panjang sebelum pengunjung melakukan tindakan.
- Lebih dari satu CTA primer dalam satu section.

### State penting

- Quick Price Check belum diisi: tampilkan form sederhana dan contoh format harga.
- Data belum tersedia: tampilkan alasan singkat dan tautan ke Papan Harga.
- Harga berada di zona merah/kuning/hijau: tampilkan badge kecil dengan penjelasan satu kalimat.
- Error: jelaskan input yang perlu diperbaiki, bukan pesan teknis.

## 2. Petani

### Tujuan utama

Membantu petani mengetahui peluang penjualan, menerbitkan tawaran panen dengan harga sadar, dan memantau pesanan atau kontrak yang sedang berjalan.

### Hierarki panel dashboard

| Prioritas | Panel | Isi wajib | Aksi utama |
|---|---|---|---|
| P0 | Ringkasan Aktivitas | Tawaran aktif, pesanan baru, kontrak berjalan, volume tersisa | Buka aktivitas terkait |
| P0 | Buat Tawaran Panen | Komoditas, volume, lokasi, tanggal kesiapan, harga | Buat Tawaran |
| P0 | Acuan Harga | Rentang harga wajar, harga input, lampu harga | Atur Harga |
| P1 | Tawaran Terbaru | Daftar ringkas tawaran aktif milik petani dengan status | Kelola Tawaran |
| P1 | Pesanan/Kontrak | Status pesanan, volume, tenggat, pihak pembeli | Buka Pesanan |
| P2 | Bantuan Kontekstual | Hanya tips yang relevan dengan aksi yang sedang dilakukan | Lihat detail |

### Prioritas pada halaman Buat Tawaran

1. Komoditas dan mutu.
2. Volume dan satuan.
3. Lokasi serta tanggal kesiapan.
4. Harga per kg dengan slider zona merah–kuning–hijau–kuning.
5. Ringkasan tawaran.
6. CTA `Terbitkan Tawaran Panen`.

Jika harga masuk zona merah, tampilkan konfirmasi sadar. Jangan memblokir secara otomatis kecuali ada aturan bisnis eksplisit.

### Panel yang tidak boleh muncul

- Statistik yang tidak dapat ditindaklanjuti.
- Kartu keamanan transaksi yang mengulang teks modal.
- Informasi teknis model AI.
- Data pembeli yang belum terkait dengan tawaran atau pesanan.
- Panel kosong tanpa penjelasan atau CTA.

### State penting

- Belum memiliki tawaran: tampilkan satu empty state dengan CTA membuat tawaran.
- Tawaran menunggu moderasi: tampilkan status kecil dan estimasi proses.
- Harga kuning/merah: tampilkan alasan dan opsi ubah harga.
- Pesanan baru: tampilkan notifikasi ringkas dengan akses langsung ke detail.

## 3. Produsen

Dalam konteks aplikasi, Produsen adalah pihak pembeli/penggilingan yang mencari pasokan, mengajukan harga, dan mengelola pesanan atau kontrak.

### Tujuan utama

Membantu produsen menemukan pasokan yang sesuai, mengajukan harga secara transparan, dan mengendalikan komitmen volume.

### Hierarki panel dashboard

| Prioritas | Panel | Isi wajib | Aksi utama |
|---|---|---|---|
| P0 | Ringkasan Pengadaan | Pesanan menunggu respons, kontrak aktif, volume dipesan, nilai transaksi | Buka Pesanan |
| P0 | Katalog Pasokan | Komoditas, mutu, lokasi, volume tersedia, harga petani, tanggal kesiapan | Cari Pasokan |
| P0 | Ajukan Harga | Harga penawaran, harga acuan, posisi slider zona, volume yang diminta | Ajukan Harga |
| P1 | Tawaran Saya | Daftar tawaran harga yang diajukan dan status respons petani | Kelola Tawaran |
| P1 | Kontrak Berjalan | Tahap pemenuhan, volume tersisa, jadwal, dokumen | Buka Kontrak |
| P2 | Papan Harga | Acuan publik untuk membantu keputusan pembelian | Lihat Papan Harga |

### Prioritas pada halaman detail pasokan

1. Identitas pasokan dan lokasi.
2. Volume tersedia dan kesiapan.
3. Harga petani serta rentang acuan.
4. Input volume pesanan.
5. Slider pengajuan harga dengan zona merah–kuning–hijau–kuning.
6. Ringkasan dampak pesanan.
7. CTA `Ajukan Harga`.

### Panel yang tidak boleh muncul

- Informasi petani yang tidak relevan untuk transaksi.
- Kartu edukasi panjang yang memisahkan form dari CTA.
- Panel metrik yang tidak memiliki keputusan lanjutan.
- Duplikasi data harga yang sama di beberapa kartu.

### State penting

- Tidak ada pasokan cocok: tampilkan filter yang dapat diubah dan CTA kembali ke katalog.
- Harga pengajuan di luar acuan: tampilkan konsekuensi dan konfirmasi sadar.
- Volume tidak tersedia: tampilkan volume terbaru dan nonaktifkan CTA dengan alasan jelas.
- Pesanan berhasil: tampilkan nomor pesanan, status pencadangan volume, dan langkah berikutnya.

## 4. Admin

### Tujuan utama

Membantu admin menjaga kualitas data, memoderasi tawaran, mengelola parameter harga, dan menelusuri aktivitas sistem dengan cepat.

### Hierarki panel dashboard

| Prioritas | Panel | Isi wajib | Aksi utama |
|---|---|---|---|
| P0 | Operasional Hari Ini | Tawaran menunggu moderasi, isu data, error penting, pengguna perlu perhatian | Buka antrean |
| P0 | Antrean Moderasi | Tawaran, pengusul, harga, lampu harga, waktu masuk, alasan flag | Tinjau Tawaran |
| P0 | Kesehatan Data | Status ingest, umur data, sumber gagal, kelengkapan wilayah/komoditas | Periksa Data |
| P1 | Parameter Harga | Parameter aktif, tanggal berlaku, cakupan wilayah/komoditas | Kelola Parameter |
| P1 | Model AI | Status model, versi, waktu pembaruan, hasil validasi ringkas | Buka Model AI |
| P1 | Pengguna | Jumlah aktif, verifikasi tertunda, status akses | Kelola Pengguna |
| P2 | Audit Log | Aktivitas administratif dengan filter waktu, aktor, dan objek | Lihat Audit Log |

### Aturan panel admin

- Panel operasional harus memprioritaskan item yang membutuhkan tindakan.
- Angka agregat harus dapat diklik menuju daftar sumbernya.
- Perubahan parameter wajib menampilkan dampak, periode berlaku, dan riwayat perubahan.
- Audit log tidak boleh menjadi panel hero; ia adalah alat penelusuran.
- Jangan menampilkan data pribadi lengkap pada ringkasan dashboard.

### State penting

- Antrean kosong: tampilkan status sehat, bukan kartu kosong berukuran besar.
- Isu kritis: gunakan warna status dan teks, bukan warna saja.
- Data stale: tampilkan umur data dan sumber yang terdampak.
- Perubahan parameter belum disimpan: tampilkan diff sebelum konfirmasi.
- Tidak memiliki izin: tampilkan alasan dan jalur eskalasi.

## Pola lintas role

### Panel ringkasan

Panel ringkasan harus menjawab tiga hal dalam sekali lihat: apa yang terjadi, apa yang membutuhkan perhatian, dan tindakan berikutnya.

### CTA

- CTA primer: satu per halaman/section.
- CTA sekunder: maksimal dua, tampil sebagai outline atau ghost.
- Label harus berupa tindakan spesifik, misalnya `Buat Tawaran`, `Tinjau Tawaran`, atau `Ajukan Harga`.
- Hindari label generik seperti `Klik di sini`, `Lihat`, atau `Submit`.

### Empty state

Setiap empty state terdiri dari judul singkat, penjelasan penyebab, dan satu CTA yang relevan. Jangan menggunakan ilustrasi besar yang mengambil alih ruang konten.

### Status

Gunakan badge compact dengan teks yang jelas. Warna mengikuti token SAMBUNG: Forest Green untuk status baik/primary, kuning untuk perhatian, merah/terracotta untuk risiko, dan neutral untuk status informasi.

### Responsif

- Desktop: panel utama dapat menggunakan grid dua kolom.
- Tablet: prioritaskan panel P0 dan susun panel lain secara vertikal.
- Mobile: satu kolom, CTA utama sticky atau tetap terlihat setelah form selesai.
- Jangan memaksa tabel kompleks pada layar kecil; ubah menjadi list atau kartu ringkas.

## Kriteria penerimaan UI

- Pengguna dapat menyebutkan tujuan halaman dalam waktu kurang dari 5 detik.
- CTA utama terlihat tanpa mencari-cari.
- Tidak ada panel tanpa tujuan atau tindakan lanjutan.
- Status tidak mengambil perhatian lebih besar daripada tugas utama.
- Spacing, radius, tipografi, dan pola tombol konsisten antar role.
- Semua kontrol keyboard memiliki focus state yang terlihat.
- Hover, active, disabled, loading, success, warning, dan error memiliki treatment yang berbeda dan dapat dipahami.
