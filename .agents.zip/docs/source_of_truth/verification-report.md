# SAMBUNG — Laporan Verifikasi Konsistensi

Tanggal: 6 November 2026. Status: fase 1 selesai; audit sumber tersedia dan ringkasan keputusan disetujui pengguna. Target terkonfirmasi: MVP final lomba 26–28 November 2026; inkubasi dicatat terpisah (DEC-001).

## 1. Kesimpulan dan batas audit

**Ketiga dokumen lama belum konsisten dan belum dapat langsung dijadikan source of truth.** Draf kebutuhan belum menjadi SRS final, IA mengikuti default yang belum dikonfirmasi, dan UI Guidelines memuat aturan yang saling bertentangan. Audit juga menemukan beberapa kesimpulan review lama yang perlu dikoreksi, bukan diwariskan.

Audit ini membandingkan isi sumber yang disediakan, bukan memvalidasi kebenaran seluruh statistik, kebijakan terkini, legalitas kontrak, hasil model, atau kondisi implementasi. Dokumen dibaca utuh melalui pemeriksaan utama dan pemeriksaan fakta paralel; temuan diperiksa terhadap teks dan nomor baris sumber. Tidak ada perubahan terhadap lima sumber asli.

Persetujuan memulai fase 1 berarti persetujuan mengaudit dan mengklarifikasi, bukan persetujuan atas Q-01…Q-15 lama. Keputusan baru dicatat di [decision-log.md](decision-log.md).

### Inventaris sumber

Nomor baris berikut mengacu pada snapshot berkas saat audit, sebelum penyuntingan sumber.

| ID | Sumber | Status | Baris |
|---|---|---|---:|
| P | [Proposal](../proposal/proposal.txt) | Proposal lomba; beberapa lampiran gambar tidak terbawa ke teks | 283 |
| R | [Review dan klarifikasi kebutuhan](../created/SAMBUNG_Review_dan_Klarifikasi_Kebutuhan.md) | 29 Oktober 2026; DRAFT, bukan SRS final (b.7–10) | 645 |
| I | [Information Architecture](../created/SAMBUNG_Information_Architecture.md) | DRAFT mengikuti default belum dikonfirmasi (b.5–6) | 373 |
| U | [UI Guideline](../created/SAMBUNG_UI_Guideline.md) | v1.0 draf, memerlukan persetujuan tim (b.5) | 472 |
| T | [Contoh format UI Guidelines](../ui_reference/contoh-ui-guidelines.md) | Referensi Jagains; tidak menjadi kebutuhan bisnis SAMBUNG | 406 |

Notasi bukti: `P:18` berarti proposal baris 18; rentang menunjukkan bagian yang dibandingkan.

### Sumber dan bukti yang belum tersedia

- P:A.1, A.3–A.6 berisi judul/ruang kosong untuk fishbone, wireframe, arsitektur, BPMN, dan user flow (P:63,99–141). Detail visual yang dikutip review tidak dapat diuji langsung.
- I merujuk delapan gambar `IA_01.png` sampai `IA_08.png`; semuanya tidak ditemukan di `docs/created/`. Diagram Mermaid tersedia dan dapat diaudit.
- “Brief” dan “kamus” yang dirujuk R/I tidak ditemukan sebagai berkas tersendiri. Contoh Rp13.400 di I:12 dapat diuji aritmetikanya, tetapi asal datanya belum terbukti.
- Tidak ada kode prototipe, `resources/css/app.css`, `resources/js`, dataset, notebook, GeoJSON, laporan backtest, atau hasil SUS dalam inventaris dokumen. Diagnosis kode U:14–29 dan klaim hasil data tidak dapat dianggap hasil pemeriksaan implementasi saat ini.

## 2. Komitmen yang benar-benar tertulis dalam proposal

| Bidang | Isi sumber | Bukti |
|---|---|---|
| Masalah dan tujuan | Harga acuan gabah, pembeli alternatif, transparansi perbedaan wilayah, posisi tawar petani | P:9–12,16 |
| Aktor | Petani/kelompok tani, penggilingan/pengolah, pendamping; warga dan Dinas sebagai pengguna sekunder | P:11,16 |
| Bisnis | Dasar gratis bagi petani, tanpa komisi; visi langganan produsen dan API | P:11,216–218 |
| Transaksi | Listing dengan harga tawar, produsen mencari/memesan, kontrak otomatis diperiksa harga | P:20,33 |
| Estimator | Narasi §4.2 memakai harga eceran dan regresi kuantil; A.7 merinci tahap 1 berbasis harga produsen × rendemen × rasio historis, tahap 2 setelah transaksi cukup | P:20,149–151,274–275 |
| Prakiraan | Narasi 2–4 pekan; keluaran A.7 secara eksplisit 2 dan 4 pekan, pita 80%; 1–8 pekan adalah riwayat masukan | P:10,18,153–155 |
| Penjelas | SHAP untuk alasan prakiraan dan selisih antardaerah; pemeriksa kontrak berupa lampu dengan alasan | P:20,156–163 |
| Evaluasi | MASE ≤0,9, pembanding baseline dan SARIMA, cakupan pita 80% sebesar 75–85%; recall lonjakan ≥70%, precision ≥60% | P:18 |
| Usability | Satu siklus simulasi dari katalog sampai kontrak selesai ≤5 langkah | P:18 |
| Prototipe | Data bersih, harga wajar, indikator, papan harga wajib 10 November | P:191–193 |
| Final | Kontrak simulasi + pemeriksa + SHAP dasar wajib; prakiraan, peta, dasbor dan notifikasi prioritas tinggi | P:194–199 |
| Inkubasi dan pengecualian | Retraining, peringatan dini dan multibahasa pada inkubasi; pembayaran, logistik, mutu fisik tidak untuk saat ini | P:200–205 |
| Validasi | Final menargetkan TKT 4, backtesting dan uji kegunaan; TKT 5 melalui uji terbatas saat inkubasi | P:23,87–96 |
| Tata kelola | Sumber beragam, minimisasi data, persetujuan, agregasi, estimasi bukan jaminan | P:265–283 |

Target di atas adalah janji proposal, bukan hasil yang sudah dicapai. Inkubasi terpisah dari baseline final sesuai DEC-001.

## 3. Matriks konsistensi empat sumber substantif

Legenda: **Konflik** = pernyataan tidak sejalan; **Usulan** = detail tambahan belum disetujui; **Kurang** = informasi belum cukup; **Selaras** = tujuan sejalan, detail tetap perlu diturunkan. Prioritas kritis berarti menghalangi pembakuan perilaku inti, bukan cacat aplikasi yang telah terbukti.

| ID / topik | Proposal | Draf kebutuhan | IA | UI | Hasil dan dampak | Keputusan |
|---|---|---|---|---|---|---|
| AUD-001 Lingkup final | Wajib/tinggi/inkubasi (P:191–205) | Must/Should/Could, tambahan Admin (R:430–452) | Mengikuti default (I:5–6,283–348) | Beberapa elemen AI diwajibkan tanpa prioritas (U:273–294) | **Konflik/usulan, kritis:** tidak ada konversi prioritas yang disetujui; DEC-001 hanya menetapkan target final | DEC-002 |
| AUD-002 Peran/izin | Pendamping ada; Admin tidak dirinci (P:16) | Pendamping/Dinas ditunda, Admin ditambah (R:227–251) | Default sama; Admin lihat kontrak/audit (I:351–358) | Pola Admin diakui (U:299–300) | **Usulan, kritis:** lingkup aktor dan akses data belum diputuskan | DEC-003 |
| AUD-003 Katalog/listing | Petani memasang, pembeli mencari (P:20) | Satu listing satu kontrak, tanpa parsial (R:321,379) | Status dan halaman mengikuti itu (I:219–242,306–330) | Daftar/tawaran dapat dibuka (U:155–157) | **Usulan:** tidak ada dasar proposal untuk larangan parsial; status stok perlu jelas | DEC-005 |
| AUD-004 Pesanan/negosiasi | Pesan dan kontrak otomatis (P:20) | Dua putaran, tujuh hari (R:285–293) | Batas dibawa ke diagram/halaman (I:115,145–148,237–240) | Riwayat dan tiga centang (U:291–294) | **Kurang/usulan, kritis:** siapa setuju, reset persetujuan saat harga berubah, penolakan/batal perlu ditetapkan | DEC-005 |
| AUD-005 Simulasi/selesai | Final simulasi; visi data nyata (P:10,18,195) | Semua simulasi; selesai dua pihak (R:308,396) | Tombol “Tandai selesai”, bukti simulasi (I:119,149,241) | Istilah kontrak simulasi (U:317) | **Sebagian selaras, kritis:** scope simulasi disarankan; pelaku selesai belum eksplisit konsisten | DEC-004, DEC-005 |
| AUD-006 Lampu harga | Tiga warna dengan alasan, aturan merujuk gambar hilang (P:160–163) | Asimetris δ3%, tidak memblokir (R:275–283,343–361) | Merah wajib centang (I:105–107) | Nonblocking + konfirmasi; latensi <150ms (U:174–183) | **Usulan, kritis:** ambang/batas, sisi pembeli dan efek konfirmasi belum sah sebagai keputusan | DEC-006 |
| AUD-007 Estimator | Eceran/GBM di narasi vs produsen/tahap 1 di A.7 (P:20,149–151) | Medium I, P10/P90 rasio (R:363–376) | Menulis 93–97% dan revisi F-03 (I:12,261) | Contoh Rp6.650–6.940 (U:188–193) | **Konflik, kritis:** sumber masukan, metode interval, mutu dan pembulatan belum tunggal | DEC-007 |
| AUD-008 Horizon/interval | Keluaran 2/4 pekan, pita80% (P:154) | Review salah baca 1–8; usulan 1–4 (R:96–102,443) | Banyak layar 1–4 dan80% (I:67,94,150) | Pita80%, tanpa horizon rinci (U:241) | **Konflik, kritis:** koreksi pembacaan lookback, pilih horizon final | DEC-008 |
| AUD-009 SHAP/fallback | SHAP dasar wajib final; penjelasan lintas wilayah (P:20,195) | Must ringan di fitur, Should pada FR (R:439,511); fallback baseline (R:312) | SHAP Should; peta statis (I:360–366,370) | Hindari klaim sebab, teks awam (U:254–256) | **Konflik, kritis:** komponen rumus bukan SHAP; fallback tidak membuktikan target AI tercapai | DEC-002, DEC-008 |
| AUD-010 Papan harga | Petani–produsen–eceran, bagian petani (P:20) | Empat tingkat; ekuivalen dari estimasi atau BPS (R:399–403,521–527) | Empat tingkat + grafik12pekan (I:59,289) | Sumber/umur terlihat (U:296–297) | **Kurang/usulan:** jangan mencampur estimasi dengan harga transaksi diamati atau frekuensi data | DEC-009 |
| AUD-011 Peta/disparitas | Narasi dan A.8 beda populasi/periode (P:17,177) | Median nasional, kelas A–D (R:405–408) | Kelas sama, tabel aksesibel (I:60–65,290–292) | Skala satu hue, jarak median (U:245–250) | **Kurang:** selisih bertanda/absolut, batas30%, level harga dan wilayah valid belum jelas | DEC-009 |
| AUD-012 Retraining | Visi closed-loop, otomatis inkubasi (P:20,201) | Simulasi dikecualikan (R:308) | Validasi data latih ditunda (I:178,366) | Tidak mendefinisikan training | **Selaras sebagai usulan tahap:** pemisahan final/inkubasi perlu eksplisit | DEC-004, DEC-009 |
| AUD-013 Notifikasi | Tinggi final (P:198) | Should, dalam aplikasi; FR petani saja (R:320,444,512) | Petani dan produsen (I:120,156) | Pola daftar, tanpa kanal (U:384) | **Konflik/usulan:** prioritas dan penerima tidak tunggal | DEC-002, DEC-010 |
| AUD-014 Autentikasi | Daftar minimal (P:20) | OTP HP; Admin email/sandi (R:229–233,296–297) | Enam kotak OTP/profil (I:298–304) | Tidak mengikat metode login | **Usulan:** metode, biaya/provider, mode demo belum diputuskan | DEC-010 |
| AUD-015 Privasi | Minimisasi/persetujuan/agregasi (P:282–283) | Kontak setelah setuju, lokasi kecamatan (R:296,555) | Pengaturan/hapus akun/Admin lihat data (I:122,175,351–358) | Panduan bukan kebijakan data | **Kurang/usulan:** visibilitas kontak, cakupan Admin dan retensi belum spesifik | DEC-003, DEC-010 |
| AUD-016 Monetisasi | Gratis petani/tanpa komisi; langganan/API (P:11) | MVP gratis dan gateway di luar (R:207–208,449) | CSV, Dinas/API ditunda (I:208,331,347) | Tidak menentukan tagihan | **Selaras tujuan, usulan tahap:** gratis MVP belum jawaban resmi | DEC-002 |
| AUD-017 Aksesibilitas/format UI | Antarmuka sederhana (P:12,18) | Huruf≥16, SUS≥68 usulan (R:558–559) | Maks2klik dari hub (I:16) | Isi17, metadata15, target48; max3tingkat (U:333–338) | **Usulan/ketidakjelasan:** batas per jenis teks dan arti kedalaman/klik perlu dijelaskan | DEC-011 |
| AUD-018 Istilah | Produsen = pembeli sekaligus tingkat pasar (P:11,149) | Listing, tawaran, pesanan, kontrak (R:285–291) | “Penawaran Saya” berarti pesanan produsen (I:151,328) | Bahasa awam “tawaran”; GKP dijelaskan (U:310,317) | **Kurang:** perlu glosarium untuk objek dan aktor yang tidak ambigu | DEC-005, DEC-011 |
| AUD-019 ≤5langkah | Katalog sampai kontrak selesai (P:18) | Sampai disetujui, per peran; AC mulai listing (R:410–416,579) | Alur hingga bukti dan selesai (I:110–119,144–149) | UI bertahap (U:214) | **Konflik, kritis:** cakupan metrik telah berubah | DEC-005 |

## 4. Konflik internal dan koreksi yang perlu dibawa ke fase berikutnya

| ID | Bukti | Temuan | Tindak lanjut |
|---|---|---|---|
| AUD-020 Semantik warna | U:41,118,123,183,204,223–226 | Warna lampu disebut hanya untuk harga, tetapi dipakai untuk kontrak, validasi dan bahaya | Pisahkan aturan/token harga, kontrak dan bahaya atau longgarkan larangan secara eksplisit (DEC-011) |
| AUD-021 Aturan vs contoh UI | U:141 vs407,413; U:140 vs412 | Format diwajibkan lewat helper, contoh memformat manual; semua harga diwajibkan num-* tetapi HPP hanya font-semibold | Perbaiki spesifikasi/contoh saat fase3; bukan bug kode produksi yang terbukti |
| AUD-022 Satuan ukuran | U:85,90–91 vs135 | Root17px membuat num-lg=29,75px, num-xl maksimum59,5px; tabel menyebut28–56px | Tabel dan CSS harus satu dasar ukuran |
| AUD-023 Prioritas FR | R:498 vs510; R:439 vs511 | Prakiraan ada di FR beranda Must tetapi FR prakiraan Should; SHAP Must ringan vs Should | Nyatakan komponen opsional pada halaman wajib atau samakan prioritas (DEC-002) |
| AUD-024 Rujukan FR salah | R:517,598 | Closed-loop menunjuk FR-022 yang sebenarnya log audit; AC-08 hanya menguji pengecualian simulasi | Pisahkan kebutuhan retraining dari audit log; jangan menganggap closed-loop sudah terspesifikasi |
| AUD-025 Kelengkapan transisi | I:228 vs R:379; I:148 vs R:394,397 | IA mengembalikan listing saat kontrak kedaluwarsa, R hanya batal/tolak; diagram produsen mewajibkan alasan tolak/batal, R hanya batal | Satu tabel transisi otoritatif diperlukan (DEC-005) |
| AUD-026 Batas kelas peta | R:407, I:60 | 20–30 dan30–40 bertumpang tindih di30; nilai negatif dan arti selisih belum ditentukan | Pilih rumus dan interval tak tumpang tindih (DEC-009) |
| AUD-027 Navigasi | I:16 vs110–119 | Janji semua fitur maksimal2klik tidak menjelaskan jalur hub→tawaran→detail→kontrak→bukti | Definisikan cakupan janji navigasi; jangan mengklaim lolos sebelum walkthrough |
| AUD-028 Interval estimator | P:151; R:368–371; I:261 | Faktor historis tetap93–97% vs kuantil empiris belum disamakan; I memakai “rasio historis” bukan bukti kalibrasi | Tetapkan definisi parameter dan bukti data, jangan memperlakukan93–97% sebagai interval keyakinan model otomatis |
| AUD-029 Referensi hilang | I:23,55,90,134,166,191,220,247; U:14–29 | PNG dan kode yang dijadikan basis diagnosis tidak tersedia | Mermaid tetap dapat dipakai; audit visual/kode menunggu sumber tersedia |
| AUD-030 Status angka contoh | U:188–193,277 vs463; R:580 | Contoh disebut “pekan ini” dan “nyata” tanpa sumber, sementara ilustrasi wajib label dan AC menolak hardcode | Cantumkan label ilustrasi/snapshot dan sumber/tanggal; harga contoh tidak dianggap data terbaru |
| AUD-031 Batas format UI | T:8–406 vs U:14–472 | Draf SAMBUNG belum mengikuti delapan bagian contoh; tema/font/stack/domain berbeda | Ini pekerjaan adaptasi fase3, bukan alasan mengadopsi kebutuhan Jagains |
| AUD-032 Inventaris vs diagram IA | I:107,155–157 vs309,324; I:197–200 vs348 | Tujuan PT-08, PR-07/08 tidak tercantum pada navigasi hub; empat fungsi pendamping dipetakan hanya PD-01…03 | Cocokkan semua simpul, ID dan tujuan tabel saat penyusunan IA |
| AUD-033 Halaman bersama/izin | I:17,122,157,318–319,331,356,373 | Profil/notifikasi disebut bersama tetapi ID per peran belum dijelaskan; petani boleh membaca katalog menurut matriks/default, namun jalurnya belum ada di diagram petani | Nyatakan alias/variasi halaman bersama dan sediakan rute hanya jika izinnya disetujui (DEC-003) |

### Pemeriksaan aritmetika F-03

Menggunakan rendemen0,5338 dan faktor0,93/0,97 sebagaimana contoh IA:

| Harga beras masukan | ×rendemen | Batas bawah | Batas atas |
|---:|---:|---:|---:|
| Rp13.400 | Rp7.152,92 | Rp6.652,2156 | Rp6.938,3324 |
| Rp14.380 | Rp7.676,044 | Rp7.138,72092 | Rp7.445,76268 |

Perhitungan pertama mendekati contoh Rp6.650–6.940 bila dibulatkan ke puluhan rupiah terdekat. Jadi klaim “rumus tidak dapat menghasilkan rentang” terlalu luas. Masalah yang tersisa adalah sumber harga masukan, konsistensi antarcontoh, metode interval dan kebijakan pembulatan. Tidak ada dataset untuk membuktikan salah satu masukan benar secara empiris.

## 5. Pemeriksaan ulang F-01…F-25

Status di tabel ini menilai kesimpulan lama terhadap sumber tersedia, bukan menyatakan keputusan bisnis sudah selesai.

| Temuan lama | Status audit | Bukti dan koreksi |
|---|---|---|
| F-01 Ambang lampu | Tetap relevan; bukti visual belum dapat diuji | P:160–163 tidak memuat ambang, R:90–94 mengutip gambar hilang; δ3% adalah rekomendasi |
| F-02 Horizon/interval | Direvisi | P:153 adalah input1–8, P:154 output2/4 dan80%; klaim wireframe90% di R:96–102 belum dapat diverifikasi |
| F-03 Rumus/wireframe | Direvisi | R:104–116 vs I:12; hitungan dapat mendekati rentang dengan masukan13.400; asal masukan belum tersedia |
| F-04 Input estimator | Tetap relevan | P:20 eceran vs P:149 produsen; P:151 sendiri sudah mengizinkan tahap1 |
| F-05 SHAP | Direvisi | Model prakiraan GBM ada di P:155; bukan berarti tidak ada model untuk SHAP. Implementasi penjelasan lintas wilayah dan lingkup wajib masih perlu ditetapkan |
| F-06 Target prakiraan | Tetap relevan sebagai risiko | Target/baseline ada P:18,166–167; tidak ada backtest untuk menyimpulkan model pasti gagal/menang |
| F-07 Lonjakan | Direvisi | Target ada P:18, definisi perubahan2pekan di atasP95 ada P:166; peringatan otomatis inkubasi P:201. Bukan sepenuhnya tanpa definisi |
| F-08 Pasar ganda | Sebagian tidak dapat diverifikasi | P:20 mendukung pencarian/pemesanan; BPMN otomatis yang dikutip R:137–138 tidak terlihat pada P:132–140 |
| F-09 Siklus kontrak | Tetap relevan | P:20 tidak merinci negosiasi, pembatalan, kedaluwarsa; detail visual R:140–144 belum terverifikasi |
| F-10 Lima langkah | Tetap relevan, diperluas | P:18 sampai selesai; R:410–416,579 mengubah batas dan satuan hitung |
| F-11 Closed-loop | Tetap relevan | P:10,20 visi nyata vs P:195 simulasi; harus dipisahkan menurut tahap, bukan kontradiksi yang mustahil diselesaikan |
| F-12 Scope proposal/brief | Sebagian tidak dapat diverifikasi | Brief tidak tersedia; katalog/auth dibutuhkan oleh P:20,33 meskipun tidak semua dirinci A.9. Peta/dasbor/notifikasi Tinggi P:198 |
| F-13 Peran | Tetap relevan dengan batas bukti | Pendamping P:16; Admin merupakan usulan R:233, bukan kebutuhan proposal eksplisit; brief tidak tersedia |
| F-14 Dasbor campur | Direvisi | P:109 menyebut gabungan wireframe sebagai gambaran; bukan bukti implementasi izin bercampur. Pemisahan peran tetap diperlukan |
| F-15 Bagian petani | Sebagian terverifikasi | P:17 75–81% vs P:183 76–81% perlu cakupan/periode; klaim83% wireframe tidak dapat diuji langsung |
| F-16 Disparitas | Tetap relevan dengan konteks | P:17 dan177 menyebut periode, tingkat pasar dan cakupan berbeda; belum membuktikan angka saling meniadakan, definisi/agregasi perlu dicatat |
| F-17 Peta | Sebagian tidak dapat diverifikasi | Kelas gambar belum tersedia; pemetaan wilayah/data kosong tetap kebutuhan usulan R:405–408; jumlah wilayah terkini tidak diverifikasi dalam audit isi |
| F-18 Harga regional | Direvisi | R:188–190 membandingkan narasi nasional P:17 dengan contoh regional tak bertanggal; cukup untuk risiko asal data, tidak membuktikan kontradiksi harga regional |
| F-19 HPP | Tetap relevan sebagai kebutuhan versi data | P:165,272–273 membahas rezim; HPP berlaku-tanggal adalah rekomendasi logis, nilai kebijakan terkini belum diverifikasi |
| F-20 Input listing | Sebagian tidak dapat diverifikasi | P:20 menyebut listing umum, rincian field wireframe di R:194–195 tidak tersedia; foto/hampa/tanggal tidak otomatis wajib |
| F-21 Kontrak/identitas | Tetap relevan sebagai kekurangan spesifikasi | P:195 simulasi; mekanisme identitas/persetujuan belum terinci. Usulan label bukan pendapat hukum yang tervalidasi |
| F-22 Arsitektur besar | Tidak dapat diverifikasi | P:A.4 kosong; daftar komponen R:201–203 tidak dapat dicek. Monolit/offline belum keputusan pengguna |
| F-23 Langganan | Direvisi | Monetisasi adalah visi P:11,216–218; mekanisme tagih belum dijabarkan, tetapi tidak otomatis wajib dibangun di final |
| F-24 Risiko | Direvisi sebagian | P:276–283 sudah mencakup salah tafsir, sumber data dan privasi; manipulasi/listing palsu belum eksplisit. Nomor bagian5→8 memang loncat (P:28,36), sebabnya belum diketahui |
| F-25 Tema | Selesai pada tingkat isi teks | Daftar P:5–7 tidak menandai pilihan, tetapi P:16 eksplisit memilih Ketahanan Pangan; bukan keputusan produk terbuka |

## 6. Status pertanyaan Q-01…Q-15 lama

Semua default lama belum memperoleh persetujuan eksplisit dalam chat ini. DEC-001 menetapkan target dokumentasi final; DEC-002 mengonfirmasi seluruh fitur wajib dan prioritas tinggi proposal sebagai target final. Rincian default lainnya belum disetujui.

| Pertanyaan | Status / perlakuan | Pemetaan baru |
|---|---|---|
| Q-01 Lampu | Terbuka; kalimat “terbalik” vs “kuning saja” di R:283 juga ambigu | DEC-006 |
| Q-02 Kontrak | Terbuka; dua putaran/tujuh hari belum dipilih | DEC-005 |
| Q-03 Akun | Terbuka; OTP/biaya/mode demo dan aturan kontak belum dipilih | DEC-010 |
| Q-04 Rumus/GKP | Terbuka; pisahkan lingkup komoditas, sumber input, metode interval, mutu | DEC-007 |
| Q-05 Peran | Terbuka; jangan menganggap pendamping sudah disetujui ditunda | DEC-003 |
| Q-06 Simulasi | Terbuka untuk pengesahan baseline; simulasi final punya dasar P:195 | DEC-004 |
| Q-07 Prakiraan | Direvisi sebelum ditanyakan: default1–4 dan Should tidak sama dengan keluaran A.7 | DEC-002, DEC-008 |
| Q-08 Peta | Terbuka; rumus, tanda dan batas kategori perlu lengkap | DEC-009 |
| Q-09 Notifikasi | Terbuka; kanal dan penerima perlu dipilih | DEC-010 |
| Q-10 Listing | Terbuka; tanpa parsial bukan fakta proposal | DEC-005 |
| Q-11 Wilayah | Terbuka; Jawa Timur fokus demo belum persetujuan | DEC-009 |
| Q-12 ML offline | Terbuka sebagai pilihan implementasi; pisahkan dari requirement produk | DEC-008 |
| Q-13 CSV | Terbuka; bukan komitmen format proposal | DEC-010 |
| Q-14 Bahasa | Dokumen Indonesia ditetapkan brief/rencana; UI Indonesia direkomendasikan, multibahasa inkubasi P:201 | DEC-011 |
| Q-15 SUS | SUS ada P:31,90; 5–8 responden dan ambang68 adalah usulan R:330,559 | DEC-012 |

### Pembaruan keputusan setelah audit

DEC-005a: pengguna memilih pembelian parsial. Default lama Q-10 “satu listing = satu kontrak, tanpa pembelian parsial” tidak digunakan. Satu tawaran dapat memiliki beberapa kontrak; sisa volume tetap tersedia untuk pembeli lain. DEC-005b menetapkan volume dicadangkan saat pesanan diajukan dan dilepas jika ditolak, dibatalkan atau kedaluwarsa. AUD-003 dan AUD-025 perlu diselesaikan dengan aturan volume serta status yang mencerminkan keputusan ini; durasi menunggu dan rincian status lanjutan masih terbuka.

DEC-005c: durasi awal menunggu kesepakatan ditetapkan 24 jam sejak pengajuan, tanpa reset saat negosiasi. Admin dapat mengubah durasinya secara dinamis. Ini menggantikan default tujuh hari pada draf lama. DEC-005d menetapkan perubahan parameter hanya berlaku untuk pesanan baru; batas waktu pesanan aktif tetap.

DEC-005e/f: pembeli boleh mengikuti harga petani atau mengajukan harga lain, dan petani dapat menerima, menolak atau menawar balik. Jumlah tawaran balik tidak dibatasi selama pesanan belum kedaluwarsa; default maksimal dua putaran tidak digunakan. Negosiasi tidak mengulang tenggat. DEC-005g menetapkan pengajuan harga sebagai persetujuan pengaju; penerimaan harga terakhir oleh pihak lain langsung menjadikan kontrak Disetujui. Penyelesaian simulasi dan pembatalan setelah persetujuan masih perlu ditetapkan.

DEC-005h: kontrak simulasi berstatus Selesai setelah petani dan pembeli masing-masing mengonfirmasi selesai. Ini memperjelas pelaku penyelesaian pada AUD-005; pengukuran alur hingga Selesai pada AUD-019 tetap perlu dirumuskan. DEC-005i menetapkan bahwa sebelum Selesai, salah satu pihak dapat langsung membatalkan kontrak Disetujui dengan alasan wajib, notifikasi kepada pihak lain, dan pengembalian volume tersedia.

DEC-005j: saat menunggu kesepakatan, pembeli dapat membatalkan dan petani dapat menolak dengan alasan wajib. Pihak lain menerima notifikasi beserta alasan; volume kembali tersedia. Ini memperjelas perbedaan alasan penolakan/pembatalan pada AUD-025.

DEC-005k menyelesaikan definisi pengukuran AUD-019: maksimal lima tindakan utama lintas kedua pihak pada alur normal, yaitu pilih tawaran, kirim pesanan, terima harga, serta dua konfirmasi selesai. Login, navigasi dan negosiasi tambahan dikecualikan. Ini tidak boleh dilaporkan sebagai lima klik keseluruhan maupun lima langkah per peran. Mesin status dan inventaris halaman lama tetap perlu disusun ulang pada fase2 agar mengikuti keputusan transaksi tersebut.

DEC-007a: pengguna memilih dukungan GKP dan GKG untuk penawaran serta penilaian harga wajar pada MVP final. Default GKP saja pada Q-04 tidak digunakan. Rentang harga dan parameter mutu harus dibedakan; metode, sumber data dan rendemen GKG belum ditetapkan dan tidak boleh diasumsikan sama dengan GKP.

DEC-007b: pengguna memilih estimator tahap awal berupa rumus berbasis harga beras produsen, rendemen dan rasio historis yang dibedakan untuk GKP/GKG. Ini menetapkan tingkat pasar masukan estimator pada AUD-007; nilai parameter dan pembentukan rentang AUD-028 masih memerlukan bukti. Penjelasan komponen rumus dipisahkan dari SHAP pada model prakiraan.

DEC-007c: mutu dicatat dan diberi peringatan tanpa penyesuaian numerik harga pada MVP final. Estimasi harus menjelaskan bahwa mutu belum diperhitungkan; ini tidak berarti mutu terverifikasi fisik. Nilai ambang peringatan dan field wajib/opsional belum diputuskan.

DEC-007d: petani boleh memilih “Belum diukur” untuk kadar air dan kadar hampa/kotoran serta tetap menerbitkan tawaran. Nilai tersebut ditampilkan sebagai belum diketahui, bukan nol atau klaim memenuhi standar. Nilai yang diisi tetap deklarasi petani, bukan verifikasi mutu fisik.

DEC-007e: data acuan yang belum cukup tidak menghalangi penerbitan tawaran. Tampilkan “Acuan harga belum tersedia” tanpa lampu harga; pembeli tetap dapat melihat dan bernegosiasi. Pemeriksaan harga perlu membedakan keadaan tidak tersedia dari tiga status harga, tanpa mengarang rentang pengganti.

DEC-006a: harga jauh di bawah rentang wajar tetap boleh dilanjutkan setelah alasan peringatan ditampilkan dan pengguna memberi konfirmasi eksplisit. Ini menetapkan konsekuensi lampu merah pada AUD-006; nilai ambang dan perilaku harga di atas rentang belum diputuskan.

DEC-006b: harga di atas rentang tetap kuning dengan penjelasan “Di atas rentang wajar”; merah khusus harga jauh di bawah batas bawah. Aturan asimetris berlaku dengan makna sama untuk pembeli dan penjual. Ambang harga rendah yang menjadi merah masih perlu ditetapkan.

DEC-006c: toleransi awal 3% dapat diubah Admin. Dengan batas bawah L, harga di bawah 0,97×L merah; tepat pada 0,97×L hingga kurang dari L kuning. Harga di dalam rentang termasuk kedua batas hijau; di atas rentang kuning. Nilai 3% adalah konfigurasi awal yang disetujui, bukan hasil validasi empiris. Dampak perubahan parameter pada pemeriksaan yang sudah tercatat belum diputuskan.

DEC-006d: perubahan ambang berlaku pada pemeriksaan harga berikutnya saat pengajuan atau penerimaan; hasil sebelumnya tetap disimpan. Kontrak yang sudah Disetujui mempertahankan hasil saat kesepakatan, tanpa penghitungan ulang retroaktif. Ini menetapkan dampak perubahan konfigurasi lampu pada AUD-006.

DEC-008a menyelesaikan pilihan horizon pada AUD-008: prakiraan ditampilkan untuk dua dan empat pekan ke depan, mengikuti keluaran A.7. Keluaran satu sampai empat pekan dalam draf lama tidak digunakan; riwayat masukan satu sampai delapan pekan tidak dianggap horizon keluaran.

DEC-008b: pengguna memilih prakiraan beras produsen per provinsi serta estimasi turunan GKP/GKG untuk dua/empat pekan. Estimasi gabah dikonversi dengan parameter jenis gabah tersendiri dan diberi label hasil turunan. Kinerja/cakupan interval model beras tidak otomatis membuktikan kinerja hasil konversi gabah; keduanya perlu dibedakan dalam evaluasi.

DEC-008c menetapkan SHAP untuk prakiraan dan perbedaan harga antarwilayah, mempertahankan lingkup penjelasan proposal pada AUD-009. Default IA berupa teks statis sebagai pengganti penjelasan model wilayah tidak digunakan sebagai pemenuhan kebutuhan SHAP. Rancangan model/fitur serta validasi masih diperlukan; penjelasan komponen estimator rumus tidak disebut SHAP dan kontribusi model tidak dianggap bukti sebab-akibat.

DEC-008d: jika model belum memenuhi target evaluasi, gunakan baseline yang telah dievaluasi dengan label “Prakiraan baseline”; hasil model tetap dilaporkan. SHAP harus sesuai model yang dijelaskan. Fallback bukan bukti tercapainya target AI dan interval baseline tidak otomatis mewarisi cakupan model lain.

DEC-009a menetapkan sumber harga petani pada AUD-010 sebagai data gabah pengamatan; harga GKP/GKG dan ekuivalen beras dibedakan, estimasi harga wajar ditampilkan terpisah. Tidak ada penggantian data pengamatan yang hilang dengan estimasi atau transaksi simulasi. Transaksi nyata terverifikasi tetap lingkup inkubasi, bukan diaktifkan oleh pilihan sumber ini.

DEC-009b menetapkan pembanding peta pada AUD-011 sebagai median harga provinsi valid untuk komoditas, tingkat pasar dan periode sama. Selisih bertanda menunjukkan lebih murah/mahal; disparitas maksimum terhadap minimum ditampilkan terpisah. Batas kategori lama AUD-026 belum otomatis disahkan dan perlu diselaraskan dengan selisih bertanda.

DEC-009c: transaksi simulasi MVP final tersedia untuk seluruh provinsi, menggantikan batas demo Jawa Timur pada Q-11 lama. Papan harga dan peta mengikuti cakupan data valid; cakupan nasional transaksi tidak menjadi klaim bahwa seluruh wilayah memiliki acuan harga/model atau telah divalidasi lapangan.

DEC-010a menetapkan login petani dan pembeli menggunakan nomor HP dan OTP pada AUD-014. Kanal/penyedia pengiriman belum dipilih; ini tidak mengesahkan OTP statis sebagai autentikasi pengguna sebenarnya. Metode Admin serta aturan privasi nomor HP perlu dirinci terpisah.

DEC-010b menetapkan pembukaan nomor HP antar pihak setelah kontrak Disetujui saja, terbatas pada kedua pihak dalam kontrak terkait. Ini memperjelas AUD-015; akses Admin, penyimpanan dan perlakuan setelah pembatalan belum ditetapkan oleh keputusan ini.

DEC-010c menetapkan notifikasi transaksi di dalam aplikasi bagi petani dan pembeli; tidak mewajibkan WhatsApp/SMS. Ini menyelesaikan pilihan kanal dan penerima pada AUD-013. Kanal OTP terpisah, dan peringatan dini lonjakan otomatis tetap lingkup inkubasi.

DEC-003a menetapkan Admin operasional untuk pengelolaan data harga, parameter, pengguna, moderasi tawaran dan log audit serta pemantauan transaksi. Admin tidak boleh menawar, menyetujui, membatalkan atau menyelesaikan kontrak atas nama pengguna. Ini memperjelas batas aksi pada AUD-002; visibilitas data pribadi tidak otomatis menjadi akses tanpa batas.

DEC-002a menyelesaikan pilihan monetisasi final pada AUD-016: seluruh fitur MVP gratis dan transaksi tanpa komisi. Langganan produsen dan API berbayar masuk rencana hilirisasi; tidak ada gerbang langganan atau penagihan yang diwajibkan pada MVP final.

DEC-011a: pengguna memilih arah visual baru untuk SAMBUNG, dengan format UI Guidelines tetap mengikuti contoh referensi. Palet/font draf lama maupun identitas Jagains tidak otomatis dipakai. Pemilihan karakter visual dan nilai token masih terbuka; aturan fungsional lampu harga tetap berlaku.

DEC-011b: karakter visual dipilih sebagai layanan pertanian modern dengan palet referensi pengguna: Forest Green #3E5A3A, Olive Green #8A9A3A, Sunflower Yellow #FFD55A, Honey Gold #F4A62A, Terracotta #C86B3C dan Warm Cream #FFF3D6. Gambar disimpan di `docs/ui_reference/sambung-color-reference.png`. Ini sumber tambahan preferensi visual setelah snapshot audit, bukan perubahan lima sumber asli. Peran warna/token dan kontras belum ditetapkan; larangan hijau merek pada draf lama perlu diselaraskan dengan pilihan pengguna.

DEC-011c: Forest Green #3E5A3A dipilih sebagai warna utama tombol/navigasi aktif, dengan latar Warm Cream dan aksen kuning/emas. Token status, ikon dan teks harus membedakan identitas merek dari penilaian harga. Pasangan kontras dan rincian token belum diuji pada tahap klarifikasi ini.

DEC-011d: Plus Jakarta Sans dipilih untuk judul dan Atkinson Hyperlegible Next untuk isi/kontrol; harga memakai angka tabular. Ini menggantikan pasangan font draf lama untuk identitas final. Skala, bobot, dukungan angka tabular dan pemuatan font masih perlu dirinci/diverifikasi pada fase3.

DEC-011e: MVP final mendukung mode terang dan gelap yang dapat dipilih pengguna. UI Guidelines perlu memuat token dan pasangan kontras kedua mode, termasuk komponen, grafik/peta serta status harga. Kontras belum dinyatakan lolos pada tahap klarifikasi.

DEC-007f memilih P10/P90 rasio historis valid per jenis gabah dan wilayah sebagai batas estimator. Ini menetapkan pilihan metode pada AUD-028, menggantikan anggapan faktor tetap93–97% berlaku universal. Dataset, rendemen, kalibrasi dan kriteria kecukupan belum terbukti tersedia; persentil rasio historis bukan bukti otomatis cakupan interval prakiraan80%.

DEC-012a menetapkan target SUS≥68 dengan minimal lima responden total yang mewakili petani dan pembeli. Angka pada Q-15/NFR lama kini menjadi target proyek terkonfirmasi, bukan hasil pengujian yang sudah dicapai. Hasil aktual dan masalah kegunaan tetap dilaporkan apa adanya.

DEC-010d menetapkan CSV ringkasan harga publik dan pasokan, tanpa nomor HP atau data pribadi. Daftar kolom dan izin per peran perlu diturunkan pada fase2; unduhan tidak otomatis memperluas hak akses data pengguna.

DEC-010e menetapkan login Admin melalui halaman terpisah dengan email dan kata sandi. Akun dibuat pengelola tanpa pendaftaran publik, terpisah dari OTP petani/pembeli. Otorisasi server tetap mengikuti batas peran Admin DEC-003a.

DEC-003b: katalog dan detail tawaran memerlukan login, sedangkan papan harga, peta, prakiraan dan bantuan terbuka untuk publik. Ekspor pasokan harus mengikuti batas tersebut; autentikasi bukan izin melihat nomor HP atau mengajukan pesanan tanpa peran pembeli.

DEC-003c: satu akun biasa memiliki satu peran yang dipilih saat pendaftaran, petani/kelompok tani atau penggilingan/pengolah, tanpa pergantian ruang kerja penjual/pembeli pada MVP. Peran Admin tetap melalui pengelola, bukan pendaftaran publik.

DEC-010f menetapkan lokasi tawaran sampai kecamatan, beserta kabupaten/kota dan provinsi; alamat lengkap serta titik rumah tidak ditampilkan. Pilihan ini tidak mengaktifkan pengungkapan lokasi rinci setelah kesepakatan atau kewajiban mengambil GPS rumah.

## 7. Kesiapan fase berikutnya

- Audit lima sumber awal selesai;33temuan dan pemeriksaan25F/15Q lama tetap merupakan catatan keadaan saat audit. Pembaruan keputusan dicatat terpisah dan tidak mengubah isi sumber asli.
- Keputusan inti telah dijawab dalam49butir utama/subbutir, termasuk jawaban terakhir DEC-011f: shadcn/ui dan Tailwind CSS v4. Versi/basis paket serta kode penerapan belum tersedia untuk diperiksa.
- Lihat [ringkasan fase1](phase-1-summary.md) untuk hasil lintas topik dan tabel bukti/detail yang masih perlu ditindaklanjuti. Metode estimator/model terpilih tidak berarti dataset, parameter atau hasilnya sudah tervalidasi.
- Pengguna mengonfirmasi ringkasan melalui pilihan A pada 6 November 2026. Fase 1 selesai dan ditutup. Sesudahnya pengguna meminta fase 2 dimulai; SRS/IA v0.1 disusun untuk review, fase 3 belum dimulai. Daftar validasi teknis tetap terbuka sebagaimana ringkasan.
- Detail yang mengubah perilaku atau lingkup tetap memerlukan keputusan eksplisit pada penyusunan berikutnya. Jangan menyebut seluruh masalah implementasi sudah selesai hanya karena arah kebutuhan telah disepakati.

