# SAMBUNG

Istilah domain untuk informasi harga gabah dan transaksi simulasi antara petani dan penggilingan/pengolah. Acuan istilah bersama bagi SRS, IA dan UI Guidelines.

## Pelaku dan transaksi

**Petani**:
Pelaku penjual gabah, termasuk akun yang mewakili kelompok tani.
_Avoid_: Produsen, bila yang dimaksud penjual gabah di aplikasi.

**Pembeli**:
Penggilingan atau pengolah yang mencari pasokan dan mengajukan pesanan gabah.
_Avoid_: Produsen tanpa penjelasan; istilah itu juga dipakai untuk tingkat pasar data beras.

**Tawaran panen**:
Publikasi petani mengenai satu jenis gabah, lokasi, volume dan harga yang diminta; dapat melayani beberapa pesanan parsial.
_Avoid_: Penawaran pembeli, kontrak.

**Pesanan**:
Permintaan pembeli atas sebagian atau seluruh volume satu tawaran panen dengan harga yang diajukan.
_Avoid_: Tawaran panen, pesanan pembayaran.

**Kontrak simulasi**:
Catatan bersama kedua pihak mengenai pesanan, negosiasi, kesepakatan dan penyelesaian simulasi; bukan bukti terjadinya pembayaran atau pengiriman nyata.
_Avoid_: Kontrak nyata, transaksi terverifikasi.

**Tawaran harga**:
Harga yang diajukan salah satu pihak dalam negosiasi sebuah kontrak simulasi.
_Avoid_: Tawaran panen, bila yang dimaksud hanya pengajuan harga dalam negosiasi.

**Tawaran harga aktif**:
Tawaran harga terakhir yang masih dapat diterima pihak lawan sebelum kontrak berakhir atau disepakati.
_Avoid_: Semua harga historis sebagai pilihan yang masih berlaku.

**Reservasi volume**:
Bagian volume tawaran panen yang dicadangkan bagi pesanan yang masih menunggu kesepakatan.
_Avoid_: Penjualan selesai, stok terverifikasi.

**Volume tersedia**:
Volume tawaran yang masih dapat dipesan setelah memperhitungkan reservasi, kesepakatan aktif dan volume selesai.
_Avoid_: Volume total, stok gudang terverifikasi.

**Disetujui**:
Keadaan kontrak ketika pihak lawan menerima tawaran harga aktif yang sudah disetujui pengajunya.
_Avoid_: Selesai, lunas.

**Selesai**:
Keadaan akhir kontrak simulasi setelah petani dan pembeli masing-masing mengonfirmasi penyelesaian.
_Avoid_: Pembayaran berhasil, barang diterima secara terverifikasi.

## Moderasi dan akun

**Temuan moderasi**:
Catatan Admin mengenai masalah informasi tawaran yang dimintakan perbaikan atau penarikan kepada petani; berbeda dari penilaian harga dan verifikasi mutu fisik.
_Avoid_: Lampu harga, kontrak bermasalah sebagai satu status yang sama.

**Menunggu Peninjauan**:
Keadaan temuan moderasi setelah petani menyatakan perbaikan dan sebelum Admin menutup temuan.
_Avoid_: Menunggu Kesepakatan, yang merupakan keadaan kontrak.

**Tawaran Ditarik**:
Tawaran panen yang telah dihentikan pemiliknya dari penerimaan pesanan baru dan tidak dapat diterbitkan kembali; riwayatnya tetap dibedakan dari tawaran baru.
_Avoid_: Seluruh kontrak pada tawaran tersebut dibatalkan, karena kontrak Disetujui tetap berjalan.

**Permintaan penutupan akun**:
Permintaan pengguna untuk mengakhiri akses akun, dengan transaksi aktif dituntaskan terlebih dahulu dan kebijakan penghapusan data yang telah ditentukan.
_Avoid_: Pembatalan seluruh kontrak otomatis, koreksi peran.

## Gabah dan harga

**Harga minta**:
Harga per kilogram yang dicantumkan petani pada tawaran panen, bukan harga pengamatan pasar atau kesepakatan akhir kontrak.
_Avoid_: Harga wajar, harga transaksi nyata.

**GKP**:
Gabah Kering Panen, jenis gabah yang dibedakan dari GKG dalam tawaran dan perhitungan harga.
_Avoid_: Semua gabah tanpa membedakan jenisnya.

**GKG**:
Gabah Kering Giling, jenis gabah dengan parameter acuan tersendiri untuk perhitungan harga.
_Avoid_: GKP dengan parameter yang disalin tanpa dasar.

**Rendemen**:
Perbandingan hasil beras terhadap jumlah gabah asal untuk konversi yang sesuai dengan jenis gabahnya.
_Avoid_: Margin harga, persentase mutu.

**Harga pengamatan**:
Harga yang tercatat dari sumber pengamatan dan disertai komoditas, tingkat pasar, wilayah serta periode.
_Avoid_: Harga estimasi, harga kontrak simulasi.

**Harga beras produsen**:
Harga beras pada tingkat pasar produsen/penggilingan dalam sumber data harga.
_Avoid_: Harga tawaran petani atau harga beli pengguna tanpa menjelaskan tingkat pasar.

**Ekuivalen beras**:
Nilai harga gabah yang dinyatakan dalam satuan beras melalui rendemen yang sesuai; merupakan hasil konversi, bukan pengamatan langsung harga beras petani.
_Avoid_: Harga beras petani nyata.

**Rentang harga wajar**:
Acuan estimasi batas bawah dan atas harga gabah menurut jenis, wilayah, periode serta parameter yang tersedia.
_Avoid_: Jaminan harga jual, harga wajib.

**Lampu harga**:
Penilaian posisi harga terhadap rentang wajar dalam status hijau, kuning atau merah beserta alasan; acuan tidak tersedia merupakan keadaan terpisah.
_Avoid_: Warna merek, jaminan mutu.

**Prakiraan baseline**:
Prakiraan dari metode pembanding yang identitas dan hasil evaluasinya dinyatakan secara jelas.
_Avoid_: Hasil model AI unggulan tanpa bukti.

**Estimasi turunan gabah**:
Estimasi GKP/GKG yang dihitung dari prakiraan beras dan parameter konversi, bukan prediksi langsung model harga gabah.
_Avoid_: Observasi gabah, prediksi langsung gabah.

**Selisih terhadap median**:
Persentase harga suatu provinsi di atas atau di bawah median provinsi berdata valid untuk komoditas, tingkat pasar dan periode yang sama.
_Avoid_: Disparitas maksimum–minimum.

**Disparitas keseluruhan**:
Persentase selisih harga provinsi termahal terhadap termurah pada himpunan data yang setara.
_Avoid_: Selisih satu provinsi terhadap median.

**Penjelasan SHAP**:
Penjelasan kontribusi fitur terhadap keluaran model tertentu; tidak membuktikan hubungan sebab-akibat.
_Avoid_: Penjelasan komponen rumus, penyebab pasti perubahan harga.
