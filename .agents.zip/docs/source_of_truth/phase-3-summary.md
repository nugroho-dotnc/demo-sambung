# SAMBUNG — Ringkasan Fase 3

6 November 2026 · **Draf untuk review pengguna**. Pasangan SRS/IA v0.2 tetap baseline yang disetujui. UI Guidelines v0.2, aset tema dan matriks v0.4 belum disetujui sebagai baseline paket.

## Keluaran

- [UI Guidelines](UI_GUIDELINES_SAMBUNG.md): 24 aturan UI, delapan bagian sesuai referensi, palet pengguna, dua mode, tipografi, layout, komponen domain dan keadaan aplikasi.
- [Manifest token](assets/sambung-tokens.json) sebagai sumber nilai; [kontrak CSS](assets/sambung-theme.css) dan [audit warna](ui-color-audit.md) dibangun dengan [skrip](../plan/build_ui_tokens.py).
- [Matriks ketertelusuran](traceability-matrix.md): 74 keputusan → kebutuhan/aturan → halaman → AC → UI. Semua 31 FR mempunyai representasi UI; kebenaran proses backend tetap diuji melalui AC tersendiri.
- [Indeks paket](README.md) menyatukan SRS, IA dan UI beserta status serta cara memperbaruinya.

## Adaptasi format referensi

| Bagian referensi | Bagian guideline SAMBUNG | Adaptasi |
|---|---|---|
| 1. Pendahuluan & Filosofi | §1 | Hierarki harga, pelaku, sumber dan baseline SRS/IA |
| 2. Warna & Semantic Tokens | §2 | Base netral Jagains, primary SAMBUNG, warna aksen/status, OKLCH, grafik/peta dan audit dua mode |
| 3. Tipografi Rasio Emas | §3 | Dasar 16 px, jangkar φ dan pembulatan; Plus Jakarta Sans/Atkinson Hyperlegible Next |
| 4. Spacing, Layout, Kedekatan | §4 | Spacing 4 px, radius, breakpoint, navigasi per peran, fokus dan sentuh 44 px |
| 5. Komponen shadcn/ui | §5 | Fungsi toast dipertahankan; API mengikuti basis yang dipilih saat implementasi; komponen harga/kontrak/privasi/data |
| 6. resources/css/app.css | §6 | Kontrak integrasi Tailwind v4, bukan perubahan pada aplikasi yang sudah tersedia |
| 7. Pantangan | §7 | Larangan penyajian dan aksi yang bertentangan dengan kebutuhan SAMBUNG |
| 8. Ringkasan Perubahan | §8 | Membandingkan draf SAMBUNG historis, tanpa mengarang rilis v1.0 |

Isi domain Jagains tidak diadopsi. Palet, font, mode, stack serta ukuran mengikuti keputusan pengguna; geometri peta, provider autentikasi, basis primitive, font binary dan protokol uji tetap perlu implementasi/validasi. Revisi visual DEC-021a mengikuti instruksi pengguna; rincian desain tetap diajukan sebagai satu dokumen untuk review, tanpa menambahkan perilaku bisnis atau menimpa SRS/IA.

## Revisi visual berdasarkan mockup

Instruksi pengguna dicatat sebagai DEC-021a: base netral Jagains, primary SAMBUNG tetap, warna hangat hanya aksen/status. Keenam PNG sudah diperiksa secara visual dan dipetakan ke halaman IA pada guideline §1.4. Pola topbar/sidebar, ringkasan, form + acuan, action bar, tabel/grafik dan area peta dijabarkan di §4.3. Font, ukuran aksesibilitas dan kebutuhan bisnis tetap mengikuti baseline. Perbedaan isi lama pada gambar diselesaikan melalui SRS/IA, bukan diadopsi sebagai kebutuhan baru.

Background/card/popover/secondary/muted/accent/border/sidebar mengikuti nilai netral Jagains, dengan canvas alias muted. Input/ring memakai override solid untuk target kontras, sidebar aktif memakai tint primary, dan helper gray tidak disahkan di atas canvas/tint netral. Warm Cream tidak lagi menjadi base halaman. Grafik menggunakan seri utama hijau dan pembanding netral; palet hangat tersedia sebagai highlight/status.

## Pemeriksaan dan batas bukti

Audit warna menghitung **106/106 pasangan solid memenuhi ambang masing-masing**, memakai nilai penuh sebelum pembulatan laporan. Nilai OKLCH netral Jagains dipertahankan persis; warna sumber HEX dikonversi dan kembali ke kode sRGB 8-bit yang sama. Olive, Honey dan Terracotta mentah di Warm Cream tidak disahkan untuk teks normal kecil; guideline menyediakan turunan semantik yang diuji. Hasil tidak mencakup semua interpolasi peta, opacity, gambar, state browser atau kepatuhan aksesibilitas menyeluruh.

Pemeriksaan dokumen mencakup delapan bagian, 24 aturan UI, cakupan 31 FR, 36 AC, 20 BR, 10 NFR, 74 keputusan, ID rujukan, tautan lokal, tabel serta keseimbangan pagar kode/Mermaid. Inventaris IA tetap 32 halaman/panel, bukan rute baru yang ditambahkan guideline. Lima sumber awal dipertahankan dan dibandingkan melalui SHA-256. Pemeriksaan struktur Mermaid bukan hasil render diagram.

Review independen menemukan header tabel ketertelusuran yang tidak sesuai jumlah sel, kombinasi kelas font yang perlu diperjelas, dan penomoran bagian ganda. Semuanya diperbaiki dan diperiksa ulang; tidak ada temuan kritis atau penting yang tersisa pada review perubahan tersebut. Audit v0.1 sebelumnya menghitung 104 pasangan unik setelah menghapus dua pemeriksaan berulang. Revisi v0.2 memiliki 106 pasangan unik dengan cakupan sidebar dan pembatasan helper gray; kedua hitungan memiliki cakupan berbeda.

Pemeriksaan dapat diulang dari root workspace dengan `python docs/plan/build_ui_tokens.py`, lalu `python docs/plan/verify_source_of_truth.py`. Keduanya selesai dengan exit 0 pada pemeriksaan fase ini.

Prototipe React/Vite kini tersedia di workspace dan memakai dependensi Radix/Tailwind v4. Tema revisi v0.2 ini belum dipasang atau dikompilasi ke prototipe; audit font, keyboard, zoom, pembaca layar, responsif, privasi, SUS, kinerja dan model tidak dijalankan pada revisi dokumentasi ini. Laporan build prototipe terpisah bukan bukti tema revisi ini sudah diterapkan. Target 5 detik dan target evaluasi proposal tetap target. Checklist implementasi berada pada guideline §6.3; ketergantungan data/model/kebijakan tetap pada SRS §7.

## Gerbang review

Pengguna meninjau UI Guidelines v0.2 bersama SRS/IA v0.2 dan aset pendukung. Persetujuan eksplisit diperlukan untuk mencatatnya sebagai baseline paket terkonfirmasi sesuai rencana. Sampai saat itu, fase 3 berstatus **penyusunan selesai untuk review; persetujuan tertunda**. Persetujuan desain tidak menutup pekerjaan teknis atau mengubah target menjadi hasil pengujian.
