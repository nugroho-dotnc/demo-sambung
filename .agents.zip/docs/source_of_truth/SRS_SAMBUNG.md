# SAMBUNG — Software Requirements Specification

| Metadata | Nilai |
|---|---|
| Versi | 0.2 — baseline fase 2 disetujui untuk fase 3 |
| Tanggal | 6 November 2026 |
| Target | MVP final lomba 26–28 November 2026 |
| Dasar keputusan | [Ringkasan fase 1 yang disetujui](phase-1-summary.md), [49 keputusan fase 1 dan 24 keputusan klarifikasi fase 2](decision-log.md), proposal |
| Status persetujuan | Disetujui pengguna melalui pilihan A: tetapkan SRS/IA v0.2 sebagai dasar fase ketiga. Bukti/rancangan teknis yang masih terbuka tetap mengikuti §7 |
| Dokumen terkait | [IA](IA_SAMBUNG.md), [ketertelusuran](traceability-matrix.md), [glosarium](GLOSSARY.md), [audit](verification-report.md) |

## 1. Tujuan, acuan dan cara membaca

SAMBUNG membantu petani membandingkan harga gabah, mencari pembeli alternatif dan menjalankan kesepakatan simulasi dengan penggilingan/pengolah. Informasi harga, prakiraan dan penjelasan model mendukung keputusan; tidak menjamin harga, mutu atau terlaksananya transaksi nyata.

Urutan acuan: keputusan pengguna fase 1 beserta klarifikasi fase 2 yang dicatat mengatasi default dokumen lama; klarifikasi terbaru berlaku pada bagian yang diperjelasnya; proposal menjelaskan komitmen yang tidak diubah keputusan; SRS menetapkan perilaku; IA mengatur halaman/navigasi; UI Guidelines pada fase 3 mengatur penyajian. Draf lama tetap arsip dan bukan acuan yang mengalahkan keputusan terbaru.

Referensi proposal: [proposal.txt](../proposal/proposal.txt) §3/§4.1/§4.2/A.7/A.9/A.12. Nomor FR lama dipertahankan sejauh cocok; perluasan/pemisahan tercatat di matriks. Struktur ini tidak mengklaim kepatuhan penuh ISO/IEC/IEEE 29148.

**Status pernyataan:** kebutuhan yang menurunkan keputusan/proposal ditulis wajib. `OPN-*` berarti belum diputuskan atau belum ada bukti; usulan di dalamnya tidak otomatis menjadi requirement final. Contoh angka merupakan ilustrasi, kecuali sumber/periode pengamatan dinyatakan. Tidak ada hasil uji aplikasi/model dalam dokumen ini.

## 2. Lingkup dan lingkungan operasi

### 2.1 Target final

Seluruh FR pada §4 ditargetkan tersedia pada final; label **W** berarti komitmen wajib proposal, **T** berarti prioritas tinggi proposal yang tetap target final, **D** berarti kebutuhan pendukung/penambahan yang disepakati atau diturunkan agar alur dapat berjalan. T/D bukan daftar yang boleh dihilangkan bila waktu tersisa. Data bersih, harga wajar, lampu dan papan harga adalah milestone prototipe 10 November.

| Termasuk MVP | Ditunda / di luar MVP |
|---|---|
| GKP/GKG; penawaran, pembelian parsial, reservasi, negosiasi dan kontrak simulasi nasional | Transaksi nyata terverifikasi, pembayaran, pengiriman/logistik, verifikasi mutu fisik |
| Estimator rumus, lampu harga; prakiraan 2/4 pekan, SHAP prakiraan/wilayah, fallback terevaluasi | Retraining otomatis, peringatan dini lonjakan otomatis, multibahasa pada inkubasi |
| Harga pengamatan dan konversinya, peta/tabel, dasbor, notifikasi aplikasi, CSV | Langganan berbayar, billing, API komersial; ruang kerja Pendamping/Dinas |
| OTP petani/pembeli; Admin email/sandi; mode terang/gelap | Pemilihan backend/database/runtime ML/provider OTP belum menjadi keputusan fase 1 |

Seluruh fitur final gratis, tanpa komisi transaksi. Transaksi seluruhnya simulasi dan dilarang menjadi data latih atau seri harga pengamatan. Layanan publik dapat dibaca tanpa akun; katalog tidak dapat dibaca tanpa login. Lingkungan produk berupa aplikasi web responsif. shadcn/ui dan Tailwind CSS v4 dipilih untuk frontend; versi/basis/API paket belum dibuktikan terpasang. Tidak ada kewajiban PWA/offline yang sudah disepakati.

### 2.2 Aktor dan batas otorisasi

| Kemampuan | Publik | Petani | Pembeli | Admin |
|---|---|---|---|---|
| Harga/peta/prakiraan/bantuan dan CSV harga publik | Baca | Baca | Baca | Baca |
| Katalog dan detail tawaran | Tidak | Tidak; tawaran sendiri melalui ruang kerja petani | Baca | Baca untuk pemantauan |
| Membuat tawaran | Tidak | Milik sendiri | Tidak | Tidak atas nama petani |
| Mengajukan pesanan | Tidak | Tidak | Atas tawaran terbit/tersedia | Tidak |
| Negosiasi, penerimaan, pengakhiran, selesai | Tidak | Hanya kontrak sendiri, sesuai status | Hanya kontrak sendiri, sesuai status | Tidak |
| Nomor HP pihak lawan | Tidak | Hanya kontrak sendiri yang saat itu berstatus Disetujui | Hanya kontrak sendiri yang saat itu berstatus Disetujui | Nomor tersamar saja; DEC-014c |
| CSV pasokan | Tidak | Tidak untuk pasokan petani lain; CSV harga publik tetap boleh | Data katalog yang boleh dibaca | Sesuai pemantauan, tanpa data pribadi |
| Parameter, impor, pengguna, moderasi, log | Tidak | Tidak | Tidak | Kelola; tidak mengubah kontrak atas nama pihak |

Satu akun biasa satu peran; koreksi/pergantian peran oleh pengguna atau Admin di luar MVP (DEC-020a). Pendamping/Dinas tidak mendapat peran operasional khusus. Pengelolaan akun atau moderasi bukan jalan untuk membatalkan kontrak. Semua pemeriksaan izin berlaku di server termasuk tautan langsung, respons data dan ekspor.

## 3. Model domain dan aturan bisnis

### 3.1 Objek dan identitas

Glosarium menjadi acuan istilah. Tawaran panen berbeda dari tawaran harga. **Pesanan dan kontrak simulasi merupakan satu riwayat transaksi beridentitas tetap**: saat pengajuan berhasil, catatan masuk Menunggu Kesepakatan; setelah diterima, catatan yang sama menjadi Disetujui. Penyebutan “kontrak otomatis” tidak membuat dua catatan yang volumenya dihitung ganda. Satu tawaran panen memiliki banyak riwayat kontrak; satu kontrak merujuk satu tawaran dan satu pembeli.

### 3.2 Katalog aturan otoritatif

| ID | Aturan wajib | Dasar |
|---|---|---|
| BR-001 | Semua kontrak `simulasi`; gratis/tanpa komisi; tidak menjadi harga pengamatan/data latih | DEC-004/002a |
| BR-002 | Setiap tawaran satu jenis gabah GKP atau GKG, lokasi sampai kecamatan, volume positif maksimal dua desimal kg dan harga positif rupiah bulat per kg; presisi berlebih ditolak, bukan dibulatkan diam-diam; mutu boleh Belum diukur | DEC-007a/c/d, DEC-010f; validasi domain |
| BR-003 | Volume tersedia = total − reservasi Menunggu − volume Disetujui − volume Selesai. Nilai tidak boleh negatif. Batal/tolak/kedaluwarsa tidak mengurangi tersedia; pelepasan hanya sekali | DEC-005a/b/i/j |
| BR-004 | Pengajuan memeriksa stok dan mencadangkan volume secara atomik; jumlah pesanan positif dan ≤ tersedia. Pemohon maupun pemilik tawaran tidak boleh sedang menunggu penutupan akun. Satu permintaan ulang tidak membuat pesanan/reservasi ganda | DEC-005a/b, DEC-014e |
| BR-005 | Tenggat = waktu pengajuan + durasi saat pengajuan (awal 24 jam). Perubahan Admin hanya pesanan baru; negosiasi tidak reset. Sebelum setiap mutasi pesanan Menunggu, periksa tenggat di server. Saat waktu kini ≥ tenggat, selesaikan transisi Kedaluwarsa terlebih dahulu; harga balik, terima, tolak maupun batal tidak dapat menggantikan status itu | DEC-005c/d/f; konsekuensi batas waktu |
| BR-006 | Harga awal dapat sama/berbeda dari harga tawaran panen; hanya pihak lawan dapat menerima tawaran harga aktif. Tawaran balik tanpa batas jumlah, menggantikan harga aktif tanpa mewarisi persetujuan pihak lawan | DEC-005e/f/g |
| BR-007 | Menunggu: pembeli membatalkan, petani menolak, alasan wajib. Tambahan DEC-013b: penarikan tawaran oleh pemilik otomatis membatalkan pesanan Menunggu yang belum kedaluwarsa, dengan alasan penarikan tercatat dan notifikasi. Disetujui sebelum Selesai: salah satu dapat membatalkan, alasan wajib; penarikan tawaran tidak membatalkannya. Selesai/terminal tidak dibuka ulang | DEC-005i/j, DEC-013b |
| BR-008 | Selesai memerlukan dua konfirmasi pihak berbeda; satu konfirmasi/permintaan ulang tidak cukup. Batal/selesai bersamaan menghasilkan satu keadaan akhir; volume konsisten | DEC-005h/i |
| BR-009 | Estimator per jenis/wilayah: q=harga gabah diamati/(harga beras produsen×rendemen jenis); L_asal=Pberas×R×P10(q), U_asal=Pberas×R×P90(q); L/U operasional dibulatkan ke rupiah terdekat, pecahan 0,5 ke atas sesuai DEC-018a. Nilai asal tetap disimpan. Sumber/satuan/periode harus setara; data/parameter belum cukup → Tidak tersedia | DEC-007a/b/e/f |
| BR-010 | Mutu deklaratif tidak mengoreksi angka harga; Belum diukur bukan nol. Jangan mengklaim mutu terverifikasi atau mengarang ambang mutu | DEC-007c/d |
| BR-011 | Lampu: L ≤ P ≤ U hijau; L×(1−δ) ≤ P<L kuning; P<L×(1−δ) merah; P>U kuning. δ awal 0,03, dapat diubah Admin; makna sama bagi kedua pelaku. Acuan tidak tersedia bukan salah satu warna | DEC-006b/c, DEC-007e |
| BR-012 | Merah perlu alasan peringatan dan konfirmasi eksplisit terkait harga sebelum penerbitan/pengajuan/penerimaan relevan. Tidak memaksa kenaikan harga. Perubahan ambang untuk pemeriksaan berikutnya; riwayat lama/kontrak Disetujui tidak ditulis ulang | DEC-006a/d |
| BR-013 | Prakiraan beras produsen 2/4 pekan, pita 80% dievaluasi; GKP/GKG hasil konversi diberi label turunan, tanpa mewarisi klaim akurasi/cakupan beras otomatis | DEC-008a/b; proposal A.7 |
| BR-014 | SHAP cocok dengan model/versi/keluaran; penjelasan wilayah memakai data/model sebanding. Komponen rumus bukan SHAP; kontribusi fitur bukan kausalitas | DEC-008c/d |
| BR-015 | Pemilihan metode per provinsi dan horizon: model memenuhi target akurasi/interval → model; belum memenuhi → baseline terevaluasi dengan label; hasil model tetap dilaporkan. Baseline/interval belum valid → jelaskan belum tersedia, tidak membuat data/penjelasan fiktif | DEC-008d, DEC-017a |
| BR-016 | Harga petani dari observasi; ekuivalen beras = harga gabah/R yang sesuai. Bagian petani = ekuivalen/eceran×100% hanya untuk perbandingan setara; jika tidak setara/data hilang, jangan tampilkan persentase yang menyesatkan | DEC-009a; proposal §4.2; turunan kesetaraan satuan |
| BR-017 | Selisih provinsi=(P−median)/median×100%; disparitas=(maks−min)/min×100%. Komoditas/pasar/periode sama, pembanding positif, provinsi valid saja; kosong bukan nol | DEC-009b |
| BR-018 | Nomor HP tidak untuk katalog/CSV/publik; hanya kedua pihak pada kontrak yang saat itu berstatus Disetujui. Setelah Dibatalkan atau Selesai, sembunyikan kembali kontak pihak lawan pada kontrak itu tanpa menghapus riwayat. Satu konfirmasi selesai belum mengubah Disetujui, dua konfirmasi menutup akses kontak. Lokasi tawaran maksimal kecamatan. Admin hanya mendapat nomor tersamar melalui panel/respons/ekspor; tanpa tombol membuka nomor lengkap. Retensi masih mengikuti OPN-004 | DEC-010b/d/f, DEC-014a/b/c |
| BR-019 | Admin mengelola operasional, tidak bertindak atas kontrak. Perubahan parameter/moderasi/publikasi data dan peristiwa kontrak dicatat pelaku/waktu/versi | DEC-003a; kebutuhan keterlacakan |
| BR-020 | Lima tindakan utama alur normal lintas pihak, bukan lima klik/per peran. Login/navigasi/negosiasi tambahan dikecualikan dan wajib disebut pada laporan | DEC-005k |

Harga/volume masukan harus terbatas, numerik, bukan NaN/tak hingga dan >0; persentase mutu yang diisi berada 0–100. Batas L/U untuk tampilan dan lampu dibulatkan ke rupiah terdekat dengan 0,5 ke atas (DEC-018a); simpan juga hasil asal. Masukan harga per kg adalah rupiah bulat dan volume maksimal dua desimal kg (DEC-018b); isian berlebih harus diperbaiki, bukan dibulatkan otomatis. Presisi rasio, interval prakiraan dan interpolasi kuantil masih OPN-008; contoh berikut dipilih jauh dari batas pembulatan bila tidak dinyatakan uji batas. Semua contoh merupakan ilustrasi.

### 3.3 Mesin status kontrak

| Dari | Aksi/pelaku | Syarat | Ke | Efek volume |
|---|---|---|---|---|
| Belum ada | Ajukan pesanan / pembeli | Tawaran terbit, volume tersedia, harga valid, konfirmasi merah jika relevan | Menunggu Kesepakatan | Cadangkan volume |
| Menunggu Kesepakatan | Harga balik / pihak kontrak | Sebelum tenggat, harga valid, versi aktif tidak berubah bersamaan | Menunggu Kesepakatan | Tetap |
| Menunggu Kesepakatan | Terima / lawan pengaju harga aktif | Sebelum tenggat, versi harga aktif cocok, konfirmasi merah jika relevan | Disetujui | Pindah reservasi→volume Disetujui; tersedia tetap |
| Menunggu Kesepakatan | Tolak / petani | Sebelum tenggat, alasan wajib | Ditolak | Lepaskan |
| Menunggu Kesepakatan | Batalkan / pembeli | Sebelum tenggat, alasan wajib | Dibatalkan | Lepaskan |
| Menunggu Kesepakatan | Tarik tawaran / petani pemilik, efek otomatis sistem | Sebelum tenggat; catat alasan penarikan dan beri notifikasi pembeli | Dibatalkan | Lepaskan sekali; tawaran tetap Ditarik dan tidak dapat dipesan |
| Menunggu Kesepakatan | Tenggat / sistem | Waktu kini ≥ tenggat | Kedaluwarsa | Lepaskan |
| Disetujui | Konfirmasi selesai / pihak pertama | Pihak kontrak, belum konfirmasi | Disetujui | Tetap; catat konfirmasi 1/2 |
| Disetujui | Konfirmasi selesai / pihak kedua | Konfirmasi kedua pihak berbeda | Selesai | Pindah Disetujui→Selesai; tidak dilepas |
| Disetujui | Batalkan / salah satu pihak | Belum Selesai, alasan wajib | Dibatalkan | Lepaskan, termasuk jika konfirmasi 1/2 |
| Terminal | Ulang aksi | Status sudah Ditolak/Dibatalkan/Kedaluwarsa/Selesai | Tetap | Tidak mengulangi efek |

Tidak ada kedaluwarsa otomatis tahap Disetujui berdasarkan tenggat negosiasi. Pembatalan dan penyelesaian tidak boleh sama-sama berhasil. Permintaan penutupan saat kontrak aktif mengikuti DEC-014d/e/f: dicatat, transaksi baru dihentikan, akses transaksi lama tetap, penutupan diproses setelah semua aktif berakhir. Kebijakan pembekuan akun belum ditetapkan sebagai fitur wajib; tidak ada hak implisit Admin membatalkan kontrak.

```mermaid
stateDiagram-v2
    state "Menunggu Kesepakatan" as Menunggu
    [*] --> Menunggu: Pengajuan berhasil dan volume dicadangkan
    Menunggu --> Menunggu: Tawaran harga baru
    Menunggu --> Disetujui: Lawan menerima harga aktif
    Menunggu --> Ditolak: Petani menolak dengan alasan
    Menunggu --> Dibatalkan: Pembeli batal atau petani menarik tawaran, alasan tercatat
    Menunggu --> Kedaluwarsa: Tenggat tercapai
    Disetujui --> Disetujui: Konfirmasi selesai pertama
    Disetujui --> Selesai: Konfirmasi pihak kedua
    Disetujui --> Dibatalkan: Salah satu membatalkan dengan alasan
    Ditolak --> [*]
    Dibatalkan --> [*]
    Kedaluwarsa --> [*]
    Selesai --> [*]
```

### 3.4 Status tawaran dan volume

Status publikasi dipisah dari ringkasan volume. Draf→Terbit saat petani mengirim. Terbit→Ditarik oleh pemilik mengikuti DEC-013b: hentikan pesanan baru, batalkan pesanan Menunggu yang belum kedaluwarsa dan lepaskan reservasinya, tetapi pertahankan kontrak Disetujui serta terminal. Tawaran Ditarik tidak dapat dipesan walaupun volume tersedia secara pembukuan bertambah; tidak otomatis diterbitkan ulang dan tidak boleh diterbitkan kembali (DEC-013e). Sisa panen memerlukan tawaran baru; riwayat/kontrak asal tetap. Moderasi Admin mengikuti DEC-013c/f/g dan FR-021: penandaan/permintaan tindak lanjut, ringkasan untuk pembeli, serta penutupan temuan setelah peninjauan, tanpa menyembunyikan atau membatalkan transaksi. **Terbit tidak berarti seluruh volume tersedia**. Tawaran dapat dipesan hanya jika terbit dan tersedia>0. Bedakan jumlah dicadangkan, Disetujui dan Selesai; jangan menamai seluruh tawaran Selesai hanya karena satu kontrak selesai. Semua volume Selesai tidak kembali tersedia kecuali ada keputusan perubahan lingkup yang baru. Label turunan volume bukan status kontrak baru.

## 4. Kebutuhan fungsional dan kriteria penerimaan

Format setiap kebutuhan: aktor/pemicu, prasyarat, perilaku/hasil, alternatif/gagal, sumber/prioritas dan AC. Setiap `AC-*` adalah skenario verifikasi yang harus dijalankan saat implementasi tersedia, **bukan hasil tes saat penulisan dokumen**.

### FR-001 — Akun petani/pembeli dan OTP
- **Aktor/pemicu/prasyarat:** pengguna memilih masuk/daftar dan memiliki nomor HP; provider menunggu OPN-001.
- **Wajib/hasil:** verifikasi OTP sebelum sesi; akun baru memilih satu peran dan profil minimal nama, wilayah, kelompok/usaha bila relevan serta menyelesaikan persetujuan FR-002 sebelum akun dibuat; akun kembali diarahkan sesuai perannya; dapat keluar.
- **Gagal:** kode salah/kedaluwarsa atau layanan gagal tidak membuat sesi; batas kirim/percobaan harus ditetapkan pada OPN-001, dengan pesan dan coba lagi tanpa memberi peran Admin.
- **Sumber/prioritas:** DEC-003c/010a, proposal §4.2; D. **AC-001:** OTP valid memberi sesi peran benar; OTP tidak valid tidak memberi sesi; perubahan peran melalui parameter permintaan ditolak; keluar mengakhiri sesi. DEC-020a: pengguna/Admin tidak memiliki aksi koreksi peran. Tambahan DEC-014g: verifikasi OTP saja tidak menyelesaikan pendaftaran atau memberi akses akun biasa sebelum persetujuan eksplisit tercatat.

### FR-002 — Informasi pemrosesan data dan bantuan
- **Aktor/pemicu/prasyarat:** publik membuka bantuan/privasi/syarat atau akun baru meninjau pemberitahuan.
- **Wajib/hasil:** jelaskan simulasi, data yang diperlukan, mutu deklaratif, estimasi bukan jaminan, akses kontak dan cara menghubungi pengelola. Sesuai DEC-014g, sebelum akun baru dibuat pengguna dapat membaca ketentuan/pemberitahuan pemrosesan data dan harus memberi persetujuan eksplisit melalui kontrol yang tidak dicentang otomatis; simpan versi dokumen serta waktu persetujuan. OTP tidak menggantikan persetujuan. Isi kebijakan serta bukti penerapan penghapusan/anonimisasi masih mengikuti OPN-004.
- **Gagal:** jangan menyebut kebijakan belum dipilih sebagai kepatuhan hukum terbukti; informasi tetap dapat dibaca tanpa login.
- **Sumber/prioritas:** proposal A.12, DEC-004/010b/f; D. **AC-002:** bantuan menjelaskan batas simulasi/estimasi/mutu; halaman privasi menampilkan versi/status dan tidak bertentangan dengan BR-018 atau mengklaim retensi yang belum dipilih. Tambahan DEC-014g: kontrol persetujuan awal tidak tercentang, dokumen dapat dibaca sebelum memilih; tanpa persetujuan akun baru tidak dibuat. Persetujuan menyimpan versi yang ditampilkan dan waktu; publikasi versi baru tidak menimpa catatan lama.

### FR-003 — Beranda petani
- **Aktor/pemicu/prasyarat:** petani login.
- **Wajib/hasil:** harga wajar GKP/GKG wilayah terpilih, umur/sumber/ketersediaan, akses prakiraan 2/4 pekan, ringkasan volume/pesanan/kontrak dan aksi jual panen; jangan menyembunyikan fitur final sebagai opsional Should.
- **Gagal:** data AI belum ada ditandai; ringkasan transaksi milik sendiri tetap tersedia; gagal jaringan dapat dicoba ulang.
- **Sumber/prioritas:** DEC-002/007a/008a/b, proposal §4.2; D. **AC-003:** akun petani hanya melihat ringkasan sendiri, dapat menuju tawaran/kontrak/harga/prakiraan; data kosong tidak berubah menjadi angka 0.

### FR-004 — Membuat dan mengelola tawaran panen
- **Aktor/pemicu/prasyarat:** petani membuka form/draf milik sendiri.
- **Wajib/hasil:** jenis GKP/GKG, volume kg, harga Rp/kg, lokasi kecamatan, mutu terukur/Belum diukur; simpan draf, tinjau dan terbitkan. Tanggal gabah siap tersedia opsional dengan pilihan “Belum ditentukan” (DEC-013h); ketiadaan tanggal tidak menghalangi terbit dan tanggal ini tidak otomatis membuat tawaran kedaluwarsa. Harga merah memerlukan konfirmasi; tanpa acuan tetap dapat terbit. Harga awal pesanan tidak mengganti harga tawaran panen.
- **Perubahan tawaran aktif (DEC-013a/d):** petani boleh mengubah harga dan volume total untuk pesanan berikutnya; harga/volume kontrak yang sudah ada tetap. Volume total baru harus ≥ jumlah volume dicadangkan + Disetujui + Selesai. Setelah pernah menerima pesanan yang berhasil dibuat, jenis gabah dan lokasi terkunci permanen untuk tawaran tersebut, termasuk ketika semua pesanan sudah terminal. Perubahan jenis/lokasi dibuat sebagai tawaran baru tanpa memindahkan pesanan lama. Validasi perubahan dan pengajuan pesanan bersamaan tidak boleh melanggar batas volume atau penguncian ini.
- **Penarikan (DEC-013b/e):** pemilik dapat menarik tawaran; pesanan Menunggu yang belum kedaluwarsa dibatalkan dengan notifikasi dan pelepasan reservasi, kontrak Disetujui tetap. Status Ditarik tidak dapat diterbitkan kembali. Sisa panen ditawarkan melalui tawaran baru dengan identitas baru tanpa memindahkan riwayat/kontrak lama. Penarikan ulang tidak mengulang efek.
- **Gagal:** volume/harga tidak valid, volume total baru di bawah batas terikat, perubahan jenis/lokasi setelah pernah menerima pesanan, atau penerbitan ulang tawaran Ditarik ditolak tanpa menghapus isian. Tanggal opsional yang diisi harus dapat dibaca sebagai tanggal, tanpa menjadikannya tenggat kontrak. Akun yang menunggu penutupan tidak boleh membuat/menerbitkan tawaran baru (DEC-014e); transaksi lama tidak dibatalkan oleh pembatasan ini. Tindakan pengelolaan akun lain masih mengikuti OPN-003/010.
- **Sumber/prioritas:** DEC-005a/007a/c/d/e/010f, DEC-013a–h/014e/018b; D.

**AC-004:**

1. GKP/GKG dapat diterbitkan dengan mutu Belum diukur, tanggal Belum ditentukan dan acuan harga tidak tersedia; tanggal tidak mengekspirasi tawaran.
2. Harga per kg rupiah bulat dan volume maksimal dua desimal: harga Rp7.000 dan125,50kg valid; harga Rp7.000,50 atau125,505kg ditolak tanpa pembulatan otomatis. Harga/volume tidak positif ditolak.
3. Hanya pemilik dapat mengubah; simpan/terbit ulang permintaan yang sama tidak menggandakan tawaran.
4. Perubahan harga/volume total hanya memengaruhi pesanan berikutnya. Kontrak lama tetap; total kurang dari dicadangkan+Disetujui+Selesai ditolak, termasuk pada pengajuan pesanan bersamaan.
5. Jenis/lokasi terkunci setelah pernah menerima pesanan, termasuk setelah pesanan terminal; tawaran baru tidak memindahkan riwayat lama.
6. Tawaran Ditarik tidak dapat diterbitkan kembali, termasuk setelah semua kontrak terminal; tawaran baru tidak mengaktifkan pesanan batal atau memindahkan kontrak Disetujui.
7. Akun dengan penutupan tertunda tidak dapat membuat/menerbitkan tawaran baru; transaksi lama tidak dibatalkan oleh pembatasan ini.

### FR-005 — Menghitung rentang harga wajar
- **Aktor/pemicu/prasyarat:** pengguna memilih jenis/wilayah/periode atau sistem menghitung acuan; input dan parameter tervalidasi tersedia.
- **Wajib/hasil:** jalankan BR-009, simpan L/U asal dan L/U operasional yang sudah dibulatkan sesuai DEC-018a, beri jenis, wilayah, periode sumber, waktu hitung, rendemen, P10/P90, versi dan status ketersediaan. Tidak mengoreksi harga berdasarkan mutu deklaratif.
- **Gagal:** parameter salah/rasio tidak valid/sampel tidak cukup menghasilkan tidak tersedia; ambang kecukupan pada OPN-002. Jangan meminjam parameter GKP untuk GKG diam-diam.
- **Sumber/prioritas:** DEC-007a–f, proposal A.7; W. **AC-005:** fixture Pberas=10.000,R=0,5,P10=0,9,P90=1 menghasilkan L 4.500/U 5.000; parameter jenis lain tidak tertukar; dataset kosong tidak menghasilkan rentang. Tambahan DEC-018a: batas asal 6.652,49→6.652 dan 6.938,50→6.939; hasil asal tetap tersimpan. Nilai L/U yang ditampilkan sama dengan batas untuk klasifikasi.

### FR-006 — Katalog dan penyaringan pasokan
- **Aktor/pemicu/prasyarat:** pembeli login atau Admin pemantau membuka katalog; petani tidak memiliki akses katalog/detail tawaran petani lain (DEC-015a).
- **Wajib/hasil:** filter minimal jenis/wilayah dan volume tersedia; tampilkan harga minta, mutu, lokasi terbatas, volume tersedia vs total dan acuan/lampu; hanya pembeli dapat memesan. Sesuai DEC-013f, pembeli melihat penanda “Sedang diminta perbaikan” dan ringkasan masalah tanpa data pribadi jika ada temuan Admin yang belum ditutup; penanda tidak memblokir pesanan.
- **Gagal:** tanpa login/tidak berhak tidak memperoleh data lewat halaman maupun respons; hasil kosong menawarkan ubah filter; tersedia 0 menonaktifkan pesan.
- **Sumber/prioritas:** DEC-003b/005a/007a/009c/010f; D. **AC-006:** publik dan akun petani tidak membaca katalog/detail/CSV pasokan petani lain; pembeli dapat filter GKG dan wilayah; stok 0 tidak dapat dipesan; tak ada nomor HP di respons katalog. Tambahan DEC-013f: pembeli login melihat penanda/ringkasan masalah di katalog dan detail tanpa data pribadi; penanda tidak mengubah lampu atau memblokir pesanan yang sah.

### FR-007 — Pengajuan pesanan parsial dan kontrak otomatis
- **Aktor/pemicu/prasyarat:** pembeli memilih tawaran terbit dan mengisi volume/harga.
- **Wajib/hasil:** BR-004 membuat satu kontrak simulasi Menunggu dengan harga awal disetujui pembeli, reservasi dan tenggat tersimpan; beri identitas yang sama untuk akses kedua pihak.
- **Gagal:** volume melebihi tersedia, data berubah, harga tak valid atau konfirmasi merah belum ada tidak mencadangkan; respons hilang/ulang tidak menggandakan. Akun pembeli atau pemilik tawaran yang menunggu penutupan tidak dapat menjadi pemohon/penerima pesanan baru, walaupun volume tersedia (DEC-014e).
- **Sumber/prioritas:** DEC-005a–e/g/004, DEC-014e/018b; W (kontrak), D (parsial).

**AC-007:**

1. Dari1.000kg tersedia, pesanan400kg menyisakan600kg; dua permintaan bersamaan masing-masing700kg tidak keduanya berhasil.
2. Pengulangan satu pengajuan hanya membuat satu kontrak/reservasi.
3. Dari125,50kg, pesan25,25kg menyisakan100,25kg; pembatalan mengembalikan125,50kg tepat satu kali. Presisi berlebih ditolak sebelum reservasi.
4. Pembeli atau pemilik tawaran yang menunggu penutupan akun tidak dapat menjadi pemohon/penerima pesanan baru. Aksi bersamaan dengan permintaan penutupan menjaga kondisi ini tanpa mengubah transaksi lama.

### FR-008 — Pemeriksaan harga dan riwayatnya
- **Aktor/pemicu/prasyarat:** penerbitan, pengajuan harga atau penerimaan harga.
- **Wajib/hasil:** BR-011/012; simpan harga, L/U, δ/versi, hasil, alasan, waktu dan konfirmasi yang relevan; sertakan L/U asal serta operasional hasil pembulatan DEC-018a. Kontrak Disetujui menyimpan hasil kesepakatan.
- **Gagal:** acuan kosong berbeda dari tiga warna; data/harga yang berubah memerlukan pemeriksaan untuk aksi baru, bukan memakai konfirmasi harga lama.
- **Sumber/prioritas:** DEC-006a–d/007e/018a; W.

**AC-008:**

1. Untuk L=Rp7.000,U=Rp7.500 danδ=3%: Rp6.789merah, Rp6.790kuning, Rp7.000hijau, Rp7.500hijau, Rp7.501kuning.
2. Merah tanpa konfirmasi eksplisit tidak melanjutkan aksi; setelah konfirmasi dapat lanjut. Acuan tidak tersedia tidak mendapat lampu.
3. Perubahanδ berlaku pada pemeriksaan berikutnya tanpa menulis ulang hasil kontrak Disetujui.
4. Batas asal Rp6.652,49 menjadi Loperasional Rp6.652; harga Rp6.652 dinilai terhadap nilai yang sama dengan tampilan. Pecahan0,5 dibulatkan ke atas; hasil asal dan operasional tersimpan untuk penelusuran.

### FR-009 — Negosiasi harga
- **Aktor/pemicu/prasyarat:** pihak kontrak Menunggu mengajukan harga baru sebelum tenggat.
- **Wajib/hasil:** simpan versi tawaran harga, pengaju, waktu dan pemeriksaan; jadikan satu harga terakhir aktif. Tidak ada batas dua putaran; tenggat dan volume tetap.
- **Gagal:** versi lama/sudah terminal/kedaluwarsa ditolak tanpa menimpa harga aktif; pembaruan bersamaan diselesaikan dengan satu urutan yang dapat diaudit.
- **Sumber/prioritas:** DEC-005e/f/g; D. **AC-009:** tiga tawaran balik valid dapat tercatat; harga tawaran panen tetap; tenggat tidak berubah; penerimaan versi sebelumnya ditolak setelah versi baru aktif. Tambahan DEC-018b: harga tawaran balik pecahan rupiah ditolak tanpa mengubah harga aktif, tenggat atau volume.

### FR-010 — Menerima harga terakhir
- **Aktor/pemicu/prasyarat:** lawan pengaju harga aktif memilih terima pada Menunggu, sebelum tenggat.
- **Wajib/hasil:** periksa versi aktif dan lampu, terapkan konfirmasi merah bila perlu; kontrak langsung Disetujui tanpa pengaju menekan setuju ulang; volume tetap terikat.
- **Gagal:** pengaju menerima harga sendiri, pihak luar, harga usang atau tepat/sesudah tenggat tidak berhasil. Hasil berlomba dengan batal/kedaluwarsa harus satu.
- **Sumber/prioritas:** DEC-005g/006a/d; W. **AC-010:** pembeli ajukan harga→petani terima→Disetujui; petani tawar balik→pembeli terima→Disetujui; waktu=tenggat gagal terima dan volume dilepas sekali.

### FR-011 — Papan harga dan bagian petani
- **Aktor/pemicu/prasyarat:** publik memilih komoditas/wilayah/periode.
- **Wajib/hasil:** harga petani pengamatan, produsen/penggilingan dan eceran; pedagang besar bila tersedia sebagai sumber pembanding, bukan data rekaan. Pisahkan GKP/GKG, ekuivalen beras, observasi dan estimasi; BR-016 untuk bagian petani.
- **Gagal:** data beda periode/mutu atau hilang ditandai; jangan menggabungkan bulanan dengan mingguan tanpa penjelasan kesetaraan dan jangan menghitung persen pembanding tak valid.
- **Sumber/prioritas:** DEC-009a, proposal §4.2/A.8; W. **AC-011:** harga gabah 5.000,R 0,5,eceran 12.500 memberi ekuivalen 10.000 dan bagian 80% bila setara; eceran kosong/0 atau periode tak setara tidak menghasilkan persen; simulasi tidak masuk seri observasi.

### FR-012 — Peta provinsi dan alternatif tabel
- **Aktor/pemicu/prasyarat:** publik memilih komoditas/tingkat pasar/periode.
- **Wajib/hasil:** harga, selisih median bertanda, sumber/umur/cakupan provinsi; ringkasan minimum/maksimum/disparitas terpisah; peta memiliki tabel setara. GeoJSON/wilayah data harus dipetakan eksplisit.
- **Gagal:** tanpa data ditandai bukan 0; pembanding tidak valid tidak dihitung; legenda memakai skala kontinu dengan pusat 0%, membedakan arah murah/mahal dan menampilkan nilai; tanpa data memiliki penanda netral tersendiri (DEC-019a), bukan kategori A–D lama.
- **Sumber/prioritas:** DEC-009b/c, proposal A.9; T. **AC-012:** harga 100/120/140 memberi median 120, selisih−16,67%/0/+16,67% dan disparitas 40% (ilustrasi dua desimal); tabel memuat nilai/cakupan yang sama; provinsi kosong dibedakan. Tambahan DEC-019a: provinsi tepat median bernilai 0% tidak disamakan dengan tanpa data; legenda berpusat 0% dengan arah/jangkauan jelas, tidak memakai batas kategori tetap; tabel mempertahankan angka/filter yang sama.

### FR-013 — Dasbor pembeli
- **Aktor/pemicu/prasyarat:** pembeli login.
- **Wajib/hasil:** ringkasan pasokan katalog (volume deklaratif, bukan stok terverifikasi), rentang GKP/GKG dan prakiraan, pesanan/kontrak sendiri, akses cari pasokan serta notifikasi.
- **Gagal:** acuan/model tak tersedia tidak menghilangkan ringkasan kontrak; tidak menampilkan kontrak milik pembeli lain.
- **Sumber/prioritas:** DEC-002/007a/008a/b, proposal A.9; T. **AC-013:** akun pembeli melihat volume tersedia dan ringkasan sendiri; dapat menuju katalog/kontrak/prakiraan/CSV; angka pasokan berlabel deklaratif.

### FR-014 — Penjelasan komponen harga wajar
- **Aktor/pemicu/prasyarat:** pengguna membuka detail acuan.
- **Wajib/hasil:** harga beras produsen, rendemen jenis gabah, rasio/kuantil, wilayah/periode, versi sumber; label estimasi bukan jaminan dan mutu belum diperhitungkan. Jelaskan istilah dengan bahasa awam.
- **Gagal:** tanpa acuan jelaskan komponen yang belum tersedia tanpa membuat nilai contoh sebagai hasil nyata.
- **Sumber/prioritas:** DEC-007b/c/f; W. **AC-014:** GKG menunjukkan parameter GKG dan asalnya; penjelasan rumus tidak dilabeli SHAP; informasi penting dapat dibaca tanpa hover.

### FR-015 — Prakiraan dan estimasi turunan
- **Aktor/pemicu/prasyarat:** publik/pengguna memilih provinsi dan horizon 2/4 pekan; keluaran model/baseline lolos publikasi.
- **Wajib/hasil:** BR-013/015, identitas metode, waktu terbit/target, harga beras dan interval yang dievaluasi; GKP/GKG turunan berlabel jelas beserta parameter konversi. Tampilkan status pencapaian evaluasi sesuai bukti.
- **Gagal:** model gagal target pada unit provinsi/horizon→baseline terevaluasi berlabel untuk unit tersebut; parameter turunan/interval belum valid→nyatakan keluaran terkait tidak tersedia, jangan menyalin klaim cakupan.
- **Sumber/prioritas:** DEC-008a/b/d, proposal §4.1/A.7; T. **AC-015:** hanya horizon 2/4 diwajibkan; model gagal target mengaktifkan baseline sesuai bukti; beras, gabah turunan dan observasi tidak tertukar; versi/interval invalid tidak dipublikasikan sebagai hasil valid. Tambahan DEC-017a: provinsi A horizon 2 lulus/horizon 4 gagal menampilkan model/baseline sesuai unit; provinsi B tanpa baseline valid ditandai belum tersedia. Setiap kartu/grafik/hasil turunan mencantumkan metode yang benar, tanpa memakai skor agregat untuk meloloskan unit gagal.

### FR-016 — Penjelasan SHAP prakiraan
- **Aktor/pemicu/prasyarat:** pengguna membuka faktor prakiraan dengan penjelasan model/versi yang sesuai.
- **Wajib/hasil:** kontribusi faktor positif/negatif disajikan dalam bahasa awam, target/horizon/model dapat ditelusuri; bukan sebab pasti. Untuk gabah turunan, jelaskan faktor berasal dari model beras dan konversinya terpisah.
- **Gagal:** penjelasan model lain atau model lama tidak ditempel pada baseline/keluaran baru; tandai belum tersedia bila tidak cocok.
- **Sumber/prioritas:** DEC-008c/d; W. **AC-016:** penjelasan versi A tidak muncul seolah menjelaskan baseline B; faktor/arah bersumber keluaran tersimpan, tanpa SHAP fiktif; tidak memakai kata penyebab pasti.

### FR-017 — Notifikasi transaksi
- **Aktor/pemicu/prasyarat:** peristiwa kontrak berhasil dicatat.
- **Wajib/hasil:** pusat notifikasi pihak relevan untuk pesanan/harga balik/persetujuan/pembatalan/penolakan/kedaluwarsa/konfirmasi selesai; status dibaca dan tautan ke kontrak sendiri; alasan pengakhiran disertakan sesuai keputusan.
- **Gagal:** kegagalan penyajian notifikasi tidak menggandakan kontrak atau melepas volume dua kali; pengguna lain tidak membaca notifikasi. Kanal transaksi bukan SMS/WA.
- **Sumber/prioritas:** DEC-010c/005i/j, proposal A.9; T. **AC-017:** kejadian tolak mengirim alasan ke pembeli terkait, pembatalan mengirim ke pihak lawan; kedua peran menerima jenis relevan, akun luar ditolak.

### FR-018 — Ekspor CSV
- **Aktor/pemicu/prasyarat:** publik meminta ringkasan harga publik atau pengguna berhak meminta pasokan.
- **Wajib/hasil:** CSV harga publik mengikuti filter/satuan/periode/sumber dan label observasi/konversi/estimasi, tanpa data pribadi. CSV pasokan (DEC-015b) hanya agregasi per jenis gabah dan wilayah: jumlah tawaran unik, total volume tersedia, harga minta minimum/maksimum; nyatakan satuan dan waktu snapshot/ekspor. Tidak ada baris/identitas tiap tawaran, nama/kontak/ID akun, mutu atau tanggal individual. Himpunan sumber tetap mengikuti hak akses dan filter yang sama; rentang harga minta bukan estimasi harga wajar atau harga observasi.
- **Gagal:** ekspor pasokan tanpa login/izin ditolak; baris tidak boleh lebih luas dari akses halaman; field berbahaya tidak menjadi formula aktif saat dibuka (NFR-003).
- **Sumber/prioritas:** DEC-010d/003b; D. **AC-018:** CSV harga dapat diunduh publik, CSV pasokan tanpa login gagal; tak ada nama pribadi/kontak/alamat; isi teks diawali karakter formula ditangani aman, data difilter konsisten. Tambahan DEC-015a: akun petani tidak dapat memakai ekspor untuk membaca pasokan petani lain; CSV harga publik tetap diizinkan. Tambahan DEC-015b: dua tawaran satu kelompok dihitung dua walau memiliki beberapa kontrak; jumlahkan volume tersedia, bukan total awal. CSV berisi minimum/maksimum harga minta kelompok dan tidak memuat ID/baris tawaran atau data pribadi; kelompok/filter/waktu snapshot konsisten dan data yang tidak berhak diakses tidak ikut dihitung.

### FR-019 — Konfigurasi parameter
- **Aktor/pemicu/prasyarat:** Admin mengubah parameter yang diizinkan.
- **Wajib/hasil:** durasi awal 24 jam danδ awal 3% dapat diubah dengan jejak versi; durasi untuk pengajuan baru saja, δ untuk pemeriksaan berikutnya. Rendemen/parameter estimator serta HPP memiliki sumber/jenis/periode berlaku bila dipublikasikan.
- **Gagal:** parameter tidak valid atau tanpa bukti yang diwajibkan tidak dipublikasikan; tidak boleh menulis ulang tenggat/hasil historis; hak parameter bukan hak mengubah harga kontrak.
- **Sumber/prioritas:** DEC-005c/d/006c/d/003a; D. **AC-019:** durasi 24→48: pesanan lama tetap 24, baru 48; δ berubah: penerimaan berikutnya memakai baru, kontrak Disetujui tetap snapshot; perubahan tercatat.

### FR-020 — Impor dan validasi data harga
- **Aktor/pemicu/prasyarat:** Admin/sistem mengimpor sumber yang penggunaannya telah diperiksa.
- **Wajib/hasil:** provenance, skema komoditas/pasar/wilayah/periode/satuan, kualitas, deduplikasi dan versi snapshot; pisahkan arsip ditolak dari dataset publik/latih.
- **Gagal:** harga nonpositif, wilayah tak terpetakan, satuan tak jelas atau duplikat konflik tidak diam-diam menjadi harga valid; kegagalan impor tidak menghapus snapshot valid sebelumnya.
- **Sumber/prioritas:** DEC-002/009a/b; proposal A.7/A.12; W. **AC-020:** fixture valid dapat dipakai,0/duplikat konflik/wilayah tak dikenal ditandai; sumber dan waktu terbit dapat ditelusuri; data simulasi tidak masuk observasi.

### FR-021 — Moderasi dan pengelolaan operasional pengguna
- **Aktor/pemicu/prasyarat:** Admin meninjau tawaran/pengguna bermasalah.
- **Wajib/hasil:** sesuai DEC-013c/f/g, Admin menandai masalah dan meminta petani memperbaiki atau menarik tawaran; catat masalah, permintaan, pelaku/waktu dan notifikasi aplikasi kepada petani. Pembeli melihat penanda “Sedang diminta perbaikan” dan ringkasan masalah tanpa data pribadi, terpisah dari catatan internal. Petani dapat menyatakan “Sudah diperbaiki”; temuan beralih Terbuka→Menunggu Peninjauan, tetap berpenanda sampai Admin meninjau dan menutupnya. Riwayat tetap tersimpan; temuan lain yang belum ditutup tetap ditampilkan. Tawaran tetap terlihat dan mengikuti ketersediaan volume. Moderasi tidak menyembunyikan tawaran, menghentikan pesanan baru, mengubah volume atau membatalkan kontrak. Tidak ada aksi atas nama pihak atau impersonasi; penutupan temuan bukan verifikasi mutu fisik.
- **Gagal:** jangan menjalankan aksi pembekuan/reset atau koreksi peran yang belum menjadi kebutuhan MVP. Moderasi dan penutupan akun mengikuti keputusan yang sudah dipilih; keduanya tidak memberi Admin hak mengeksekusi kontrak atau membatalkannya secara terselubung.
- **Sumber/prioritas:** DEC-003a/013c/f/g/020a; D.

**AC-021:**

1. Admin tidak dapat menawar, menyetujui, membatalkan atau menyelesaikan kontrak lewat UI maupun respons/API; tidak ada fitur koreksi peran.
2. Penandaan dan permintaan tindak lanjut tercatat serta diberitahukan kepada petani; tidak menyembunyikan tawaran, memblokir pesanan baru yang sah, atau mengubah kontrak/volume.
3. Pembeli login melihat penanda/ringkasan tanpa catatan internal atau data pribadi. Penanda bukan lampu harga atau klaim verifikasi mutu fisik.
4. Setelah petani menyatakan Sudah diperbaiki, penanda tetap. Petani tidak dapat menutup temuan sendiri; Admin meninjau/menutup dan riwayat tetap.
5. Jika dua temuan terbuka dan satu ditutup, temuan lain tetap berpenanda. Jika petani menarik tawaran, efek penarikan mengikuti AC-024; semua aksi yang diperbolehkan tercatat.

### FR-022 — Audit peristiwa
- **Aktor/pemicu/prasyarat:** aksi kontrak, pemeriksaan, parameter, impor/publikasi atau moderasi berhasil/gagal relevan.
- **Wajib/hasil:** identitas objek/pelaku/peran, waktu, aksi/hasil, versi terkait, perubahan status dan alasan; dapat dibaca Admin sesuai izin tanpa membuka kredensial/OTP.
- **Gagal:** pembaruan status bisnis tidak dianggap berhasil tanpa jejak yang konsisten; replay tidak membuat efek bisnis ganda; penghapusan/anonimisasi saat penutupan mengikuti DEC-014f; masa simpan nonpribadi dan teknis cadangan OPN-004.
- **Sumber/prioritas:** DEC-003a/005b/g/i/j/006d; D. **AC-022:** rantai Menunggu→Disetujui→Selesai dan batal punya pelaku/waktu/versi; log tidak memuat OTP/sandi; FRini tidak disebut kebutuhan retraining.

### FR-023 — Kedaluwarsa dan pelepasan reservasi
- **Aktor/pemicu/prasyarat:** sistem memeriksa pesanan Menunggu, termasuk saat aksi penerimaan/pengajuan berikutnya.
- **Wajib/hasil:** BR-005; pada tenggat tandai Kedaluwarsa, lepaskan reservasi sekali dan beri notifikasi relevan. Periksa tenggat sebelum semua mutasi Menunggu, termasuk tolak/batal, walaupun job kedaluwarsa belum berjalan. Jangan bergantung hanya pada tampilan penghitung waktu browser.
- **Gagal:** job terlambat tidak mengizinkan terima melewati tenggat; kontrak Disetujui tidak diekspirasi dengan tenggat negosiasi.
- **Sumber/prioritas:** DEC-005b/c/d/f; D. **AC-023:** pada waktu=tenggat aksi terima gagal dan tersedia pulih; tolak/batal pada atau setelah tenggat, dengan job belum berjalan, menghasilkan Kedaluwarsa dan bukan Ditolak/Dibatalkan; job ulang tidak menambah volume; Disetujui melewati tenggat tetap tidak kedaluwarsa otomatis.

### FR-024 — Penolakan dan pembatalan
- **Aktor/pemicu/prasyarat:** petani/pembeli pada kontrak sendiri sesuai tabel status.
- **Wajib/hasil:** BR-007; alasan wajib, transisi tunggal, volume dilepas, notifikasi serta audit. Saat tawaran ditarik pemilik, sistem mencatat alasan “Tawaran ditarik oleh petani” dan referensi penarikannya pada pembatalan otomatis Menunggu. Satu konfirmasi selesai tidak menutup hak batal yang dipilih pengguna.
- **Gagal:** alasan kosong, pihak luar/Admin atau kontrak Selesai tidak boleh membatalkan; permintaan berulang tidak melepas lagi.
- **Sumber/prioritas:** DEC-005i/j, DEC-013b; D. **AC-024:** petani tolak Menunggu dan pembeli batal Menunggu berhasil beralasan; salah satu batal Disetujui termasuk 1/2 konfirmasi berhasil; selesai/batal bersamaan tidak dua hasil; ulang tidak gandakan volume. Tarik tawaran dengan dua pesanan Menunggu dan satu Disetujui membatalkan hanya dua Menunggu, memberi notifikasi dan melepas reservasi sekali; Disetujui tetap, pesanan baru ditolak. Pada waktu ≥ tenggat, pesanan tersebut Kedaluwarsa, bukan Dibatalkan. Penarikan bersamaan penerimaan/pengajuan tidak menyisakan reservasi tanpa status yang sesuai.

### FR-025 — Konfirmasi penyelesaian dua pihak
- **Aktor/pemicu/prasyarat:** petani/pembeli kontrak Disetujui memilih konfirmasi selesai.
- **Wajib/hasil:** tandai per pihak, tampilkan pihak yang ditunggu; kedua pihak→Selesai tanpa mengembalikan volume ke tersedia.
- **Gagal:** konfirmasi ganda pihak sama tetap 1/2, pihak luar ditolak; sudah batal tidak dapat selesai.
- **Sumber/prioritas:** DEC-005h; W (siklus selesai). **AC-025:** pertama tetap Disetujui, pengulangan tetap 1/2, kedua jadi Selesai, volume tidak kembali; urutan pihak boleh dibalik.

### FR-026 — Detail kontrak dan bukti simulasi
- **Aktor/pemicu/prasyarat:** pihak kontrak atau Admin pemantau membuka identitas kontrak.
- **Wajib/hasil:** jenis/volume/harga/status, tenggat jika Menunggu, riwayat harga/pemeriksaan, konfirmasi per pihak, label SIMULASI dan ringkasan kesepakatan yang dapat dicetak. Aksi hanya sesuai peran/status; bukan tanda tangan tersertifikasi.
- **Gagal:** detail/cetak tidak membocorkan kontrak/kontak ke pihak lain; bukti tidak menyebut pembayaran/pengiriman terverifikasi; Admin tidak memperoleh aksi pihak kontrak atau nomor lengkap melalui halaman/bukti pemantauan (DEC-014c).
- **Sumber/prioritas:** DEC-004/005g/h/010b; proposal §3/§4.2; W. **AC-026:** cetak memuat label Simulasi, data kontrak cocok; URL pihak lain ditolak; status Selesai tidak terbaca sebagai bukti pembayaran nyata.

### FR-027 — Profil dan visibilitas kontak
- **Aktor/pemicu/prasyarat:** pengguna membuka profil sendiri atau kontak pada kontrak Disetujui yang melibatkannya.
- **Wajib/hasil:** tampilkan nama/peran/wilayah dan pengaturan sendiri; kontak lawan hanya sesuai BR-018. Setelah kontrak Dibatalkan atau Selesai, nomor pihak lawan disembunyikan kembali pada kontrak tersebut, termasuk respons data dan bukti yang dihasilkan setelah pembatalan; riwayat tetap tersimpan (DEC-014a/b). Permintaan penutupan akses dicatat; jika ada Menunggu Kesepakatan atau Disetujui, proses menunggu semua transaksi aktif berakhir. Pengguna tetap dapat menyelesaikan/mengakhiri transaksi sesuai peran/status; permintaan tidak otomatis membatalkan kontrak atau melepas volume (DEC-014d). Selama tertunda, akun tidak dapat membuat tawaran/pesanan baru dan tawarannya tidak menerima pesanan baru; transaksi lama tetap dapat ditindaklanjuti sesuai status tanpa otomatis Ditarik/batal (DEC-014e). Setelah penutupan diproses, hapus kontak/profil pribadi dan anonimkan identitas pada riwayat; pertahankan hanya data transaksi nonpribadi (DEC-014f). Koreksi/pergantian peran di luar MVP (DEC-020a). Perubahan nomor/identitas yang belum ditetapkan tidak menjadi aksi wajib MVP; validasi penghapusan/anonimisasi serta masa simpan nonpribadi mengikuti OPN-004/010.
- **Gagal:** login saja tidak membuka nomor orang lain; CSV, katalog dan notifikasi yang tidak relevan tidak menyisipkan kontak tersembunyi.
- **Sumber/prioritas:** DEC-003c/010b/f/014a–g/020a; D.

**AC-027:**

1. Kontak pihak lawan hanya dapat diakses kedua pihak ketika kontrak saat itu Disetujui; sebelum kesepakatan dan setelah Dibatalkan/Selesai tidak ada nomor lengkap pada detail, respons atau bukti baru. Riwayat tetap ada.
2. Satu konfirmasi selesai masih Disetujui; konfirmasi kedua menjadi Selesai dan menutup kontak. Kontrak lain dinilai terpisah menurut izin/statusnya.
3. Admin hanya menerima nomor tersamar di panel, pencarian, detail, log, ekspor dan bukti; tidak ada tombol atau respons yang membuka lengkap. Identitas akun tetap dapat dipakai menelusuri transaksi.
4. Lokasi tidak melebihi kecamatan. Perubahan nomor/reset yang belum dipilih tidak dianggap aksi wajib; tidak ada koreksi/pergantian peran oleh pengguna/Admin.
5. Permintaan penutupan dengan Menunggu/Disetujui dicatat, akses penyelesaian/pengakhiran lama tetap, tanpa otomatis membatalkan kontrak atau melepas volume. Satu konfirmasi selesai masih aktif.
6. Selama penutupan tertunda, penerbitan tawaran baru/pesanan baru ditolak di server; pembeli lain tidak dapat mengajukan pesanan ke tawaran pemilik itu. Uji bersama permintaan penutupan agar tidak meninggalkan kontrak aktif tanpa akses.
7. Setelah semua transaksi terminal dan penutupan diproses, hapus kontak/profil pribadi serta anonimkan identitas riwayat. Periksa profil, kontrak/bukti baru, notifikasi, log, indeks/cache/ekspor, teks bebas dan relasi; data nonpribadi tetap, bukan hanya nama diganti ID yang masih terhubung.
8. Cadangan/provider dan bukti persetujuan memiliki rencana serta bukti penghapusan/anonimisasi yang selaras, tanpa masa retensi tambahan pribadi terselubung. Jangan mengklaim anonimisasi lulus sebelum diperiksa.

### FR-028 — Autentikasi dan ringkasan Admin
- **Aktor/pemicu/prasyarat:** Admin yang disediakan pengelola masuk halaman terpisah.
- **Wajib/hasil:** email/sandi, sesi Admin, keluar, ringkasan impor/tawaran/kontrak dan tautan operasional; tanpa pendaftaran publik atau pilihan peran Admin di OTP.
- **Gagal:** kredensial salah/tidak berhak tidak memberi sesi/akses; pemulihan kredensial dan batas percobaan pada OPN-001.
- **Sumber/prioritas:** DEC-003a/010e; D. **AC-028:** akun Admin valid dapat memantau, akun biasa tidak memperoleh panel lewat URL langsung; pendaftaran publik tidak membuat Admin; keluar mengakhiri sesi.

### FR-029 — Penjelasan model atas perbedaan wilayah
- **Aktor/pemicu/prasyarat:** pengguna memilih wilayah/komoditas/pasar/periode yang sebanding dan model penjelas yang valid tersedia.
- **Wajib/hasil:** kontribusi model yang menjelaskan perbedaan wilayah, target/model/baseline dan keterbatasan dapat ditelusuri; bukan teks statis yang diklaim SHAP.
- **Gagal:** wilayah tanpa fitur/model/versi cocok→penjelasan belum tersedia, bukan bobot fiktif. Perbandingan dua prediksi harus dilabeli sebagai prediksi, bukan otomatis menjelaskan seluruh selisih harga observasi.
- **Sumber/prioritas:** DEC-008c; proposal §4.2; W. **AC-029:** hasil terhubung model/target wilayah/periode; ubah periode tidak mempertahankan bobot lama; penjelasan tanpa bukti tak diterbitkan sebagai SHAP; tidak mengklaim kausalitas.

### FR-030 — Pilihan mode dan penyajian responsif
- **Aktor/pemicu/prasyarat:** pengguna memilih mode terang/gelap pada shell publik/ruang kerja.
- **Wajib/hasil:** keduanya tersedia dengan makna status, informasi dan aksi sama; shadcn/ui+Tailwind v4 mengikuti identitas yang dipilih, font judul Plus Jakarta/isi Atkinson, angka tabular.
- **Gagal:** mode tidak menghilangkan fokus/teks/status; detail token/kontras/skala pada fase 3, bukan klaim sudah lolos.
- **Sumber/prioritas:** DEC-011a–f; D. **AC-030:** ganti mode pada halaman publik/katalog/kontrak/admin mempertahankan informasi/izin; lampu dapat dipahami tanpa warna; token/font rinci diperiksa pada fase 3.

### FR-031 — Versi model, evaluasi dan gerbang publikasi
- **Aktor/pemicu/prasyarat:** Admin/tim data memasukkan kandidat estimator/model/baseline/penjelasan beserta bukti evaluasi.
- **Wajib/hasil:** sumber/snapshot data, waktu pelatihan, versi/fitur/target/horizon, metrik, status kelayakan dan interval; pisahkan latih/uji temporal, larang simulasi sebagai latih/observasi; publikasikan hasil yang memenuhi aturan atau fallback berlabel per provinsi/horizon sesuai DEC-017a; simpan bukti pemilihan metode tiap unit.
- **Gagal:** tanpa protokol/evaluasi, data bocor masa depan, interval tidak valid atau simulasi terdeteksi→tidak boleh diklaim model layak. Otomasi retraining bukan kewajiban final.
- **Sumber/prioritas:** DEC-004/008d, proposal §4.1/A.7/A.12; D. **AC-031:** fixture simulasi dikecualikan dari latih; kandidat gagal target tetap tercatat namun publik memakai baseline valid; hasil model, horizon dan laporan cocok; fitur masa depan tidak dipakai pada cutoff prakiraan. Tambahan DEC-017a: bukti tiap provinsi/horizon menentukan keluaran model/baseline/tidak tersedia; publikasi satu unit tidak mengubah unit lain, penjelasan dan turunan tetap cocok dengan metode/versi asalnya.

## 5. Kebutuhan nonfungsional

| ID | Kebutuhan/target dan status | Verifikasi yang diperlukan |
|---|---|---|
| NFR-001 | Integritas: tidak ada volume negatif, pesanan ganda akibat replay, atau efek lepas volume dua kali; satu versi harga aktif/keadaan akhir | AC-007/009/010/023/024/025 dengan skenario bersamaan dan ulang |
| NFR-002 | Keamanan/privasi: izin objek/peran pada server, sesi/kredensial terlindungi, komunikasi terlindungi, tidak mencatat OTP/sandi di log; data minimal sesuai keputusan | AC-001/006/022/027/028; protokol, hashing, batas percobaan dan penerapan penghapusan/anonimisasi perlu rancangan teknis OPN-001/004 |
| NFR-003 | Ekspor tidak membocorkan data pribadi; nilai sel teks yang dapat dieksekusi spreadsheet dinetralkan tanpa merusak arti nilai | AC-018; tinjau seluruh kolom dan fixture formula/karakter khusus |
| NFR-004 | Usability terkonfirmasi: minimal 5 responden total mewakili petani/pembeli, target SUS ≥ 68; alur normal ≤ 5 tindakan BR-020 | AC-032 di bawah; hasil aktual belum tersedia |
| NFR-005 | Target AI proposal: MASE ≤ 0,9 per provinsi; dibanding baseline pekan lalu/musiman/SARIMA; pita 80% cakupan 75–85% pada walk-forward | AC-033; denominator MASE, cutoff, split, agregasi lintas wilayah dan aturan kelayakan OPN-007 |
| NFR-006 | Evaluasi lonjakan: recall ≥ 70%, precision ≥ 60%; perubahan 2 pekan di atas P95 historis provinsi sebagai acuan proposal; bukan kewajiban notifikasi otomatis final | AC-034; threshold/kalibrasi dari data latih saja dan laporan kondisi tanpa kejadian |
| NFR-007 | Transparansi: semua angka AI memiliki label metode/jenis/wilayah/periode/sumber/umur; tidak tersedia ≠ nol; observasi/estimasi/turunan terpisah | AC-005/011/012/014/015/016/029/031 |
| NFR-008 | Aksesibilitas terkonfirmasi DEC-016a: teks isi ≥ 16 px, area sentuh ≥ 44×44 px, navigasi keyboard, zoom 200%, kontras teks normal ≥ 4,5:1 dan indikator fokus ≥ 3:1; status bukan warna saja, informasi penting tanpa hover, kedua mode. Skala rinci, komponen grafis/teks besar dan reduced-motion dirinci fase 3 | AC-035; target proyek, bukan hasil uji atau klaim kepatuhan menyeluruh |
| NFR-009 | Kinerja/operasi: permintaan gagal tidak menghilangkan form/menggandakan aksi; snapshot valid terakhir tidak rusak oleh impor gagal. Target terkonfirmasi DEC-016b: halaman utama siap digunakan ≤ 5 detik, berarti konten utama dan tombol tindakan utama dapat digunakan | AC-036; profil perangkat/jaringan/data, cache, pengulangan dan aturan penilaian harus dicatat sebelum klaim lulus; availability/backup/recovery masih OPN-006 |
| NFR-010 | Audit/versi: peristiwa bisnis bisa ditelusuri ke pelaku/waktu/parameter; hasil historis tak ditulis ulang oleh perubahan ambang | AC-019/022/031; masa simpan nonpribadi dan teknis penghapusan/cadangan masih perlu ditetapkan, tanpa retensi tambahan data pribadi terselubung |

**AC-032:** lakukan walkthrough lima tindakan BR-020 dari katalog hingga Selesai dengan dua peran; catat interaksi yang dikecualikan. Uji juga tugas buat tawaran dan baca harga/prakiraan. Catat responden/hasil tugas/SUS; lulus target bila total ≥ 5, kedua peran terwakili, skor agregat SUS ≥ 68 menurut metode perhitungan yang terdokumentasi. Ini skenario uji, belum hasil.

**AC-033:** backtest walk-forward pada kedua horizon dengan cutoff historis dan fitur yang saat itu tersedia; laporkan MASE per provinsi, galat baseline/SARIMA dan cakupan pita 80% per horizon, ukuran sampel, missing data dan kegagalan. Lulus target numerik sesuai NFR-005 dengan aturan agregasi/gerbang OPN-007 yang harus disahkan; fallback tidak mengubah kandidat gagal menjadi lulus. Evaluasi hasil gabah terpisah atau nyatakan keterbatasan bukti.

**AC-034:** bangun label lonjakan dengan ambang dari histori yang tersedia sebelum titik uji; laporkan confusion matrix, recall/precision, cakupan kejadian dan periode. Jika tidak ada kejadian/prediksi positif, metrik yang tak terdefinisi diberi keterangan, bukan otomatis 100%. Bandingkan target tanpa mengklaim fitur alert otomatis sudah dibangun.

**AC-035:** audit alur/komponen di kedua mode: teks isi minimal 16 px, area sentuh minimal 44×44 px, keyboard, zoom 200%, kontras teks normal minimal 4,5:1 dan indikator fokus minimal 3:1 sesuai DEC-016a. Periksa status dengan ikon/teks, fokus dan informasi tanpa hover. Lebar 360/1280 px adalah fixture awal yang akan dikunci dalam protokol uji, bukan bukti hasil. Skala rinci dan pasangan token diperiksa pada fase 3; jangan mengklaim lulus sebelum implementasi diuji.

**AC-036:** putuskan koneksi saat form/pengajuan berjalan lalu pulihkan; isian tetap/ada pemulihan, retry tidak menggandakan pesanan; impor gagal tidak merusak snapshot valid. Untuk PB-01/PT-01/PR-01/AD-01 yang diuji, ukur dari titik awal yang ditetapkan sampai konten utama serta tombol utamanya dapat dipakai, target maksimal 5 detik sesuai DEC-016b. Catat perangkat/browser, jaringan, data, cache, pengulangan serta aturan agregasi pada protokol OPN-006 sebelum menyatakan lulus; kerangka kosong tidak dihitung sebagai siap.

## 6. Data konseptual dan kontrak antarmuka

Tidak menetapkan nama tabel, route API, bahasa backend atau database fisik. Hubungan/data minimum berikut diturunkan dari perilaku; detail skema mengikuti rancangan teknis.

| Objek | Data/relasi minimum |
|---|---|
| Akun dan profil | Identitas tetap, satu peran, nama, nomor HP untuk akun biasa/email Admin, wilayah, status sesi; kebijakan perubahan OPN-010 |
| Wilayah dan komoditas | Kode/hierarki provinsi→kab/kota→kecamatan; pemetaan versi wilayahke sumber data; GKP/GKG/jenis beras dipisah |
| Tawaran panen | Pemilik, jenis gabah, wilayah, volume total, harga minta, status publikasi, nilai mutu/Belum diukur, tanggal ketersediaan opsional/Belum ditentukan; versi |
| Kontrak simulasi/pesanan | Identitas, tawaran/petani/pembeli, volume, status, flag simulasi, waktu pengajuan/tenggat, durasi tersimpan, harga aktif/versi, konfirmasi selesai per pihak |
| Tawaran harga | Kontrak, versi urutan, pengaju, harga, waktu, persetujuan pengaju; penerimaan merujuk versi tertentu |
| Pergerakan volume | Referensi kontrak, jenis reservasi/disetujui/selesai/pelepasan, jumlah dan identitas efek untuk cegah hitung ganda |
| Pemeriksaan harga | Harga, jenis/wilayah, L/U, rentang/versi, δ/versi, hasil/alasan, konfirmasi, waktu; snapshot kesepakatan |
| Observasi harga | Sumber/izin penggunaan, jenis/mutu/pasar, wilayah, periode mulai/akhir, frekuensi, satuan, nilai, waktu terbit/impor, quality flag/snapshot |
| Parameter/rentang | Rendemen per jenis dan sumber, P10/P90/kalibrasi per wilayah, versi/periode berlaku, sampel/kecukupan; HPP per jenis/sumber/periode jika digunakan |
| Prakiraan/estimasi turunan | Issue/cutoff/target periode, wilayah, target komoditas/pasar, horizon 2/4, metode/versi, median/interval, status evaluasi; parameter konversi untuk turunan |
| Penjelasan model | Model/versi/target/horizon/wilayah/periode, baseline penjelasan, fitur/kontribusi, status validasi; model beras terpisah dari konversi gabah |
| Evaluasi/publikasi | Snapshot latih/uji, cutoff/protokol, metrik per horizon/wilayah, candidat/status, alasan fallback, versi yang dipublikasikan |
| Temuan moderasi | Tawaran/pemilik/Admin, masalah, ringkasan untuk pembeli tanpa data pribadi, catatan internal terpisah, Terbuka/Menunggu Peninjauan/Ditutup, pernyataan perbaikan dan waktu/pelaku peninjauan; riwayat tidak mengubah kontrak |
| Persetujuan pendaftaran | Versi ketentuan/pemberitahuan yang ditampilkan, waktu dan tindakan persetujuan eksplisit; keterkaitan akun serta perlakuan setelah penutupan mengikuti penghapusan/anonimisasi DEC-014f/g |
| Permintaan penutupan akun | Referensi akun selama pemrosesan, waktu/status permintaan, pembatasan transaksi baru, pemeriksaan transaksi aktif dan hasil pemrosesan; data pribadi/relasi setelah penutupan mengikuti DEC-014f |
| Notifikasi dan audit | Penerima/objek/jenis/teks alasan/read status; pelaku/waktu/aksi/versi/hasil tanpa kredensial |

Kontrak penyajian lintas halaman:

1. **Data harga:** nilai + satuan + komoditas/jenis + tingkat pasar + wilayah + periode + sumber + label observasi/konversi/estimasi + status ketersediaan. Hanya waktu hitung baru tidak menjadikan sumber lama “terbaru”.
2. **Hasil pemeriksaan:** harga diperiksa, acuan/snapshot, status HIJAU/KUNING/MERAH/TIDAK_TERSEDIA, alasan, selisih Rp/% bila dapat dihitung, perlu konfirmasi dan versi. Ketika L/U tak valid atau L ≤ 0, tidak mengeluarkan warna valid.
3. **Perintah transaksi:** pengguna/objek berhak, volume/harga/versi yang dilihat, identitas permintaan untuk replay, konfirmasi bila perlu. Respons sukses menyertakan identitas/status/versi dan volume tersedia; konflik mengharuskan muat ulang data, bukan sukses semu.
4. **Impor/publikasi:** bukti provenance/versi dan validasi sebelum mengganti data yang disajikan. Kegagalan layanan eksternal tidak membuka data pribadi atau membuat keluaran AI fiktif.

## 7. Keputusan lanjutan dan keterbatasan

| ID | Jenis / yang belum tersedia | Usulan atau tindakan untuk review; bukan persetujuan diam-diam |
|---|---|---|
| OPN-001 | Implementasi OTP/autentikasi Admin | Pilih kanal/provider, batas percobaan/kirim ulang/umur kode, recovery dan biayanya. Jangan mengganti verifikasi nyata dengan kode statis kecuali lingkungan demo terisolasi disepakati terpisah |
| OPN-002 | Bukti data/kalibrasi | Dataset, R_GKG, sumber/R_GKP, kecukupan sampel per wilayah/jenis, periode, outlier, pemetaan mutu dan umur data. Rasio tak terbukti→acuan tak tersedia; ambang peringatan mutu belum boleh diarang |
| OPN-003 | Perilaku edit/tarik/moderasi akun/tawaran aktif | **Aturan tawaran terselesaikan — DEC-013a–h:** edit harga/volume hanya pesanan berikutnya dengan batas volume; jenis/lokasi terkunci setelah pernah menerima pesanan; tarik pemilik membatalkan Menunggu, bukan Disetujui; Ditarik tidak dapat terbit kembali; moderasi tidak menyembunyikan/memblokir; pembeli melihat penanda/ringkasan nonpribadi; petani menyatakan perbaikan, Admin meninjau/menutup, riwayat tetap; tanggal ketersediaan opsional tanpa kedaluwarsa otomatis. **Sisa pengelolaan akun:** dibahas bersama OPN-004/010 |
| OPN-004 | Kebijakan data pribadi | **Kebijakan inti DEC-014a–g:** kontak hanya saat Disetujui; Admin nomor tersamar; penutupan menunggu transaksi aktif dan menghentikan transaksi baru, kemudian hapus kontak/profil pribadi serta anonimkan riwayat; pendaftaran memerlukan persetujuan eksplisit tanpa centang otomatis dengan versi/waktu tercatat. **Bukti/rancangan lanjutan:** isi kebijakan, pemrosesan cadangan/provider dan waktu penyelesaian penghapusan, validasi anonimisasi, perlakuan bukti persetujuan setelah penutupan serta masa simpan nonpribadi. Tidak ada retensi tambahan data pribadi yang otomatis disetujui. SRS tidak mengesahkan kepatuhan hukum |
| OPN-005 | Akses baca petani dan kolom CSV | **Selesai — DEC-015a/b:** petani tidak mengakses katalog/detail/ekspor pasokan petani lain; tawaran sendiri/harga publik tetap dapat dibaca. CSV pasokan pembeli/Admin hanya ringkasan jenis gabah/wilayah, jumlah tawaran unik, volume tersedia, harga minta minimum/maksimum, satuan/waktu snapshot; tanpa baris/identitas tawaran atau data pribadi. Verifikasi ekspor tetap diperlukan pada implementasi |
| OPN-006 | NFR numerik/operasi | **Target terkonfirmasi DEC-016a/b:** isi 16 px, sentuh 44×44 px, keyboard/zoom 200%, kontras teksnormal 4,5:1/fokus 3:1 dan halaman utama siap ≤ 5 detik. **Rancangan/bukti lanjutan:** profil perangkat/jaringan/data/cache/pengulangan/konkurensi, SLA/backup/recovery dan lingkungan operasional; jangan menganggap Railway dipilih atau target sudah tercapai |
| OPN-007 | Protokol evaluasi/publikasi | **Sebagian selesai — DEC-017a:** gerbang model/baseline/tidak tersedia per provinsi dan horizon, label/versi sesuai hasil. **Bukti/protokol lanjutan:** denominator MASE, split/retrain/cutoff, agregasi laporan, kalibrasi interval baseline, model SHAP wilayah dan evaluasi turunan; skor agregat tidak meloloskan unit gagal. Target numerik proposal tetap, protokol ditinjau tim data |
| OPN-008 | Presisi/pembulatan | **Kebijakan produk DEC-018a/b:** L/U operasional ke rupiah terdekat dengan 0,5 ke atas; hasil asal tersimpan; harga masukan perkg rupiah bulat, volume maksimal dua desimal; presisi berlebih diminta diperbaiki. **Rancangan teknis lanjutan:** interpolasi kuantil, presisi rasio/interval prakiraan dan penyajian nilai turunan; tidak boleh mengubah aturan masukan atau lampu diam-diam |
| OPN-009 | Peta dan sumber wilayah | **Penyajian diputuskan — DEC-019a:** skala kontinu berpusat 0%, arah lebih murah/mahal dan angka jelas, tanpa data penanda netral tersendiri; tidak ada kategori tetap A–D. **Bukti/rancangan lanjutan:** sumber GeoJSON/lisensi/versi/pemetaan data wilayah, tingkat pasar awal serta token/kontras/legenda jangkauan pada fase 3 |
| OPN-010 | Koreksi akun/profil | **Koreksi peran di luar MVP — DEC-020a.** Penutupan akun mengikuti DEC-014d/e/f, bukan aksi kontrak Admin. Perubahan nomor, reset/pembekuan atau koreksi identitas lain yang belum ditetapkan tidak dianggap fitur wajib; bila ingin ditambahkan perlu keputusan lingkup baru. Verifikasi/pemulihan autentikasi dasar yang diperlukan tetap rancangan teknis OPN-001 |

OPN yang mengubah perilaku perlu diputuskan pengguna; yang berupa fakta teknis/data perlu bukti, bukan tebakan. SRS dan IA v0.2 telah disetujui sebagai baseline kebutuhan/struktur untuk fase 3. Persetujuan tidak menyatakan parameter produksi lengkap atau bukti teknis telah lulus. UI Guidelines harus mengikuti baseline ini; perubahan perilaku substantif memerlukan keputusan baru yang dicatat.
