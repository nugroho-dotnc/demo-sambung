# SAMBUNG — UI Guidelines

**Standar Antarmuka, Token OKLCH, Tipografi Rasio Emas, Tata Letak, dan Komponen shadcn/ui**

| Metadata | Nilai |
|---|---|
| Versi | 0.2 — revisi sesuai enam mockup dan arahan warna pengguna |
| Acuan perilaku | [SRS v0.2](SRS_SAMBUNG.md), [IA v0.2](IA_SAMBUNG.md), [ringkasan klarifikasi](phase-2-summary.md), [catatan keputusan](decision-log.md) |
| Format | Delapan bagian utama mengikuti [contoh UI Guidelines](../ui_reference/contoh-ui-guidelines.md), dengan isi domain SAMBUNG |
| Identitas | Layanan pertanian modern; base netral Jagains, primary Forest Green, palet hangat sebagai aksen/status; Plus Jakarta Sans dan Atkinson Hyperlegible Next |
| Implementasi | Target shadcn/ui + Tailwind CSS v4; prototipe React/Vite dengan Radix tersedia, integrasi tema v0.2 belum diaudit |
| Status bukti | Kontras pasangan token dihitung; revisi ini memverifikasi dokumen/tema, belum menguji penerapannya di prototipe |
| Aset pendukung | [Manifest token](assets/sambung-tokens.json), [kontrak CSS](assets/sambung-theme.css), [audit warna](ui-color-audit.md), [matriks](traceability-matrix.md) |

## 1. Pendahuluan & Filosofi Desain Antarmuka

### 1.1 Tujuan dan prinsip

**UI-001 — Harga dan tindakan mudah ditemukan.** Petani memahami jenis gabah, jumlah yang tersedia, posisi harga serta tindakan berikutnya. Pembeli membandingkan pasokan tanpa mengira volume deklaratif sebagai stok terverifikasi. Admin memantau dan meminta tindak lanjut sesuai kewenangannya. Gunakan judul konkret, teks singkat, angka tabular dan susunan yang konsisten; dekorasi tidak bersaing dengan informasi transaksi.

**UI-002 — Perilaku mengikuti SRS/IA.** Halaman, izin, status dan efek aksi berasal dari baseline v0.2. Guideline ini tidak menambahkan pembayaran, transaksi nyata, koreksi peran, akses katalog petani, kewenangan Admin menyembunyikan tawaran, atau akses nomor lengkap Admin. Kegagalan model/data tidak ditutupi dengan angka ilustrasi. Nilai token, skala dan pola komponen di sini adalah rincian desain yang diajukan untuk review, bukan bukti aplikasi sudah mengimplementasikannya.

Prinsip utama:

1. Satu fokus tindakan per konteks, dengan akses ke informasi pendukung yang relevan.
2. Informasi harga selalu menyebut jenis gabah/beras, satuan, wilayah, periode, sumber dan sifatnya: pengamatan, konversi, estimasi atau prakiraan.
3. Warna memiliki peran, tetapi tidak berdiri sendiri. Lampu harga, status kontrak, penanda moderasi dan navigasi bukan satu sistem status yang sama.
4. Latar tenang dan jarak yang jelas; gunakan kartu untuk objek yang dapat dibuka/dipilih, daftar berdivider untuk riwayat, serta grafik untuk perbandingan waktu.
5. **Netral sebagai dasar:** permukaan, teks, sidebar dan divider mengikuti base Jagains. Hijau menjadi primary; kuning/emas/olive/terracotta/cream hanya aksen terarah atau status, bukan warna dasar halaman.
6. Semua harga/kontrak contoh di dokumen ini **ilustrasi**, bukan hasil model, harga terkini atau bukti transaksi nyata.

### 1.2 Hubungan dengan sumber

SRS menetapkan perilaku; IA menetapkan halaman dan hak akses; guideline menetapkan penyajian. [Glosarium](GLOSSARY.md) membedakan tawaran panen, tawaran harga, kontrak simulasi dan temuan moderasi. Draf UI lama hanya pembanding pada bagian 8; diagnosis prototipe di dalamnya tetap merupakan catatan historis dan tidak menjadi bukti kondisi prototipe saat ini. Prototipe React/Vite kini tersedia di workspace; revisi ini menyusun panduan dari mockup, tanpa mengaudit kesesuaian seluruh kode atau mengganti stylesheet prototipe.

Foto pada referensi palet dipakai sebagai **referensi warna**, bukan logo, foto produk atau bukti kepemilikan lahan/mitra. Gambar itu tidak wajib menjadi latar aplikasi. Foto lapangan, bila tersedia dan memiliki izin, dapat menjadi materi pendukung; alur transaksi tidak bergantung padanya.

### 1.3 Referensi teknis yang diperiksa

Konvensi pasangan token mengikuti [theming shadcn](https://ui.shadcn.com/docs/theming), pemetaan variabel memakai [`@theme inline` Tailwind](https://tailwindcss.com/docs/theme), dan selector mode mengikuti [dark mode Tailwind](https://tailwindcss.com/docs/dark-mode). Penamaan jalur `resources/css/app.css` pada bagian 6 adalah target integrasi yang diusulkan sesuai format contoh, bukan klaim berkas aplikasi sudah ada.

Kontras dihitung dengan [metode G 18 W 3 C](https://www.w3.org/WAI/WCAG21/Techniques/general/G18); ambang proyek berasal dari DEC-016a. Pemeriksaan nonteks tambahan merujuk [penjelasan W 3 C tentang kontrol/grafik](https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html). Lulus pasangan token tidak sama dengan lulus aksesibilitas aplikasi secara menyeluruh.

### 1.4 Referensi mockup dan batas adaptasinya

Enam gambar pada folder mockup menjadi acuan komposisi: topbar, sidebar berlabel, breadcrumb, judul/subjudul, kartu berborder tipis, panel utama/ringkasan dan action bar bawah. Nilai token dasar berasal dari dokumen Jagains, bukan sampling piksel abu kebiruan atau tombol navy pada PNG. Primary SAMBUNG yang sudah dipilih tetap hijau. Rancangan gelap merupakan adaptasi token karena mockup yang tersedia hanya menampilkan mode terang.

| Mockup yang diperiksa | Halaman IA | Pola visual yang dipakai | Isi yang diselaraskan dengan SRS/IA |
|---|---|---|---|
| [Beranda Petani](<../ui_reference/mockup/Beranda Petani.png>) | PT-01 | Panel harga lebar, pembanding dipisah divider, grafik dan langkah berikutnya, bantuan singkat | Jenis GKP/GKG, horizon 2/4 pekan, interval 80% bila valid; bukan 3–4 pekan/90% atau alert lonjakan otomatis |
| [Dasbor Produsen](<../ui_reference/mockup/Dasbor Produsen.png>) | PR-01, menuju PR-02 | Tiga ringkasan setara, filter sejajar, daftar pasokan dan panel panduan | Label ruang kerja Pembeli; tersedia berbeda dari total dan bukan stok terverifikasi; petani tidak membuka katalog |
| [Jual Hasil Panen](<../ui_reference/mockup/Jual Hasil Panen.png>) | PT-02/04 | Form sekitar 3/5 lebar, panel harga/ringkasan 2/5, kelompok field dan action bar | Mutu/tanggal boleh belum diketahui; tidak semua field wajib. Acuan bisa tidak tersedia; harga merah konfirmasi, bukan blokir permanen. Stepper hanya pengelompokan tampilan, tanpa fitur simpan draf server baru |
| [Kontrak](<../ui_reference/mockup/Kontrak.png>) | PT-06 | Identitas/rincian di kiri, pemeriksaan harga di kanan, action bar yang jelas | Status resmi dan tenggat dinamis; pengaju sudah menyetujui harga aktif, pihak lawan menerima. Tidak menyalin tiga centang, periode contoh atau transaksi nyata |
| [Papan Harga 2 Sisi](<../ui_reference/mockup/Papan Harga 2 Sisi.png>) | PB-02 | Filter di atas, rantai harga kiri, ringkasan selisih kanan, grafik penuh di bawah | Pengamatan gabah vs ekuivalen beras berlabel dan pembanding setara; sumber/periode nyata. Bukan data contoh 12 pekan yang dianggap terverifikasi |
| [Peta Publik](<../ui_reference/mockup/Peta Publik.png>) | PB-03/03a/03b | Filter, area peta besar, legenda, ringkasan ekstrem dan penjelasan bawah; tautan tabel terlihat | Skala kontinu signed berpusat 0%, bukan A–D. Geometri provinsi valid, tabel setara, SHAP sesuai model; gambar skematis bukan data batas administratif |

Topbar berisi identitas, konteks wilayah dan menu akun bila masuk; pemilih wilayah tidak membatasi cakupan transaksi hanya Jawa Timur. Sidebar menampilkan tujuan yang diizinkan bagi peran aktif, bukan semua ruang kerja seperti pada mockup. Pusat notifikasi, profil/mode dan bantuan tetap mudah dicapai sesuai IA. Angka/nama contoh serta label “WIREFRAME · DATA ACUAN” tidak menjadi data atau badge wajib aplikasi. Label SIMULASI pada transaksi tetap mengikuti SRS.

## 2. Sistem Warna & Semantic Tokens (OKLCH)

### 2.1 Base Jagains, primary SAMBUNG dan aksen

**UI-003 — Base netral; warna merek digunakan terarah.** Arahan terbaru pengguna (DEC-021a) menggantikan pemakaian Warm Cream sebagai latar umum pada DEC-011c. Gunakan token netral Jagains pada background/foreground/card/popover/secondary/muted/accent/border/sidebar; pertahankan primary hijau SAMBUNG. Manifest menyimpan nilai OKLCH Jagains persis dan HEX warna merek/aksen; CSS mempertahankan atau mengonversinya sesuai sumber. Kolom berikut adalah nilai canonical, bukan perkiraan warna dari mockup.

| Palet SAMBUNG | HEX acuan | Peran revisi |
|---|---|---|
| Forest Green | `#3E5A3A` | Primary terang dan identitas merek; primary gelap tetap `#B7D2A5` untuk keterbacaan |
| Olive Green | `#8A9A3A` | Aksen sekunder terbatas, bukan latar sidebar atau halaman |
| Sunflower Yellow | `#FFD55A` | Sorotan kecil dan peringatan yang sesuai; bukan tombol utama atau fokus global |
| Honey Gold | `#F4A62A` | Aksen/ilustrasi pendukung, gunakan teks gelap yang diuji |
| Terracotta | `#C86B3C` | Keluarga aksen/status bahaya dengan turunan semantik sesuai kontras |
| Warm Cream | `#FFF3D6` | Tint aksen kecil bila diperlukan; bukan background/card/shell default |

`accent` bawaan shadcn berarti hover netral, bukan seluruh palet warna aksen merek. Aksen kuning memakai `highlight`; status memakai `price-*`/`review`/`destructive`. Jangan mengubah `accent` global menjadi kuning karena itu mewarnai semua hover menu/baris. Tidak ada kuota yang mewajibkan semua warna palet tampil pada setiap layar.

| Token semantik | Light (`:root`) | Dark (`.dark`) | Pemakaian |
|---|---|---|---|
| `background` / `foreground` | `oklch(1 0 0)` / `oklch(0.145 0 0)` | `oklch(0.145 0 0)` / `oklch(0.985 0 0)` | Latar dasar dan teks, sama dengan Jagains |
| `card` / `card-foreground` | `oklch(1 0 0)` / `oklch(0.145 0 0)` | `oklch(0.205 0 0)` / `oklch(0.985 0 0)` | Kartu/topbar; surface Jagains |
| `popover` / `popover-foreground` | `oklch(1 0 0)` / `oklch(0.145 0 0)` | `oklch(0.205 0 0)` / `oklch(0.985 0 0)` | Dialog/menu; surface Jagains |
| `primary` / `primary-foreground` | `#3E5A3A` / `oklch(1 0 0)` | `#B7D2A5` / `oklch(0.145 0 0)` | Aksi utama hijau SAMBUNG |
| `primary-hover` | `#31492F` | `#C7DEB8` | Hover primary; foreground tetap pasangan primary |
| `secondary` / `secondary-foreground` | `oklch(0.967 0.001 286.375)` / `oklch(0.21 0.006 285.885)` | `oklch(0.274 0.006 286.033)` / `oklch(0.985 0 0)` | Tombol pendukung/status kontrak netral Jagains |
| `muted` / `muted-foreground` | `oklch(0.97 0 0)` / `oklch(0.556 0 0)` | `oklch(0.269 0 0)` / `oklch(0.708 0 0)` | Canvas netral; helper gray hanya pada permukaan yang disahkan |
| `accent` / `accent-foreground` | `oklch(0.97 0 0)` / `oklch(0.205 0 0)` | `oklch(0.269 0 0)` / `oklch(0.985 0 0)` | Hover netral Jagains |
| `highlight` / `highlight-foreground` | `#FFD55A` / `oklch(0.145 0 0)` | `#FFD55A` / `oklch(0.145 0 0)` | Aksen Sunflower terbatas dan noninteraktif |
| `border` | `oklch(0.922 0 0)` | `oklch(1 0 0 / 10%)` | Divider dekoratif Jagains; alpha gelap bukan batas kontrol |
| `input` | `#7A7A7A` | `#8C8C8C` | Override abu solid agar batas kontrol memenuhi 3:1 |
| `ring` | `#3E5A3A` | `#B7D2A5` | Override hijau primary agar fokus solid memenuhi 3:1 |
| `sidebar` / `sidebar-foreground` | `oklch(0.985 0 0)` / `oklch(0.145 0 0)` | `oklch(0.205 0 0)` / `oklch(0.985 0 0)` | Sidebar netral Jagains |
| `sidebar-accent` / `sidebar-accent-foreground` | `#EAF1E7` / `#3E5A3A` | `#2B3826` / `#B7D2A5` | Seleksi menu: tint hijau dan teks primary |
| `destructive` / `destructive-foreground` | `#9B3529` / `oklch(1 0 0)` | `#F1AA8C` / `#311A12` | Aksi pengakhiran sah; keluarga terracotta |

`canvas` adalah alias `muted`: area kerja berwarna abu netral seperti mockup; kartu/topbar tetap `card`, sidebar memakai `sidebar`. Halaman publik dapat memakai `background`. Jangan mengisi layar dengan Warm Cream, Olive atau tint hijau. `contract`/`contract-surface` tetap alias pasangan secondary. Alias `sidebar-primary`, `sidebar-border` dan `sidebar-ring` mengikuti primary/border/ring; seleksi menu ditandai tint hijau, ikon/label dan penanda aktif, bukan warna saja.

**Pengecualian aksesibilitas yang disengaja:** input dan ring tidak menyalin nilai tipis/transparan Jagains; keduanya memakai override pada tabel agar target kontrol/fokus proyek tetap tercapai. `muted-foreground` Jagains tidak disahkan untuk teks normal di atas canvas/muted/secondary/accent: gunakan `foreground` di sana, termasuk subjudul halaman. Teks helper gray dipakai pada card/background/popover yang tercantum dalam audit. Border alpha gelap hanya dekoratif dan belum diaudit sebagai kontrol. Ini mempertahankan base Jagains tanpa mewarisi pasangan yang gagal target SAMBUNG.

### 2.2 Harga, kontrak, moderasi dan galat

**UI-004 — Peran warna tidak dicampur.** Hijau merek tetap diperbolehkan sesuai keputusan pengguna. Lampu dibedakan melalui bentuk, ikon, label dan alasan; tidak menyatakan semua penggunaan hijau berarti harga wajar.

| Token teks/garis dan permukaan | Light | Dark | Isi yang wajib menyertai |
|---|---|---|---|
| `price-within` / `price-within-surface` | `#246447` / `#E8F2E4` | `#A9D6B0` / `#203E2B` | Ikon centang + “Dalam rentang wajar” |
| `price-caution` / `price-caution-surface` | `#775000` / `#FFF0C2` | `#FFD55A` / `#453819` | Ikon peringatan + posisi di bawah/di atas rentang |
| `price-low` / `price-low-surface` | `#9B3529` / `#FBE5DD` | `#FFC0AB` / `#4A2922` | Ikon peringatan tegas + “Jauh di bawah rentang wajar” |
| `review` / `review-surface` | `#7A4B21` / `#FFF0D2` | `#E9C78D` / `#3F3220` | Ikon catatan + “Sedang diminta perbaikan” dan ringkasan |
| `contract` / `contract-surface` | Alias secondary | Alias secondary | Nama status kontrak, ikon sesuai tahap, bukan lampu harga |

Kontrak Menunggu Kesepakatan/Disetujui/Selesai/Dibatalkan/Ditolak/Kedaluwarsa memakai badge netral dengan label lengkap. Konfirmasi selesai 0/1/2 ditampilkan sebagai informasi terpisah; 1/2 masih Disetujui. Temuan Terbuka/Menunggu Peninjauan/Ditutup adalah status **temuan**, bukan status kontrak. Galat field memakai teks, ikon serta `aria-invalid`; warna `destructive` boleh membantu tetapi tidak membuat seluruh layar merah.

### 2.3 Grafik dan peta

**UI-005 — Data tidak diartikan dari warna saja.** Gunakan label langsung, gaya garis dan ringkasan/tabel setara. Observasi solid, prakiraan model garis putus, baseline garis titik, turunan gabah berlabel jenis/metode. Urutan seri tetap pada semua halaman yang membandingkan data sama.

| Seri token | Light | Dark |
|---|---|---|
| `chart-1` | `#3E5A3A` | `#B7D2A5` |
| `chart-2` | `#404040` | `#FAFAFA` |
| `chart-3` | `#686868` | `#B4B4B4` |
| `chart-4` | `#525252` | `#D4D4D4` |
| `chart-5` | `#737373` | `#A3A3A3` |
| `interval` | `oklch(0.97 0 0)` | `oklch(0.269 0 0)` |

Grafik mengikuti mockup: satu seri utama hijau dan seri pembanding netral/garis berbeda, sehingga aksen kuning/emas tidak menyebar ke seluruh grafik. `chart-1` primary, `chart-2…5` netral; label tetap wajib. Pita interval memakai `interval` sebagai fill, dengan batas garis `chart-1` dan nilai interval dalam teks. Fill bukan satu-satunya cara memahami interval. Tooltip boleh menambah detail; pilih titik lewat keyboard/sentuhan dan sediakan ringkasan yang tidak memerlukan hover.

Peta PB-03 memakai skala **kontinu** `map-low`→`map-mid` pada 0%→`map-high`, dengan legenda arah/jangkauan dan persentase numerik. Light: `#3E5A3A`→`oklch(0.97 0 0)`→`#9B3529`; dark: `#A9D6B0`→`oklch(0.269 0 0)`→`#F1AA8C`. Tanpa data memakai `map-missing` dengan pola diagonal/label “Data belum tersedia”, bukan fill polos yang sama dengan 0% valid. Provinsi terpilih memakai kontur dua lapis `card`/`foreground`, bukan primary yang menyerupai salah satu nilai data. Selisih terhadap median dan disparitas maksimum–minimum tetap dua metrik terpisah. Tabel PB-03a mempertahankan filter, angka dan himpunan data yang sama.

### 2.4 Bukti kontras

**UI-006 — Audit pasangan aktual.** [Audit warna](ui-color-audit.md) memeriksa 106 pasangan solid: teks utama/sekunder, primary/hover, status, kontrol/fokus dan garis grafik pada permukaan yang disahkan. Semua 106 memenuhi ambang masing-masing; rasio dihitung sebelum angka laporan dibulatkan. Nilai OKLCH netral Jagains dipertahankan persis; warna sumber HEX dikonversi dan diperiksa kembali ke kode sRGB 8-bit yang sama.

| Pasangan | Light | Dark | Ambang |
|---|---:|---:|---:|
| Teks primary pada primary | 7,70:1 | 12,04:1 | 4,5:1 |
| Helper gray pada card | 4,73:1 | 6,91:1 | 4,5:1 |
| Batas input pada card | 4,29:1 | 5,33:1 | 3:1 |
| Ring fokus pada background | 7,70:1 | 12,04:1 | 3:1 |
| Teks harga hijau pada tint sendiri | 6,11:1 | 7,24:1 | 4,5:1 |
| Teks harga kuning pada tint sendiri | 6,31:1 | 8,14:1 | 4,5:1 |
| Teks harga merah pada tint sendiri | 5,91:1 | 8,20:1 | 4,5:1 |
| Teks moderasi pada tint sendiri | 6,53:1 | 7,71:1 | 4,5:1 |

Olive mentah di Warm Cream hanya 2,82:1, Honey Gold 1,84:1 dan Terracotta 3,39:1: **jangan gunakan sebagai teks normal kecil**. Warm Cream sendiri hanya aksen terbatas pada revisi ini; pengujian terhadap putih/canvas juga harus memakai pasangan aktual. Gunakan turunan semantik/pasangan foreground yang diuji. Divider `border` boleh lebih redup karena dekoratif; kontrol wajib memakai `input`.

Audit ini tidak mengesahkan semua interpolasi peta, opacity, gambar, overlay, state disabled, font atau komponen browser. Jangan mengubah fill menjadi `/10` lalu mewarisi klaim kontras solid. Warna peta antara endpoint tidak diklaim semuanya≥ 3:1; kontur, label numerik, pemilihan aksesibel dan tabel harus diperiksa pada implementasi. Fokus memiliki offset sehingga berbatasan dengan permukaan yang diuji. Highlight tidak menjadi wadah kontrol interaktif; jika konteks latar berubah, hitung ulang fokus/teksnya.

## 3. Tipografi: Skala Rasio Emas (φ = 1,618)

### 3.1 Keluarga font dan skala

**UI-007 — Dua keluarga font.** Judul memakai **Plus Jakarta Sans**; isi, kontrol dan angka harga memakai **Atkinson Hyperlegible Next**. Gunakan bobot 400/600/700. Data angka memakai `price-value` untuk meminta lining/tabular numbers; uji fitur pada berkas font sebenarnya, bukan menganggap deklarasi CSS membuktikan dukungannya.

Metadata font resmi mengonfirmasi nama, distribusi variable dan lisensi OFL: [Atkinson Hyperlegible Next](https://raw.githubusercontent.com/google/fonts/main/ofl/atkinsonhyperlegiblenext/METADATA.pb) dan [Plus Jakarta Sans](https://raw.githubusercontent.com/google/fonts/main/ofl/plusjakartasans/METADATA.pb). Simpan pemberitahuan lisensi saat mendistribusikan font: [OFL Atkinson](https://raw.githubusercontent.com/google/fonts/main/ofl/atkinsonhyperlegiblenext/OFL.txt), [OFL Plus Jakarta](https://raw.githubusercontent.com/google/fonts/main/ofl/plusjakartasans/OFL.txt). Tidak ada berkas font yang telah dipasang pada aplikasi dalam pekerjaan dokumentasi ini.

Dasar 16 px pada pengaturan browser standar, sesuai DEC-016a. Hormati pembesaran pengguna. Rasio emas menjadi jangkar, bukan alasan membuat semua judul sangat besar; beberapa nilai antara dipilih untuk layar kerja.

| Kelas | Ukuran pada dasar 16 px | Dasar hitung | Line-height | Bobot | Pemakaian |
|---|---:|---|---:|---:|---|
| `text-display-hero` | 42–68 px | φ³× 16≈67,8 →68 maks | 1,10 | 700 | Judul publik bila ruang cukup; bukan harga/heading setiap panel |
| `text-display-xl` | 32–42 px | φ²× 16≈41,9 →42 maks | 1,15 | 700 | Judul publik/detail bila ruang cukup |
| `text-workspace-title` | 28–32 px | Antara optis mengikuti kepadatan mockup | 1,20 | 700 | H1 halaman kerja/form/kontrak |
| `text-display-lg` | 26–32 px | φ× 16≈25,9; maksimum 32 sebagai antara optis | 1,25 | 700 | H2 seksi utama |
| `text-display-md` | 26 px | φ× 16≈25,9 | 1,30 | 600 | H3 panel/dialog |
| `text-display-sm` | 21 px | √φ× 16≈20,4 →21 | 1,35 | 600 | H4 kelompok informasi |
| `text-body-lg` | 18 px | φ^0,25 × 16≈18,0 | 1,60 | 400 | Pengantar singkat |
| `text-body-base` | 16 px | Dasar | 1,50 | 400 | Isi, input dan penjelasan pengambilan keputusan |
| `text-body-medium` | 16 px | Dasar | 1,50 | 600 | Label field/tombol dengan `font-semibold` |
| `text-body-sm` | 14 px | 16/φ^0,25≈14,2 | 1,50 | 400/600 | Metadata sekunder dan badge kontrak; bukan input atau alasan penting |
| `text-caption-xs` | 13 px | 16/√φ≈12,6 →13 | 1,40 | 400 | Metadata sangat sekunder; tidak untuk harga/status/aksi penting |

Kelas `text-*` pada tabel hanya menetapkan ukuran dan line-height. Font serta bobot harus dipasang bersama: H1 kerja `font-display text-workspace-title font-bold`, H1 publik dapat `font-display text-display-xl font-bold`, H2 `font-display text-display-lg font-bold`, H3 `font-display text-display-md font-semibold`, H4 `font-display text-display-sm font-semibold`. Isi memakai `font-sans text-body-base font-normal`; label/tombol `font-sans text-body-medium font-semibold`. Panel sederhana memakai judul 21 px (`font-display text-display-sm font-semibold`) dengan tingkat heading sesuai struktur dokumen, bukan dipaksa menjadi H4. Jangan mengandalkan gaya bawaan elemen heading setelah reset Tailwind.

Harga utama boleh 32–42 px pada font isi berbobot 600; satuan `/kg` memakai 16 px dan tetap berdekatan. Harga tabel/list minimal 16 px dan rata kanan; tidak semua harga harus memakai ukuran hero. Judul/font harga tidak menggantikan satuan atau label sumber. Baris bacaan sekitar 45–70 karakter, kiri rata; jangan meratakan kiri-kanan paragraf.

### 3.2 Angka, satuan dan pembulatan

**UI-008 — Bentuk angka mengikuti domain.** Satu formatter berlokal `id-ID` menangani harga, angka, persen, tanggal dan volume; jangan membentuk rupiah berbeda di tiap halaman. Implementasi parser harus membedakan titik ribuan dan koma desimal secara eksplisit.

| Isi | Bentuk | Aturan |
|---|---|---|
| Harga per kg | `Rp7.000/kg` | Masukan rupiah bulat; pecahan rupiah diminta diperbaiki, tidak dipotong otomatis |
| Volume | `125,50 kg` | Maksimal dua desimal; perhitungan/reservasi mempertahankan presisi |
| Rentang wajar | `Rp6.652–6.939/kg` | L/U operasional dibulatkan ke rupiah terdekat,0,5 ke atas, sama dengan penilaian; hasil asal dapat ditelusuri |
| Selisih | `Rp350 (5,26%) di bawah batas bawah` | Arah dan pembanding disebut; di atas rentang tetap kuning |
| Peta | `−16,67% dari median` | Tanda dan “lebih murah/mahal”;0% berbeda dari data kosong |
| Data kosong | `Acuan harga belum tersedia` | Tidak diganti 0, tanda hijau atau rentang ilustrasi |
| Mutu/tanggal | `Belum diukur` / `Belum ditentukan` | Bukan 0 atau tanggal otomatis |

Sumber/periode data berbeda dari waktu perhitungan. Tulisan “diperbarui” harus jelas merujuk sumber atau perhitungan; tidak membuat observasi lama tampak sebagai harga pekan ini. Batas toleransi dihitung dari L operasional; bila perlu dirinci, tampilkan presisi yang menjelaskan warna. Pembulatan masukan, interval prakiraan dan rasio tidak disamakan tanpa dasar.

## 4. Spacing, Tata Letak, & Hukum Kedekatan

### 4.1 Spacing dan radius

**UI-009 — Dekatkan hal yang satu keputusan.** Label/input/pesan field berkelompok; kelompok harga memuat jenis, satuan, acuan dan lampu; informasi kontrak dikelompokkan menurut harga, volume, pihak, riwayat dan tindakan. Jangan membungkus setiap baris dengan kartu.

| Tingkat | Jarak | Kelas/pola | Pemakaian |
|---|---:|---|---|
| Micro | 4–8 px | `gap-1`, `gap-2` | Ikon/teks, label/helper yang satu field |
| Meso | 12–16 px | `gap-3`, `gap-4` | Antar field dan pasangan tombol |
| Padding komponen | 16 px mobile,24 px desktop | `p-4 md:p-6` | Kartu tawaran/form/dialog |
| Macro | 24–32 px | `gap-6`, `gap-8` | Kelompok mandiri, daftar dan ringkasan |
| Global | 48–64 px | `py-12`, `py-16` | Seksi publik; halaman transaksi tidak dipaksa setinggi layar |

Dasar spacing 4 px. Radius `sm=4px`, `md=6px`, `lg=8px`, `xl=12px`; input/select `md`, tombol `lg`, objek/dialog/sheet `xl`. Lingkaran untuk avatar/lampu; jangan memakai pill besar untuk semua panel. Kartu biasa border tanpa bayangan; elevasi hanya untuk overlay dan harus memakai token yang ditetapkan implementasi, bukan nilai acak per halaman.

### 4.2 Responsif, navigasi dan mode

**UI-010 — Satu struktur informasi di semua ukuran.** `app-wrap` maksimum 76 rem (1.216 px pada dasar 16), margin kiri/kanan setara, padding 16 px di layar kecil dan 24 px pada≥ 1.024 px. Form maksimum 42 rem bila diperlukan. Spesifikasi ini adalah keputusan tata letak, bukan tambahan halaman di luar IA.

| Lebar CSS | Penyajian |
|---|---|
| <640 px | Satu kolom; informasi/tindakan penting lebih dahulu. Navigasi berlabel melalui `Sheet`; kontrol utama memenuhi lebar yang dibutuhkan, tetap≥ 44 × 44 px |
| 640–1.023 px | Kelompok ringkasan dapat dua kolom jika label tidak terpotong; navigasi tetap dapat dibuka dengan label |
| ≥ 1.024 px | Sidebar berlabel dan konten utama; panel acuan di samping form mengikuti mockup. Tabel Admin mempertahankan label/kolom penting |

Daftar pasokan mobile menjadi baris/kartu objek dengan jenis, harga, tersedia, kecamatan dan status. Tabel lebar boleh berada dalam area gulir lokal yang diberi nama serta dapat dijangkau keyboard jika seluruh data memang diperlukan; halaman keseluruhan tidak bergulir horizontal. Jangan mengecilkan teks atau menghilangkan informasi utama demi memuat tabel.

Menu mengikuti IA: petani Beranda/Tawaran Saya/Kontrak, pembeli Dasbor/Katalog/Pesanan-Kontrak, Admin tujuh panel operasional. Petani tidak memiliki menu/link katalog orang lain. Detail kontrak adalah halaman yang sama bagi kedua pihak, dengan aksi/status sesuai izin. Alias PT-08/PR-04/PR-05/PR-06/PR-08 tidak membuat halaman atau salinan data baru.

Tombol pilihan mode terang/gelap tersedia pada shell publik dan akun. Rekomendasi implementasi: gunakan preferensi sistem bila belum ada pilihan, lalu pertahankan pilihan pengguna; kegagalan penyimpanan preferensi tidak mengubah akses atau menghalangi tugas. Cara penyimpanannya bukan keputusan backend dalam guideline ini. Native control, tanggal, scrollbar dan popover mengikuti `color-scheme` mode aktif; cegah kilatan teks tidak terbaca saat halaman dimuat.

### 4.3 Pola shell dan komposisi dari mockup

Ukuran berikut adalah spesifikasi adaptasi, bukan hasil pengukuran CSS asli PNG. Pada desktop, topbar sekitar 72 px dan sidebar sekitar 208 px dengan pembatas tipis; gunakan token `--shell-header`/`--shell-sidebar`. Topbar tetap di atas dan sidebar melekat di bawahnya, tetapi dapat diubah menjadi alur biasa bila tinggi viewport/zoom menyebabkan konten atau fokus terpotong. Sediakan tautan Lewati ke konten utama. Mobile memakai header ringkas dan Sheet, tanpa sidebar permanen.

Area kerja `bg-canvas` memuat breadcrumb ringkas, H1 dan satu kalimat penjelas, kemudian filter atau panel utama. Gunakan padding luar 24–32 px desktop/16 px mobile, gap 24 px antar panel, padding kartu 24 px desktop/16 px mobile, border dekoratif dan radius 8–12 px. Harga/acuan memakai primary seperlunya; mayoritas judul/angka netral. Ikon outline konsisten sekitar 20 px; target interaktif tetap minimal 44 px.

| Pola | Susunan desktop | Susunan mobile |
|---|---|---|
| Dasbor | Ringkasan lebar atau tiga metrik sejajar, kemudian panel utama + tindak lanjut sekitar 2:1 | Ringkasan penting, tindakan, lalu panel lain satu kolom |
| Form panen/kontrak | Konten sekitar 3/5, acuan/ringkasan 2/5; divider memisah kelompok | Field → acuan/hasil → ringkasan → tindakan; acuan relevan tetap dekat field harga |
| Papan harga | Filter tiga kolom bila muat; tabel rantai dan ringkasan 2:1; grafik penuh bawah | Filter bertumpuk, rantai harga lalu ringkasan dan grafik |
| Peta | Filter di atas, peta lebar, legenda kontinu dan ringkasan ekstrem, penjelasan bawah | Filter, peta/tabel yang dapat dioperasikan, legenda dan angka tetap terbaca |
| Action bar | Panel lebar penuh di akhir konten: status/penjelasan kiri, sekunder/primary kanan | Tombol dapat bertumpuk dan label membungkus; tidak menutupi keyboard atau pesan galat |

Stepper bernomor dapat mengelompokkan review/pengiriman seperti gambar, tetapi tidak menetapkan status kontrak baru, batas lima tindakan baru atau fitur simpan draf server. Tiga langkah tampilan bukan tiga kali persetujuan. Action bar tidak dipaksa fixed/sticky; bila dibuat sticky, ruang dan scroll-margin harus menjaga field/fokus tetap terlihat. H1 kerja memakai 28–32 px dan judul panel sekitar 21 px dengan tingkat heading semantik yang benar; jangan membesarkan semua judul menjadi display hero.

### 4.4 Fokus, target sentuh dan gerak

**UI-011 — Kontrol dapat digunakan tanpa pointer presisi.** Minimum 44 × 44 px berlaku untuk tombol, input/trigger, ikon interaktif, toggle dan target navigasi; badge informatif bukan otomatis target sentuh. Jangan menyebut ukuran default shadcn sudah memenuhi minimum tanpa memeriksanya.

- Outline fokus 3 px solid memakai `ring`, offset 3 px sehingga berbatasan dengan permukaan yang diuji. Jangan meredupkan menjadi `/50` atau menghapus fokus tanpa pengganti.
- Urutan fokus mengikuti urutan baca; dialog mengelola fokus dan mengembalikannya ke pemicu. Tindakan tidak hanya tersedia lewat hover.
- Zoom 200% dan keyboard diuji; pesan galat mengait ke field, pengumuman status tidak mengganggu pembaca layar berulang saat setiap karakter diketik.
- Micro-feedback maksimal sekitar 150 ms untuk hover/press/perubahan panel; tidak ada scroll reveal/parallax/penghitung harga yang bergerak. Hormati `prefers-reduced-motion`; konten tetap terlihat tanpa animasi.
- `forced-colors` tetap memiliki outline sistem, label dan ikon; pola peta/tabel menyediakan informasi di luar warna.

## 5. Standar Komponen shadcn/ui

### 5.1 Pilihan basis dan umpan balik

**UI-012 — Komponen semantik lebih dahulu.** Gunakan primitive shadcn yang tersedia; komponen domain menggabungkannya untuk harga, volume, kontrak dan moderasi. Jangan membuat ulang modal/select lewat `div` tanpa penanganan aksesibilitas. Jalur `@/components/ui/*` adalah konvensi target; periksa kesesuaiannya dengan komponen prototipe sebelum integrasi.

**Basis generator shadcn perlu dikonfirmasi.** Prototipe saat ini mencantumkan paket Radix dan Tailwind v4, tetapi itu belum membuktikan semua komponen hasil generator atau API yang dibutuhkan sudah terpasang. Dokumentasi resmi yang diperiksa saat fase 3 menyediakan jalur Base UI dan Radix. Contoh referensi tidak cukup untuk memutuskan basis aplikasi. Periksa `components.json` dan sumber hasil generator saat implementasi, lalu gunakan API dari basis tersebut. Untuk navigasi bergaya tombol, gunakan tautan semantik dan helper gaya; dokumentasi [Button Base UI](https://ui.shadcn.com/docs/components/base/button) memperingatkan bahwa `render` pada Button tidak mempertahankan semantik tautan. Jangan menyalin contoh `asChild`/`render` dari basis lain tanpa pemeriksaan.

**UI-013 — Tombol dan pesan mengikuti jenis aksi.** Tombol utama `primary` untuk aksi paling penting pada panel, sekunder/outline untuk pendukung, `destructive` untuk pengakhiran yang sah, ghost untuk utilitas dengan label aksesibel. Navigasi memakai `<a>`/router link; aksi memakai `<button>`. Semua varian interaktif minimal 44 px, `h-auto` bila label membungkus; teks dapat tumbuh tanpa terpotong.

| Kejadian | Komponen/pola | Aturan |
|---|---|---|
| Field tidak valid | FieldError + ringkasan galat bila banyak | Terlihat dekat field, bukan toast; isian tidak hilang |
| Harga merah perlu dipahami | Panel harga + checkbox konfirmasi eksplisit | Terkait harga/versi sekarang; bukan centang otomatis atau persetujuan umum |
| Batal/tolak butuh alasan | Dialog dengan form | Alasan wajib, jelaskan efek volume/status sebelum kirim |
| Tarik tawaran | AlertDialog | Jelaskan jumlah Menunggu yang dibatalkan dan Disetujui yang tetap; alasan otomatis tersimpan menurut SRS |
| Aksi asinkron selesai/gagal | Toast singkat + keadaan halaman yang diperbarui | Jangan menyembunyikan kegagalan transaksi di toast yang cepat hilang |
| Kondisi menetap | Alert/teks status di halaman | Data belum tersedia, penutupan akun tertunda, model baseline |
| Bantuan penting | Teks terlihat | Tooltip/Popover hanya detail tambahan |

Judul 5.1 pada contoh membahas Sonner; SAMBUNG mempertahankan **fungsi toast** tanpa klaim universal “Toast lama selalu diganti Sonner”. Per pemeriksaan sumber, [Base UI Toast](https://ui.shadcn.com/docs/components/base/toast) memakai `@/components/ui/toast`, sedangkan [Radix Sonner](https://ui.shadcn.com/docs/components/radix/sonner) merupakan jalur berbeda. Pilih adapter yang sesuai basis terpasang dan gunakan satu jalur notifikasi sementara. Pusat notifikasi transaksi PT-09 tetap fitur tersendiri, bukan digantikan toast.

### 5.2 Spesifikasi komponen domain dan daftar komponen

**UI-014 — Form menjaga satuan, presisi dan data yang belum diketahui.** Field berlabel terlihat, deskripsi singkat, satuan eksplisit dan galat yang menjelaskan perbaikan. Harga per kg rupiah bulat, volume maksimal dua desimal; inputmode mendukung perangkat sentuh, tetapi server tetap memvalidasi. Pilihan mutu “Belum diukur” dan tanggal “Belum ditentukan” nyata, bukan placeholder yang hilang. Jangan mengisi nol atau tanggal hari ini otomatis. Jenis/lokasi terkunci setelah pernah menerima pesanan; tampilkan alasannya serta arah membuat tawaran baru, bukan kontrol redup tanpa penjelasan. Volume total minimum adalah dicadangkan+Disetujui+Selesai; pengubahan bersamaan harus memuat ulang jika konflik.

**UI-015 — Autentikasi dan persetujuan.** AU-01/02 memakai nomor HP+OTP dengan jumlah digit, waktu tunggu dan percobaan sesuai konfigurasi autentikasi yang masih perlu ditetapkan. Sediakan pengisian kode yang dapat ditempel/autofill dan label satu kode logis; jangan memaksa enam digit hanya karena contoh lama memakai enam kotak. Setelah OTP akun baru, AU-03 memilih satu peran dan persetujuan eksplisit; versi dokumen dapat dibaca sebelum dicentang dan tidak dicentang otomatis. Admin masuk lewat email/sandi AU-04 tanpa daftar publik. Tidak ada pilihan/kontrol koreksi peran pada PT-10/AD-05.

**UI-016 — Blok acuan dan lampu harga.** Susunan: jenis/wilayah/periode → L/U operasional dan satuan → estimasi bukan jaminan serta mutu belum diperhitungkan → sumber/umur → komponen/harga pembanding yang valid. Pada form petani dan pengajuan harga pembeli, gunakan slider harga bersegmen dengan urutan merah → kuning → hijau → kuning: merah di bawah toleransi, kuning di sekitar batas bawah, hijau di dalam rentang termasuk batas, dan kuning di atas U. Slider selalu memiliki input angka bulat yang dapat diketik, marker L/U, nilai harga saat ini, label status, ikon dan alasan; keyboard serta pembaca layar berinteraksi dengan input range yang sama. Lampu berupa ikon+tanda bentuk+label+alasan, dekat harga yang diperiksa. Nilai δ awal 3% dapat dikonfigurasi; jangan menulis persen ini sebagai konstanta bisnis pada komponen. Ketika acuan tidak tersedia, tampilkan keadaan itu tanpa zona seolah valid dan tetap izinkan penerbitan/pemesanan sesuai SRS.

Contoh **ilustrasi** microcopy:

> Harga Anda Rp6.300/kg, Rp350 (5,26%) di bawah batas bawah acuan. Tinjau kembali harga dan syaratnya.
>
> Konfirmasi: “Saya memahami peringatan harga ini dan ingin melanjutkan.”

Penjelasan komponen rumus bukan SHAP dan rentang P10/P90 rasio historis bukan jaminan interval prakiraan 80%. Status yang ditampilkan di katalog dapat memakai acuan terkini berlabel waktu; pada kontrak Disetujui, hasil pemeriksaan saat kesepakatan tidak ditulis ulang oleh perubahan parameter.

**UI-017 — Kontrak dan volume.** Detail memisahkan harga minta tawaran, tawaran harga aktif, volume kontrak, volume total tawaran dan tersedia. Mengajukan harga adalah persetujuan pengaju; tombol penerimaan menyebut harga/versi yang diterima dan hanya untuk pihak lawan. Negosiasi tidak memakai batas dua putaran dan tidak mereset tenggat. Selesai 0/1/2 jelas; konfirmasi pertama tetap Disetujui, kedua menjadi Selesai. Waktu Menunggu memakai tenggat tersimpan pada pesanan, bukan durasi global Admin terbaru. Konflik data/tepat tenggat memuat status terbaru; kontrol tidak memberi kesan dapat mengabaikan keputusan server.

**UI-018 — Penarikan dan moderasi berbeda.** Tarik oleh petani menghentikan pesanan baru, membatalkan Menunggu yang belum kedaluwarsa, melepas reservasi sekali, tetapi Disetujui tetap. Status Ditarik tidak memiliki tombol Terbitkan Lagi; arahkan ke pembuatan tawaran baru tanpa menyalin/mengaktifkan pesanan lama. Admin hanya menandai dan meminta tindak lanjut. Pembeli melihat penanda/ringkasan nonpribadi, tawaran tetap dapat dipesan. Petani memilih “Sudah diperbaiki”; penanda tetap pada Menunggu Peninjauan hingga Admin menutup temuan. Tidak ada tombol Admin Sembunyikan, Batal Kontrak atau Koreksi Peran.

**UI-019 — Kontak dan penutupan akun.** Kontak lawan hanya terlihat bagi pihak berhak saat kontrak berstatus Disetujui; setelah Dibatalkan/Selesai disembunyikan termasuk bukti baru. Admin hanya nomor tersamar. Lokasi maksimal kecamatan beserta kabupaten/kota/provinsi. PT-10 menjelaskan bahwa permintaan penutupan menghentikan transaksi baru dari/ke akun, tetapi tidak membatalkan yang lama; pengguna tetap dapat menyelesaikan/mengakhiri sesuai izin. Setelah diproses, profil/kontak dihapus dan identitas riwayat dianonimkan sesuai kebijakan; jangan menampilkan “data sudah sepenuhnya terhapus” sebelum ada bukti pemrosesan. Data privat tidak boleh sekadar disembunyikan di CSS ketika masih dikirim ke pengguna yang tidak berhak.

**UI-020 — Prakiraan, SHAP dan peta transparan.** PB-04 menampilkan beras produsen, estimasi turunan GKP dan GKG, horizon 2/4, waktu terbit/target, metode/versi dan interval valid. Pilihan model/baseline per provinsi/horizon dapat berbeda, jadi label melekat pada hasil masing-masing. Teks “Prakiraan baseline” tetap terlihat. Faktor SHAP berasal dari model/versi terkait, tidak ditempel pada baseline lain atau disebut penyebab pasti. Penjelasan wilayah memerlukan model yang relevan dan tidak memalsukan bobot ketika belum tersedia. Ringkasan harga petani pengamatan, ekuivalen beras, estimasi wajar dan turunan prakiraan tidak ditukar label.

**UI-021 — Notifikasi dan CSV mengikuti hak akses.** PT-09 untuk petani/pembeli memuat kejadian, alasan pengakhiran, status dibaca dan tautan kontrak sendiri; notifikasi lama tidak membuka aksi usang. Kanal transaksi hanya aplikasi, berbeda dari pengiriman OTP. CSV harga publik dapat diakses publik. CSV pasokan PR-07 hanya untuk pembeli/Admin yang berhak dan berbentuk agregasi jenis/wilayah: jumlah tawaran unik, total tersedia, harga minta min/maks, satuan/waktu snapshot, tanpa baris atau identitas tiap tawaran. Petani tidak diberi menu ekspor pasokan orang lain.

**UI-022 — Keadaan aplikasi adalah bagian komponen.** Semua komponen mengikuti K0–K7 pada IA: normal, memuat, kosong, gagal, tanpa izin, data belum cukup/usang, konflik versi dan kebijakan teknis yang belum tersedia. Skeleton menandai area yang sedang dimuat tanpa angka 0; empty menyebut alasan dan aksi yang sah; error mempertahankan form. Pending action mencegah pengiriman tak sengaja berulang, tetapi kebenaran replay/konkurensi tetap tanggung jawab server. Kontrol read-only menjelaskan alasan; disabled bukan satu-satunya cara mengomunikasikan izin/status.

### 5.3 Microcopy untuk keadaan penting

Contoh berikut adalah pola pesan, bukan data atau status aktual. Isi dinamis mengikuti respons server dan hak akses.

| Keadaan | Pesan dan tindakan | Dasar / halaman |
|---|---|---|
| Presisi harga salah | “Masukkan harga per kg dalam rupiah bulat.” Pertahankan isian dan fokuskan field terkait. | UI-014; FR-004/007/009; PT-02/PR-03/PT-06 |
| Volume berubah | “Volume tersedia telah berubah. Periksa jumlah terbaru sebelum mengirim kembali.” Jangan mengirim ulang otomatis. | UI-017/022; FR-007; PR-03 |
| Daftar kosong | “Belum ada tawaran yang sesuai filter ini.” Tawarkan Reset Filter, tanpa mengarahkan petani ke katalog. | UI-022; FR-006; PR-02 |
| Gagal jaringan | “Pesanan belum dapat dipastikan terkirim. Periksa status terbaru sebelum mencoba lagi.” Pertahankan form; jangan menyatakan batal atau berhasil tanpa respons. | UI-013/022; FR-007; PR-03/PT-06 |
| Acuan tidak tersedia | “Acuan harga belum tersedia untuk jenis dan wilayah ini. Anda tetap dapat melanjutkan tanpa penilaian harga.” Tidak menampilkan lampu. | UI-016/022; FR-005/008; PT-02/PR-03 |
| Data usang | “Data terakhir berasal dari [periode sumber]. Angka ini belum mewakili harga terkini.” Tampilkan sumber/periode yang sebenarnya. | UI-020/022; FR-011/020; PB-02/AD-03 |
| Pembatalan | “Batalkan kontrak ini? Tindakan dicatat dan pihak lain menerima pemberitahuan.” Tampilkan dampak volume sesuai status dan field Alasan sebelum kirim. | UI-013/017; FR-024; PT-06 |
| Penutupan tertunda | “Penutupan menunggu transaksi aktif berakhir. Anda masih dapat menyelesaikan transaksi yang ada.” Jelaskan pembatasan transaksi baru dan tautkan Pesanan/Kontrak. | UI-019; FR-027; PT-10 |

### 5.4 Pemetaan primitive dan komponen domain

| Komponen | Konvensi berkas target | Aturan SAMBUNG / halaman |
|---|---|---|
| Button dan tautan bergaya tombol | `button.tsx` | `control-target`, teks 16 px, default≥ 44 px; aksi vs navigasi benar; semua halaman |
| Field/Input/Textarea/Select/Radio/Checkbox | berkas primitive terkait | Label/galat/satuan; harga/volume, mutu/tanggal; PT-02/PR-03/PT-06/AU-03 |
| InputOTP | `input-otp.tsx` atau input aksesibel setara | Panjang kode konfigurasi, autofill/paste, bukan 6 digit hardcode; AU-02 |
| Badge | `badge.tsx` | Status kontrak netral, penanda moderasi khusus; informatif tidak wajib 44 px |
| Alert | `alert.tsx` | Harga/peringatan menetap, baseline, penutupan tertunda; bukan banner dekoratif |
| Dialog | `dialog.tsx` | Form alasan tolak/batal, peninjauan sesuai izin; fokus terkelola |
| AlertDialog | `alert-dialog.tsx` | Konfirmasi penarikan/aksi tanpa input tambahan, dengan dampak nyata |
| Sheet/Sidebar | `sheet.tsx`, `sidebar.tsx` | Navigasi sesuai peran, label terlihat/aksesibel, tidak ada katalog petani |
| Table | `table.tsx` | Angka rata kanan/tabular, header dan satuan; mobile daftar atau area gulir lokal |
| Card/Separator | `card.tsx`, `separator.tsx` | Objek tawaran/form, bukan kartu di dalam kartu; divider tidak menjadi batas input |
| Chart | `chart.tsx` dan adapter data | Label/gaya garis/ringkasan, interval dan metode tepat; PB-04/PR-01 |
| Tabs/Popover/Tooltip | berkas terkait | Tidak menyembunyikan informasi wajib di hover; tab bukan peran akun |
| Skeleton/Empty/Spinner | berkas terkait | Memuat/kosong/proses tanpa statistik atau harga palsu |
| Toast/Sonner sesuai basis | adapter notifikasi sementara | Umpan balik singkat; bukan pengganti FieldError/Alert/PT-09 |
| Komponen domain | kontrak lokal belum menjadi berkas aplikasi | `FairPriceBlock`, `PriceCheckNotice`, `VolumeSummary`, `ContractStatus`, `ReviewNotice`, `ForecastSummary`; gabungan primitive dan data SRS |

## 6. Implementasi di `resources/css/app.css`

### 6.1 Sumber nilai dan integrasi

**UI-023 — Satu sumber token dan pemeriksaan yang dapat diulang.** [sambung-tokens.json](assets/sambung-tokens.json) adalah sumber nilai warna; [build_ui_tokens.py](../plan/build_ui_tokens.py) membangun [sambung-theme.css](assets/sambung-theme.css) dan [audit warna](ui-color-audit.md). Tabel bagian 2 adalah ringkasan, bukan salinan alternatif yang boleh berubah sendiri.

Kontrak CSS memuat `:root`/`.dark`, alias sidebar/kontrak, seluruh pemetaan `@theme inline`, tipografi, radius, ukuran kontrol, outline fokus, layout dasar dan reduced-motion. Contoh pola pemetaan:

```css
@import "tailwindcss";
@custom-variant dark (&:where(.dark, .dark *));

@theme inline {
  --color-primary: var(--primary);
  --color-primary-foreground: var(--primary-foreground);
  --color-price-low: var(--price-low);
  --color-price-low-surface: var(--price-low-surface);
}
```

Gunakan seluruh kontrak CSS canonical saat mengintegrasikan, lalu sesuaikan jalur dengan struktur aplikasi yang benar. Jangan mengimpor Tailwind dua kali atau menimpa global CSS yang sudah ada tanpa meninjau isinya. `@import "shadcn/tailwind.css"` atau stylesheet primitive lain mengikuti hasil generator/basis terpasang; guideline tidak menganggap satu import tersedia untuk semua versi. Jangan menyalin font/utility ganda dari contoh Jagains.

Font harus dimuat secara nyata. Rekomendasi integrasi self-host Latin variable normal, dengan `font-display: swap`, fallback sistem dan pemberitahuan OFL; hanya preload aset penting yang benar-benar dipakai. Contoh berikut **mengharuskan implementer menyediakan berkas yang sesuai**, bukan jalur yang sudah ada dalam workspace:

```css
@font-face {
  font-family: "Atkinson Hyperlegible Next";
  src: url("/fonts/atkinson-hyperlegible-next-latin-wght.woff2") format("woff2");
  font-style: normal;
  font-weight: 200 800;
  font-display: swap;
}
@font-face {
  font-family: "Plus Jakarta Sans";
  src: url("/fonts/plus-jakarta-sans-latin-wght.woff2") format("woff2");
  font-style: normal;
  font-weight: 200 800;
  font-display: swap;
}
```

### 6.2 Contoh varian tanpa mengasumsikan basis primitive

Pemetaan kelas ini merupakan kontrak gaya lokal; nama export/API primitive diperiksa saat implementasi. Tidak ada perhitungan harga bisnis di komponen presentasi.

```ts
export const priceNoticeClass = {
  within: "border-price-within bg-price-within-surface text-price-within",
  caution: "border-price-caution bg-price-caution-surface text-price-caution",
  low: "border-price-low bg-price-low-surface text-price-low",
  unavailable: "border-input bg-muted text-foreground",
} as const

export const contractBadgeClass =
  "border-input bg-contract-surface text-contract text-body-sm font-semibold"

export const reviewNoticeClass =
  "border-review bg-review-surface text-review text-body-base"
```

```tsx
// Ilustrasi pemakaian: data, izin dan hasil pemeriksaan berasal dari server.
<Button
  className="control-target h-auto rounded-lg px-5 py-2.5 text-body-medium font-semibold"
  disabled={pending}
>
  {pending ? "Mengirim pesanan…" : "Kirim pesanan"}
</Button>

// Navigasi memakai tautan; cocokkan signature buttonVariants pada basis terpasang.
<a
  className={`${buttonVariants({ variant: "outline" })} control-target h-auto px-4 py-2.5 text-body-medium font-semibold`}
  href={contractHref}
>
  Lihat kontrak
</a>
```

`contractHref` berasal dari route kontrak sendiri yang ditetapkan saat implementasi; ID halaman IA bukan URL aplikasi. Ukuran minimum diterapkan langsung pada anchor/trigger yang interaktif. Contoh tidak menyatakan handler, autentikasi atau API telah diimplementasikan.

### 6.3 Gerbang verifikasi implementasi

Sebelum digunakan pada aplikasi:

- Kompilasi CSS dengan Tailwind v4 dan versi shadcn yang dipasang; pastikan seluruh token/utility/varian terpakai benar.
- Periksa semua ukuran Button/Select/OTP/Checkbox/Switch/Nav; hitbox 44 px, label dapat membungkus, fokus solid dan offset tidak terpotong oleh overflow.
- Pastikan font benar-benar dimuat, lisensi terdistribusi, angka lining/tabular bekerja pada berkas sebenarnya, fallback/zoom tidak merusak tata letak.
- Uji halaman publik, PT-02/PT-06/PT-10, PR-02/03, AD-04/05 dalam kedua mode, keyboard dan zoom 200%; gunakan fixture lebar 360/768/1.024/1.280 px sebagai rancangan pengujian, bukan hasil yang sudah terjadi.
- Verifikasi sumber data/izin/status di server; contoh CSS tidak membuktikan privasi, replay, volume atau anonimisasi lulus.
- Ukur konten/tombol utama siap dipakai≤ 5 detik dengan profil perangkat/jaringan/data/cache/pengulangan yang terdokumentasi. Font, gambar dan grafik tidak boleh membuat klaim kinerja berdasarkan kerangka kosong.

## 7. Aturan Pantangan (UI Anti-Patterns)

**UI-024 — Larangan yang dapat diperiksa.**

1. Warna ad hoc atau palet mentah pada komponen (`bg-[#…]`, `text-green-600`); gunakan token. Nilai raw hanya pada manifest/kontrak tema dan audit.
2. Latar shell/card berwarna Warm Cream/Olive atau semua hover kuning; base kini netral Jagains. Warna aksen mentah sebagai teks kecil tanpa pasangan teruji juga dilarang.
3. Warna tanpa label/ikon, atau memakai hijau primary sebagai satu-satunya tanda harga wajar; penanda moderasi tidak boleh tampak sebagai lampu harga.
4. Input/teks isi di bawah 16 px, target sentuh di bawah 44 px, fokus redup/terpotong, informasi wajib hanya di tooltip, animasi yang menyembunyikan isi.
5. Toast untuk validasi field atau sebagai satu-satunya bukti kontrak berubah; konfirmasi pembatalan tanpa alasan ketika alasan diwajibkan SRS.
6. Tiga centang persetujuan, tujuh hari, dua putaran, GKP saja, fokus transaksi Jawa Timur, kelas peta A–D, atau ukuran 17 px/48 px sebagai kewajiban yang disalin dari draf lama. Baseline terbaru mengatasinya.
7. Memakai volume total sebagai tersedia, jumlah kontrak sebagai jumlah tawaran, atau melepas volume Selesai; antarmuka tidak boleh menghitung ulang sendiri dengan aturan berbeda dari server.
8. Menawarkan aksi Admin menyembunyikan/memblokir tawaran, mengubah kontrak, membuka nomor lengkap, atau mengoreksi peran. Menu tersembunyi bukan pengganti otorisasi.
9. Memberi akses katalog/CSV pasokan orang lain kepada petani, atau mengekspor pasokan per baris tawaran/identitas individual.
10. Mengaktifkan kembali pesanan batal ketika tawaran baru dibuat, menyediakan Terbitkan Lagi untuk Ditarik, atau menganggap permintaan tutup akun sama dengan menarik tawaran.
11. Menampilkan nomor lengkap pada kontrak Dibatalkan/Selesai atau hanya menyembunyikannya lewat CSS; menampilkan data pribadi lama setelah penutupan seolah anonimisasi sudah dilakukan.
12. Harga contoh tanpa label ilustrasi, observasi kosong sebagai 0, data usang diberi tanggal hitung baru seolah data terkini, grafik tanpa sumber/jenis/satuan/metode.
13. SHAP fiktif, penjelasan modelA sebagai alasan baselineB, estimasi gabah turunan disebut prediksi langsung, atau kata “penyebab pasti”.
14. Menyalin domain Jagains seperti tiket/SLA/kuorum/Auditor atau konten foto/slogan pada gambar palet ke SAMBUNG. Foto/testimoni/angka penggunaan yang tidak tersedia tidak dibuat sebagai fakta.

## 8. Ringkasan Perubahan dari Draf Sebelumnya

### 8.1 Dari draf SAMBUNG lama ke guideline ini

Versi lama pada tabel adalah [draf UI di docs/created](../created/SAMBUNG_UI_Guideline.md), bukan rilis resmi yang telah disetujui. Dokumen ini pertama kali disusun sebagai guideline baru berdasarkan 73 keputusan awal dan revisi visual DEC-021a; rincian desain fase 3 menunggu review.

| Area | Draf sebelumnya | Guideline fase 3 | Dasar |
|---|---|---|---|
| Format |16 bagian diagnosis/refactor |8 bagian utama sesuai contoh | DEC-011a |
| Identitas | Papan Harga Pasar; biru tinta | Layanan pertanian modern; palet pengguna, Forest Green primary | DEC-011b/c |
| Font | Atkinson + Source Serif 4 | Plus Jakarta Sans judul, Atkinson Hyperlegible Next isi | DEC-011d |
| Minimum |17 px/48 px |16 px/44 px | DEC-016a |
| Mode | Belum lengkap | Terang/gelap dengan token pasangan dan audit | DEC-011e |
| Warna status | Larangan hijau merek bertabrakan dengan penggunaan status | Brand, lampu, kontrak, moderasi dan bahaya berbeda token/bentuk/label | DEC-011c; UI-004 |
| Kontras | Angka draf lama untuk palet berbeda |106 pasangan diperiksa dari manifest baru; batas cakupan dinyatakan | UI-006 |
| Harga | Semua harga wajib ukuran besar; pemformatan manual di contoh | Harga sesuai hierarki, formatter bersama, L/U dibulatkan sebelum lampu | DEC-018a/b; UI-007/008 |
| Alur | Satu tawaran/satu kontrak, default 2 putaran/7 hari | Parsial, reservasi, tanpa batas putaran, awal 24 jam dinamis; lima tindakan utama | DEC-005a–k |
| Katalog/ekspor | Akses petani sempat diusulkan, CSV belum spesifik | Petani tidak membaca katalog; CSV pasokan agregasi nonpribadi | DEC-015a/b |
| Moderasi | Kewenangan belum rinci | Admin menandai/meminta, pembeli berpenanda, Admin menutup setelah tinjau | DEC-013c/f/g |
| Privasi | Kontak setelah setuju, keadaan akhir belum rinci | Kontak hanya saat Disetujui, Admin tersamar, penutupan tanpa transaksi baru dan anonimisasi | DEC-014a–g |
| API komponen | Menganggap basis/Toast tertentu berlaku | Verifikasi basis; Base UI Toast dan Radix Sonner dibedakan; tautan semantik | UI-012/013; sumber resmi |
| Klaim implementasi | Merujuk diagnosis kode yang tidak tersedia | Kontrak CSS dan checklist, tanpa menganggap revisi tema sudah diterapkan atau prototipe telah lolos audit | UI-023 |

### 8.2 Revisi v0.1 → v0.2 berdasarkan mockup

| Area | v0.1 | v0.2 / dasar DEC-021a |
|---|---|---|
| Base | Cream/permukaan hijau hangat | Token netral Jagains persis; canvas abu, kartu/topbar putih, sidebar netral; gelap padanannya |
| Primary | Forest terang, hijau muda gelap | Nilai primary kedua mode tetap; CTA navy pada gambar diganti primary SAMBUNG |
| Aksen | Palet hangat tersebar ke permukaan/grafik | Kuning/emas/olive/terracotta/cream hanya sorotan/status terbatas; hover global tetap netral |
| Grafik | Lima seri keluarga warna tanah | Primary hijau + seri netral, gaya garis/label, interval netral |
| Layout | Pola umum responsif | Shell topbar/sidebar, ringkasan dashboard, form + acuan, action bar, papan harga/peta mengikuti enam gambar |
| Isi gambar | Belum menjadi referensi | Pola visual diadopsi; angka/horizon/status/izin lama disesuaikan SRS/IA (§1.4) |
| Audit | 104 pasangan unik v0.1 | 106 pasangan unik v0.2, cakupan sidebar ditambahkan dan helper gray dibatasi permukaannya |

### 8.3 Ketertelusuran dan pemeriksaan dokumen

Semua UI-001…024 dipetakan ke FR/BR/NFR, halaman IA dan AC pada [matriks](traceability-matrix.md). Sumber angka token hanya manifest; perubahan palet membangun ulang CSS/audit dan memerlukan pemeriksaan teks/grafik/fokus pada konteks aktual. Perubahan aturan bisnis memperbarui SRS/IA lebih dahulu, bukan disembunyikan pada komponen.

### 8.4 Status review dan batas bukti

Dokumen, manifest/CSS serta audit warna merupakan keluaran fase 3 yang siap ditinjau bersama. Prototipe kini tersedia, tetapi penerapan tema revisi ini serta uji keyboard, zoom, font, responsif, otorisasi, kinerja 5 detik dan pipeline data/model belum diverifikasi dalam pekerjaan dokumentasi ini. Semua batas teknis SRS§7 tetap berlaku. Persetujuan desain tidak mengubah target menjadi hasil yang sudah tercapai.

Setelah pengguna menyetujui guideline, catat versi pasangan SRS/IA v0.2 dan UI Guidelines yang dipakai sebagai baseline paket. Revisi berikutnya harus menyebut alasan, sumber keputusan serta dampak pada matriks/audit, tanpa menimpa arsip proposal/draf awal.
