# SAMBUNG — Information Architecture

Versi 0.2 · 6 November 2026 · **Baseline fase 2 disetujui untuk fase 3**. Acuan perilaku: [SRS v0.2](SRS_SAMBUNG.md), keputusan [fase 1](phase-1-summary.md), [glosarium](GLOSSARY.md), dan [matriks ketertelusuran](traceability-matrix.md). Pengguna telah menyetujui pasangan SRS/IA v0.2 sebagai dasar fase ketiga melalui pilihan A. UI Guidelines belum disusun pada fase ini.

## 1. Prinsip struktur

1. Publik membaca informasi harga, peta, prakiraan dan bantuan. Katalog/detail tawaran serta CSV pasokan memerlukan login sebagai pembeli atau akses pemantauan Admin; petani tidak membaca tawaran petani lain. Pemesanan hanya untuk pembeli.
2. Satu akun biasa satu peran. Tiga ruang kerja: petani, pembeli dan Admin. Pendamping/Dinas tidak memiliki ruang kerja khusus.
3. Pisahkan **tawaran panen**, **pesanan/kontrak**, dan **tawaran harga**. Satu tawaran panen dapat memiliki beberapa kontrak parsial, masing-masing memiliki tenggat dan riwayat sendiri.
4. Detail kontrak adalah satu identitas halaman dan satu objek yang sama bagi kedua pihak; isi/aksi mengikuti peran, kepemilikan dan status pada SRS §3.3. Admin hanya memantau, tanpa aksi pihak kontrak dan tanpa nomor HP lengkap (DEC-014c).
5. Halaman harga/prakiraan publik dapat dibuka dari ruang kerja tanpa membuat salinan data. Profil/notifikasi dan daftar/detail kontrak menggunakan identitas kanonis bersama; alias lama dijelaskan di §8.
6. Navigasi memakai label konkret: Tawaran Saya untuk objek milik petani; Pesanan/Kontrak untuk transaksi; Ajukan Harga Lain untuk negosiasi. Kata “Produsen” pada data selalu dilengkapi “tingkat pasar”; ruang kerja memakai istilah Pembeli.
7. Tidak mewarisi janji semua fitur maksimal dua klik dari IA lama. Target yang disepakati adalah lima tindakan utama alur normal sampai Selesai, dengan pengecualian yang jelas (§5).
8. Informasi status, sumber, waktu dan ketidak tersediaan adalah bagian struktur konten, bukan dekorasi. Nilai kosong tidak diganti nol atau lampu hijau.

## 2. Peta situs kanonis

Node adalah identitas halaman, bukan URL implementasi. Diagram tidak bergantung pada PNG lama. Alias tidak menjadi halaman baru.

```mermaid
flowchart TD
    PB01["PB-01 Beranda publik"] --> PB02["PB-02 Papan Harga"]
    PB01 --> PB03["PB-03 Peta"]
    PB01 --> PB04["PB-04 Prakiraan dan Penjelasan"]
    PB01 --> PB05["PB-05 Bantuan, Privasi dan Syarat"]
    PB03 --> PB03a["PB-03a Tabel Provinsi"]
    PB03 --> PB03b["PB-03b Detail Provinsi"]
    PB03b --> PB02
    PB03b --> PB04
    PB01 --> AU01["AU-01 Masuk / Daftar"]
    AU01 --> AU02["AU-02 Verifikasi OTP"]
    AU02 --> AU03["AU-03 Peran dan Profil Akun Baru"]
    AU02 --> ROLE{"Peran akun terverifikasi"}
    AU03 --> ROLE
    ROLE --> PT01["PT-01 Beranda Petani"]
    ROLE --> PR01["PR-01 Dasbor Pembeli"]
    PT01 --> PT02["PT-02 Jual Hasil Panen"]
    PT01 --> PT03["PT-03 Tawaran Saya"]
    PT02 --> PT04["PT-04 Detail Tawaran Saya"]
    PT03 --> PT04
    PT01 --> PT05["PT-05 Pesanan / Kontrak"]
    PR01 --> PT05
    PT04 --> PT06["PT-06 Detail Kontrak Simulasi"]
    PT05 --> PT06
    PT06 --> PT06a["PT-06a Bukti Simulasi"]
    PR01 --> PR02["PR-02 Katalog Pasokan"]
    PR02 --> PR03["PR-03 Detail Pasokan"]
    PR03 -->|"Pembeli mengajukan pesanan"| PT06
    PT01 --> PT07["PT-07 Detail Harga Wajar"]
    PR01 --> PT07
    PB04 --> PT07
    PT01 --> PB04
    PR01 --> PB04
    PT01 --> PT09["PT-09 Notifikasi Bersama"]
    PR01 --> PT09
    PT09 --> PT06
    PT01 --> PT10["PT-10 Profil dan Pengaturan Bersama"]
    PR01 --> PT10
    PB01 --> AU04["AU-04 Masuk Admin"]
    AU04 --> AD01["AD-01 Ringkasan Admin"]
    AD01 --> AD02["AD-02 Parameter"]
    AD01 --> AD03["AD-03 Data Harga"]
    AD01 --> AD04["AD-04 Moderasi Tawaran"]
    AD01 --> AD05["AD-05 Pengguna"]
    AD01 --> AD06["AD-06 Log Audit"]
    AD01 --> AD07["AD-07 Model dan Evaluasi"]
    AD01 -->|"Pemantauan tanpa aksi kontrak"| PT06
```

PT-07 merupakan detail informasi yang juga dapat dibaca publik; prefix PT dipertahankan agar rujukan lama tidak putus. PT-05/06/06a/09/10 adalah halaman bersama yang memerlukan otorisasi objek. Tautan Admin menuju PT-06 tidak membuka nomor HP secara otomatis; DEC-014c membatasi nomor pada bentuk tersamar; kebijakan data lain masih mengikuti OPN-004.

## 3. Navigasi per ruang

| Ruang | Navigasi utama | Akses pendukung | Batas |
|---|---|---|---|
| Publik | Beranda PB-01; Papan Harga PB-02; Peta PB-03; Prakiraan PB-04 | Bantuan/privasi/syarat PB-05; masuk AU-01; masuk Admin AU-04; mode terang/gelap | Tidak ada daftar tawaran atau CSV pasokan publik |
| Petani | Beranda PT-01; Tawaran Saya PT-03; Kontrak PT-05 | Jual Panen PT-02; harga PT-07; PB-02/03/04; notifikasi PT-09; profil PT-10 | Tidak dapat mengajukan pesanan atau mengubah tawaran/kontrak pihak lain |
| Pembeli | Dasbor PR-01; Katalog PR-02; Pesanan/Kontrak PT-05 | Harga PT-07/PB-04; PB-02/03; CSV panel PR-07; notifikasi PT-09; profil PT-10 | Tidak membuat tawaran panen atas nama petani |
| Admin | Ringkasan AD-01; Parameter AD-02; Data Harga AD-03; Moderasi AD-04; Pengguna AD-05; Log AD-06; Evaluasi AD-07 | Informasi publik dan pemantauan kontrak PT-06; keluar | Tidak ada tombol menawar/setuju/batal/selesai; data sensitif tidak dibuka otomatis |

Target dasar DEC-016a: teks isi minimal 16 px, area sentuh minimal 44×44 px, dukungan keyboard dan zoom 200%; kontras teks normal minimal 4,5:1 dan fokus minimal 3:1 pada kedua mode. Ini target yang perlu diuji, bukan hasil implementasi.

Target halaman utama PB-01/PT-01/PR-01/AD-01 adalah konten/tombol utama siap digunakan maksimal 5 detik (DEC-016b); profil dan protokol uji harus dicatat sebelum menyatakan hasil.

Navigasi mobile mempertahankan label dan tujuan yang sama; bentuk sidebar, menu atau navigasi bawah dirinci pada fase 3. Satu aksi utama per konteks tidak berarti menghilangkan aksi lain yang sah. Tidak ada perpindahan peran akun lewat pilihan menu.

## 4. Inventaris halaman dan keadaan

### 4.1 Kontrak keadaan bersama

Semua baris inventaris mewarisi keadaan `K0`–`K7` yang relevan, selain catatan khusus pada baris:

| Kode | Keadaan | Perilaku konten dan aksi |
|---|---|---|
| K0 | Normal | Informasi, aksi dan tujuan sesuai baris; tidak membuka izin tambahan |
| K1 | Memuat | Tunjukkan pemuatan, hindari angka 0 atau kontrol transaksi yang terlihat sudah berhasil |
| K2 | Kosong | Nyatakan belum ada transaksi/data atau filter tidak cocok; tawarkan aksi yang berhak dilakukan |
| K3 | Gagal jaringan/layanan | Pesan jelas dan coba lagi; pertahankan isian; retry aksi tidak menggandakan objek |
| K4 | Tanpa sesi/tanpa izin/objek tidak tersedia | Minta login bila perlu; pengguna login yang tidak berhak tetap ditolak. Jangan bocorkan kontak/isi objek lewat judul, data atau ekspor |
| K5 | Data harga usang/tidak cukup | Tampilkan sumber/periode/umur yang sebenarnya atau “Acuan harga belum tersedia”; jangan memberi lampu/angka baru palsu. Kebijakan umur OPN-002 |
| K6 | Status/versi berubah | Muat ulang harga/volume/status dan jelaskan konflik; jangan menerima versi lama atau mengulang konfirmasi harga berbeda |
| K7 | Kebijakan belum diputuskan | Rancangan menandai OPN yang memblokir aksi; tidak memperlakukan usulan sebagai kewenangan yang sudah disetujui |

Prioritas W/T/D sama dengan SRS §2.1 dan semuanya target final; OPN bukan fitur inkubasi otomatis. Tidak semua keadaan memerlukan halaman terpisah: misalnya tanpa izin dapat menjadi tampilan terkontrol, dan ekspor adalah aksi/panel.

### 4.2 Publik dan autentikasi

| ID / tujuan | Aktor; prioritas | Kebutuhan / aturan | Konten wajib | Aksi → tujuan | Keadaan khusus / AC |
|---|---|---|---|---|---|
| PB-01 Beranda publik: pintu masuk produk | Semua; D | FR-002/005/011/012/015/030; BR-001/009/013 | Penjelasan simulasi, ringkasan harga berlabel/sumber/wilayah, akses informasi utama | Harga→PB-02; peta→PB-03; prakiraan→PB-04; bantuan→PB-05; masuk→AU-01; Admin→AU-04 | K1/3/5; harga ringkas kosong tidak menghalangi akses lain; AC-002/005/015/030 |
| PB-02 Papan Harga: rantai harga setara | Semua; W | FR-011/018/030; BR-016 | Filter komoditas/pasar/wilayah/periode; harga pengamatan petani/produsen/eceran, ekuivalen dan bagian petani bila valid; estimasi terpisah, sumber/umur | Ubah filter→PB-02; acuan→PT-07; prakiraan→PB-04; CSV harga→unduhan; bantuan→PB-05 | K2/3/5; beda frekuensi/komoditas tidak dipaksakan sebanding; AC-011/018 |
| PB-03 Peta: posisi harga provinsi | Semua; T | FR-012/029/030; BR-017/014 | Peta provinsi, selisih median bertanda, cakupan valid, ringkasan minimum/maksimum/disparitas, skala kontinu berpusat 0% dengan arah/nilai persentase | Tabel→PB-03a; sentuh provinsi→PB-03b; bantuan→PB-05 | K2/3/5; provinsi tanpa data berpenanda netral berbeda dari 0% valid; skala kontinu DEC-019a, sumber wilayah OPN-009; AC-012/029 |
| PB-03a Tabel Provinsi: alternatif peta | Semua; T | FR-012; BR-017 | Data dan filter sama dengan peta, arah lebih murah/mahal, sumber/periode/cakupan | Pilih provinsi→PB-03b; kembali peta→PB-03 | K2/3/5; tidak mengubah himpunan provinsi pembanding; AC-012 |
| PB-03b Detail Provinsi: konteks perbedaan wilayah | Semua; T | FR-012/029; BR-014/017 | Harga/selisih/periode; penjelasan model wilayah bila valid, label dan versi; bukan penyebab pasti | Rantai harga→PB-02 dengan konteks; prakiraan→PB-04; peta→PB-03 | K5; SHAP belum tersedia tidak diganti bobot fiktif; AC-012/029 |
| PB-04 Prakiraan dan Penjelasan: harga ke depan | Semua; T/W penjelasan | FR-015/016/030; BR-013/014/015 | Provinsi; horizon 2/4; harga beras dan estimasi GKP/GKG turunan; pita 80% sesuai bukti; metode/versi/waktu per provinsi/horizon; faktor model terkait; fallback berlabel sesuai unit | Filter→PB-04; detail acuan→PT-07; harga historis→PB-02; bantuan→PB-05 | K2/3/5; target gagal→baseline valid; penjelasan tidak cocok→tidak tersedia; AC-015/016 |
| PB-05 Bantuan, Privasi dan Syarat: memahami layanan | Semua; D | FR-002; BR-001/010/018/020 | Glosarium awam, simulasi, rentang/lampu, mutu, horizon, lima tindakan dan pengecualian; informasi kebijakan berversi | Kembali konteks; masuk→AU-01; tautan bagian bantuan/privasi/syarat dalam halaman | K7 pada isi kebijakan yang belum divalidasi; persetujuan pendaftaran mengikuti DEC-014g; AC-002 |
| AU-01 Masuk/Daftar: mulai verifikasi | Akun biasa belum login; D | FR-001; BR-018 | Nomor HP, informasi pemrosesan data, status layanan | Kirim kode→AU-02; bantuan/privasi→PB-05 | K3; nomor tidak valid/provider gagal tidak membuat akun terverifikasi; OPN-001; AC-001 |
| AU-02 Verifikasi OTP: buktikan akses nomor | Pemohon OTP; D | FR-001 | Isian kode, tujuan tersamar, batas waktu/kirim ulang sesuai konfigurasi yang disahkan | Valid akun lama→PT-01/PR-01; baru→AU-03; koreksi nomor→AU-01 | K3; salah/kedaluwarsa/rate-limit jelas tanpa sesi; AC-001 |
| AU-03 Peran dan Profil: lengkapi akun baru | Nomor terverifikasi, belum ada profil; D | FR-001/002/027; BR-018 | Pilih salah satu peran biasa, nama/wilayah/kelompok-usaha relevan, ketentuan/pemberitahuan dapat dibaca dan persetujuan eksplisit tidak tercentang otomatis | Selesai petani→PT-01; pembeli→PR-01; bantuan→PB-05 | K3/7; tidak ada pilihan Admin atau dua peran; tanpa persetujuan tidak membuat akun; versi/waktu persetujuan dicatat, isi kebijakan OPN-004; AC-001/002/027 |
| AU-04 Masuk Admin: sesi operasional | Admin yang disediakan pengelola; D | FR-028 | Email, sandi, pesan galat, pemulihan sesuai kebijakan teknis | Valid→AD-01; kembali→PB-01 | K3/4; tanpa daftar Admin publik; OPN-001; AC-028 |

### 4.3 Ruang kerja dan halaman bersama

| ID / tujuan | Aktor; prioritas | Kebutuhan / aturan | Konten wajib | Aksi → tujuan | Keadaan khusus / AC |
|---|---|---|---|---|---|
| PT-01 Beranda Petani: langkah berikutnya | Petani; D | FR-003/005/015/017; BR-003/009/013 | Acuan GKP/GKG, prakiraan 2/4, sumber/umur; ringkasan volume tawaran, pesanan dan kontrak sendiri | Jual→PT-02; tawaran→PT-03; kontrak→PT-05; acuan→PT-07; prakiraan→PB-04; PB-02/03; PT-09/10 | K2/3/5; kosong tawaran→ajak membuat, bukan statistik palsu; AC-003 |
| PT-02 Jual Hasil Panen: susun tawaran | Petani atas objek sendiri; D | FR-004/005/008; BR-002/009/010/011/012 | Jenis, volume maksimal dua desimal kg, harga rupiah bulat per kg, kecamatan, mutu/Belum diukur; tanggal ketersediaan opsional/Belum ditentukan; tinjauan; acuan dan lampu dekat harga; label simulasi | Simpan draf→PT-04; tinjau→keadaan tinjau PT-02; terbit→PT-04 | K3/5/6/7; merah konfirmasi; tanpa acuan tetap terbit; jenis/lokasi terkunci setelah pernah menerima pesanan (DEC-013d); tanggal opsional, tidak mengekspirasi tawaran; akun penutupan tertunda tidak dapat menerbitkan tawaran baru; AC-004/005/008 |
| PT-03 Tawaran Saya: lihat portofolio volume | Petani; D | FR-004/007/025; BR-003 | Daftar sendiri, status publikasi, total/tersedia/reservasi/disetujui/selesai dan filter | Baru→PT-02; pilih→PT-04 | K2/3/6; satu kontrak selesai tidak menandai seluruh tawaran selesai; AC-004/007/025 |
| PT-04 Detail Tawaran Saya: kelola pasokan sendiri | Petani pemilik; D | FR-004/007/024/025; BR-003/007/019 | Data panen, mutu, harga/lampu, rincian volume dan seluruh kontrak terkait | Pesanan terkait→PT-06; draf→PT-02; ubah harga/volume→PT-02 sesuai DEC-013a; tarik→status Ditarik sesuai DEC-013b; nyatakan Sudah diperbaiki→Menunggu Peninjauan temuan | K3/4/6/7; edit harga/volume hanya pesanan berikutnya, jenis/lokasi terkunci setelah pernah menerima pesanan; tarik membatalkan Menunggu dengan notifikasi dan pelepasan reservasi, Disetujui tetap; tawaran Ditarik tidak dapat dipesan atau diterbitkan kembali; sisa panen lewat tawaran baru PT-02; AC-004/007/024/025 |
| PT-05 Pesanan/Kontrak: daftar transaksi | Petani/pembeli, objek sendiri; D | FR-007/009/010/023/024/025/026; BR-005/007/008 | Daftar/filter status, jenis/volume/harga, tenggat Menunggu, pihak yang ditunggu, label simulasi | Pilih→PT-06; petani→PT-03; pembeli→PR-02 | K2/3/4/6; tidak menampilkan transaksi pihak lain; AC-007/010/023/024/025/026 |
| PT-06 Detail Kontrak Simulasi: kesepakatan bersama | Kedua pihak; Admin baca; W | FR-008/009/010/022/023/024/025/026/027; BR-005/006/007/008/011/012/018/019 | Identitas simulasi, jenis/volume, harga aktif/versi, pemeriksaan dan riwayat, tenggat, status, alasan, konfirmasi 0/1/2; kontak hanya izin sesuai status, Admin hanya nomor tersamar | Menunggu: harga balik/terima/tolak petani/batal pembeli→PT-06; Disetujui: konfirmasi selesai/batal salah satu→PT-06; bukti→PT-06a; asal tawaran→PT-04 atau PR-03 | K3/4/5/6/7; Admin tanpa aksi; terminal tanpa aksi bisnis; Dibatalkan/Selesai menyembunyikan kontak; Admin hanya nomor tersamar; AC-008/009/010/022/023/024/025/026/027 |
| PT-06a Bukti Simulasi: ringkasan dapat dicetak | Pihak kontrak; Admin baca operasional; W | FR-026/027; BR-001/018 | Ringkasan data/status/riwayat relevan, sumber pemeriksaan saat kesepakatan, SIMULASI, bukan bukti bayar/kirim nyata | Cetak; kembali→PT-06 | K4/7; kontak/identitas mengikuti kebijakan, tidak membuka lewat tautan cetak; AC-026/027 |
| PT-07 Detail Harga Wajar: jelaskan rumus | Publik/pengguna; W | FR-005/014; BR-009/010 | Jenis/wilayah/periode; Pberas/R/P10/P90 dan sumber/versi; L/U operasional dibulatkan sama dengan penilaian, nilai asal dapat ditelusuri; mutu belum dihitung; HPP bila sumber/periode sesuai | Prakiraan→PB-04; papan→PB-02; petani jual→PT-02; publik masuk→AU-01 | K2/3/5; parameter tidak ada dijelaskan, bukan angka ilustrasi; AC-005/014 |
| PT-09 Notifikasi: tindak lanjut kejadian | Petani/pembeli penerima; T | FR-017; BR-007/008/018 | Pesanan/harga/persetujuan/pengakhiran/konfirmasi, alasan, status dibaca dan waktu | Buka kejadian→PT-06; tandai dibaca→PT-09 | K2/3/4; notifikasi lama tidak memberi izin aksi usang; AC-017 |
| PT-10 Profil/Pengaturan: identitas dan preferensi | Akun biasa milik sendiri; D | FR-001/027/030; BR-018 | Nama/peran/wilayah, informasi kebijakan, pilih mode, keluar; permintaan tutup akun dan status menunggu transaksi aktif serta pembatasan transaksi baru; penutupan memproses penghapusan profil/kontak dan anonimisasi riwayat; koreksi peran di luar MVP; rincian penghapusan/auth OPN-004/001 | Minta penutupan akun→PT-10 status tercatat; transaksi aktif→PT-05/06; keluar→PB-01; bantuan→PB-05; ubah mode→tetap | K3/4/7; tidak ada tukar/koreksi peran oleh pengguna/Admin; perubahan nomor bukan fitur wajib yang sudah ditetapkan; AC-001/027/030 |
| PR-01 Dasbor Pembeli: cari pasokan dan pantau | Pembeli; T | FR-013/005/015/017 | Ringkasan pasokan deklaratif/tersedia, rentang GKP/GKG, prakiraan 2/4, transaksi sendiri | Cari→PR-02; kontrak→PT-05; acuan→PT-07; prakiraan→PB-04; PB-02/03; CSV→PR-07; PT-09/10 | K2/3/5; pasokan bukan stok terverifikasi; AC-013 |
| PR-02 Katalog Pasokan: temukan tawaran | Pembeli; Admin pemantau; D | FR-006/018; BR-002/003/018 | Filter jenis/wilayah/volume, harga/lampu/ketidak tersediaan, mutu dan volume tersedia vs total; penanda Sedang diminta perbaikan/ringkasan tanpa data pribadi jika relevan | Detail→PR-03; ekspor→PR-07; reset filter→PR-02 | K2/3/4/5/6; tersedia 0 tidak dapat dipesan; petani tanpa akses katalog; tawaran sendiri melalui PT-03/04; AC-006/018 |
| PR-03 Detail Pasokan: pilih volume/harga | Pembeli; Admin baca; D | FR-006/007/008/014; BR-004/009/010/011/012/018 | Jenis/mutu/lokasi, tanggal ketersediaan/Belum ditentukan, volume, harga minta/pengajuan rupiah bulat per kg, volume pesanan maksimal dua desimal, acuan/lampu, makna pengajuan sebagai persetujuan; penanda/ringkasan masalah tanpa data pribadi jika relevan | Pesan harga ini/ajukan harga lain→PT-06 setelah berhasil; kembali→PR-02; acuan→PT-07 | K3/4/5/6; tanpa izin pembeli tidak ada aksi; merah konfirmasi; gagal stok atau status penutupan tertunda pada pembeli/pemilik tidak membuat reservasi; AC-006/007/008/014 |
| PR-07 Ekspor pasokan (panel, bukan halaman baru) | Pembeli; Admin sesuai akses; D | FR-018; BR-018 | Ringkasan per jenis/wilayah: jumlah tawaran unik, volume tersedia, harga minta minimum/maksimum; satuan/waktu snapshot; tanpa identitas/baris individual | Unduh CSV; tutup→PR-02/PR-01 konteks asal | K2/3/4/7; kolom agregasi DEC-015b; publik/petani ditolak, hanya pembeli/Admin sesuai hak; AC-018 |

### 4.4 Admin

| ID / tujuan | Aktor; prioritas | Kebutuhan / aturan | Konten wajib | Aksi → tujuan | Keadaan khusus / AC |
|---|---|---|---|---|---|
| AD-01 Ringkasan: pantau operasional | Admin; D | FR-028/020/022/026/031; BR-019 | Status impor/model, jumlah tawaran/kontrak menurut status, isu validasi; data operasional tersamar bila sensitif | AD-02/03/04/05/06/07; pantau kontrak→PT-06; keluar→PB-01 | K2/3/4/7; tidak ada aksi atas nama pihak; AC-021/026/028 |
| AD-02 Parameter: konfigurasi berversi | Admin; D | FR-019/022; BR-005/009/011/012/019 | Durasi,δ,rendemen per jenis/versi/sumber, HPP bertanggal bila dipakai; dampak perubahan | Simpan valid→AD-02; riwayat→AD-06; bukti parameter→AD-03/07 | K3/4/7; parameter tak terbukti tidak otomatis terbit; AC-019/022 |
| AD-03 Data Harga: impor dan kualitas | Admin; W | FR-020/022; BR-009/016/017/019 | Sumber/snapshot/izin, periode/satuan/cakupan, valid/ditolak/duplikat/anomali dan hasil impor | Impor dan validasi→AD-03; detail kualitas→AD-03; audit→AD-06 | K2/3/4/7; gagal tidak menghapus snapshot valid; AC-020/022 |
| AD-04 Moderasi Tawaran: tindak lanjut masalah | Admin; D | FR-021/022; BR-019 | Tawaran/status, masalah yang ditandai, permintaan perbaikan/penarikan, ringkasan masalah yang boleh dilihat pembeli, catatan internal terpisah dan riwayat | Tinjau detail→PR-03 mode baca; tandai/minta petani menindaklanjuti→AD-04 dengan notifikasi petani; tinjau perbaikan/tutup temuan→AD-04, riwayat tetap; audit→AD-06 | K2/3/4; tanpa tombol sembunyikan/hentikan pesanan/batalkan kontrak; penanda tetap saat Menunggu Peninjauan, hilang hanya untuk temuan yang ditutup Admin; tawaran tetap terlihat dan dapat dipesan sesuai volume; AC-021/022 |
| AD-05 Pengguna: operasi akun | Admin; D | FR-021/027/028; BR-018/019 | Peran/status/data operasional minimal, kebijakan aksi; nomor HP tersamar tanpa aksi buka lengkap | Tinjau akun→AD-05; tindakan sesuai OPN-003/004/010; audit→AD-06 | K3/4/7; penutupan mengikuti DEC-014d/e/f; tanpa aksi koreksi peran; reset/pembekuan belum ditetapkan sebagai fitur MVP; AC-021/027/028 |
| AD-06 Log Audit: telusuri peristiwa | Admin; D | FR-022; BR-019 | Filter objek/pelaku/waktu/aksi, perubahan/versi/alasan, tanpa OTP/sandi | Objek kontrak→PT-06 mode baca; parameter→AD-02; data→AD-03; evaluasi→AD-07 | K2/3/4; log bukan tombol melakukan ulang aksi bisnis; AC-022 |
| AD-07 Model dan Evaluasi: bukti publikasi | Admin/timdata melalui akses Admin; D | FR-031/015/016/029; BR-013/014/015/019 | Model/dataset/cutoff/horizon/target, metrik per wilayah/horizon dan metode publikasi tiap unit, interval, SHAP, alasan fallback/kelayakan dan versi publikasi | Validasi/publikasi sesuai bukti→AD-07; sumber→AD-03; audit→AD-06 | K2/3/4/7; simulasi dikecualikan, gagal target tidak hilang dari laporan; OPN-007; AC-015/016/029/031/033/034 |

## 5. Alur tugas dan skenario alternatif

### 5.1 Lima tindakan utama alur normal

Prasyarat: kedua akun telah login; tawaran sudah terbit dengan volume cukup; tidak ada tawaran balik; harga dapat diterima dan konfirmasi merah dilakukan bila relevan. Jumlah klik/validasi di dalam tindakan dicatat terpisah, bukan disembunyikan sebagai lima klik.

| Tindakan utama | Pelaku | Halaman | Hasil |
|---|---|---|---|
| 1. Pilih tawaran dari katalog | Pembeli | PR-02→PR-03 | Detail pasokan terbuka |
| 2. Kirim pesanan | Pembeli | PR-03→PT-06 | Menunggu, volume dicadangkan, tenggat tersimpan, pengaju setuju harga |
| 3. Terima harga aktif | Petani | PT-06 (dari PT-04/05/09) | Disetujui, kedua pihak sepakat tanpa setuju ulang |
| 4. Konfirmasi selesai pertama | Petani atau pembeli | PT-06 | Tetap Disetujui,1/2 konfirmasi |
| 5. Konfirmasi selesai kedua | Pihak lainnya | PT-06 | Selesai, volume tidak dilepas |

SRS BR-020/AC-032 merupakan definisi penerimaan. Login, perjalanan ke notifikasi, navigasi, negosiasi tambahan dan membuat tawaran bukan bagian lima tindakan tersebut. Bukti PT-06a adalah hasil yang dapat dibuka/dicetak; membukanya bukan syarat status Selesai.

```mermaid
sequenceDiagram
    participant B as Pembeli
    participant S as SAMBUNG
    participant P as Petani
    B->>S: 1 Pilih tawaran
    B->>S: 2 Kirim volume dan harga
    S-->>B: Menunggu, reservasi dan tenggat
    S-->>P: Notifikasi pesanan
    P->>S: 3 Terima harga aktif
    S-->>B: Disetujui dan pemeriksaan tersimpan
    P->>S: 4 Konfirmasi selesai
    S-->>B: Menunggu konfirmasi pihak kedua
    B->>S: 5 Konfirmasi selesai
    S-->>P: Selesai, tetap simulasi
    S-->>B: Selesai, tetap simulasi
```

### 5.2 Alur alternatif yang harus tampak di struktur halaman

| Kondisi | Jalur/keadaan | Hasil bisnis acuan |
|---|---|---|
| Pembelian parsial | PR-03:1.000 kg tersedia, pesan 400 → PT-06; PR-02/03 menampilkan 600 tersedia | BR-003/004; banyak kontrak untuk satu tawaran |
| Dua pembeli berebut volume | Salah satu pengajuan gagal K6 pada PR-03 dengan volume terbaru | Tidak oversell; retry tidak ganda |
| Negosiasi | PT-06 menampilkan harga aktif/pengaju/riwayat; pihak lain menerima versi terakhir | BR-006; tidak reset tenggat, tidak batas 2 putaran |
| Tenggat habis | PT-06 Menunggu→Kedaluwarsa, PT-09 kejadian; katalog volume diperbarui | BR-005; job terlambat tidak memberi hak terima |
| Tolak/batal Menunggu | PT-06 form alasan sesuai peran→status akhir; PT-09 pihak lawan | BR-007; volume dilepas sekali |
| Petani menarik tawaran | PT-04 memperlihatkan dampak penarikan→Ditarik; pesanan Menunggu yang belum kedaluwarsa→Dibatalkan; PT-09 pembeli | BR-005/007; reservasi dilepas sekali, kontrak Disetujui tetap berjalan, tawaran tidak dapat dipesan |
| Batal Disetujui termasuk 1/2 selesai | PT-06 alasan wajib, kedua peran boleh; pihak lain diberi notifikasi | Tidak perlu izin Admin/persetujuan lawan; tidak mungkin jika sudah Selesai |
| Acuan/model tidak tersedia | PT-02/PR-03/PT-06 atau PB-04 menampilkan K5 | Terbit/pesan tetap boleh tanpa lampu bila acuan hilang; prakiraan tak dikarang |
| Harga merah | PT-02/PR-03/PT-06: alasan dan konfirmasi sebelum aksi | Konfirmasi relevan untuk harga yang diproses, bukan pengesahan umum |
| Admin mengubah durasi/δ | AD-02 penjelasan dampak dan riwayat; PT-06 tenggat lama tetap | Durasi baru hanya pesanan baru;δbaru pemeriksaan berikutnya; snapshot kontrak Disetujui tetap |
| Kontak belum boleh dibuka | PT-06 menampilkan keterangan sampai Disetujui; PR-02/03 tanpa nomor | Tidak ada nomor tersembunyi di respons/CSV; Dibatalkan/Selesai menyembunyikan kembali nomor |
| Moderasi informasi tawaran | AD-04 menandai→PT-09/PT-04 petani; PR-02/03 pembeli berpenanda; petani menyatakan perbaikan→Admin meninjau/menutup | DEC-013c/f/g; tidak menyembunyikan atau memblokir pesanan, riwayat tetap dan bukan verifikasi mutu fisik |
| Penutupan akun tertunda | PT-10 permintaan tercatat→PT-05/06 untuk transaksi lama; PT-02/PR-03 menolak transaksi baru dari/ke akun terkait | DEC-014d/e; tidak sama dengan menarik tawaran, tidak otomatis membatalkan Menunggu atau Disetujui |
| Penutupan akun diproses | Setelah semua transaksi terminal, proses penutupan/penghapusan; riwayat nonpribadi tetap dengan identitas dianonimkan | DEC-014f; verifikasi salinan/provider/cadangan dan bukti persetujuan, bukan klaim anonimisasi sudah lulus |

Mesin status lengkap hanya di [SRS §3.3](SRS_SAMBUNG.md#33-mesin-status-kontrak); IA tidak memiliki mesin status tandingan. Tampilan halaman mewarisi transisi itu.

## 6. Pemetaan sumber data dan modul ke halaman

| Sumber/modul | Keluaran | Halaman penerima | Batas |
|---|---|---|---|
| Observasi PIHPS/BPS/sumber tervalidasi | Harga menurut pasar/jenis/wilayah/periode | PB-01/02/03/03a/03b; AD-03 | Tidak menyebut estimasi/simulasi sebagai observasi |
| Estimator rumus GKP/GKG | L/U dan komponen/versi/ketidak tersediaan | PB-01; PT-01/02/04/07; PR-01/02/03; PT-06 snapshot; AD-02/07 | Rjenis/kalibrasi sesuai OPN-002; bukan SHAP |
| Pemeriksa harga | Lampu/alasan/konfirmasi/snapshot | PT-02/04, PR-02/03, PT-06; AD-06 riwayat | Tidak tersedia terpisah; merah tidakblok permanen |
| Prakiraan beras/baseline dan konversi gabah | Horizon 2/4, interval berbukti, metode, hasil turunan | PB-04, PT-01, PR-01; AD-07 | Fallback berlabel dan evaluasi turunan terpisah |
| SHAP prakiraan | Kontribusi model/horizon/versi | PB-04; ringkasan PT-01/PR-01 boleh menautkan; AD-07 | Jangan tampilkan model A sebagai alasan baseline B |
| SHAP perbedaan wilayah | Penjelasan model sebanding dan keterbatasan | PB-03b, tautan PB-03; AD-07 | Tidak menggantinya dengan teks statis sebagai klaim pemenuhan SHAP |
| Data tawaran/reservasi/kontrak simulasi | Volume/status/harga riwayat | PT-03/04/05/06/06a, PR-01/02/03, AD-01/06 | Bukan data latih/observasi dan bukan stok terverifikasi |
| Parameter/versioning/audit | Durasi,δ,R/HPP bersumber, log | AD-02/03/06/07; snapshot di detail relevan | Otoritas Admin tidak mengubah kontrak atas nama pihak |

## 7. Izin dan aksi pada halaman

| Kelompok halaman | Publik | Petani | Pembeli | Admin |
|---|---|---|---|---|
| PB-01/02/03/03a/03b/04/05, PT-07 | Baca | Baca | Baca | Baca |
| AU-01/02/03 | Alur akun biasa | Akun kembali melalui OTP | Sama | Bukan pembuatan Admin |
| AU-04 dan AD-01…07 | Tidak | Tidak | Tidak | Akses operasional |
| PT-01/02/03/04 | Tidak | Milik sendiri | Tidak | Pemantauan melalui AD, bukan impersonasi |
| PR-01 | Tidak | Tidak | Milik sendiri | Ringkasan operasional melalui AD |
| PR-02/03/07 | Tidak | Tidak; hanya tawaran sendiri melalui PT-03/04 | Baca/pesan/ekspor sesuaihak | Baca/ekspor operasional; tidak memesan |
| PT-05/06/06a | Tidak | Hanya kontrak sendiri | Hanya kontrak sendiri | Pemantauan; tanpa aksi pihak dan hanya nomor tersamar |
| PT-09/10 | Tidak | Milik sendiri | Milik sendiri | Tidak menyamar; pengelolaan melalui AD-05 |

Kontak hanya pada kontrak yang saat itu Disetujui; Dibatalkan/Selesai menyembunyikannya kembali sesuai DEC-014a/b. Kebijakan data sensitif lain dan pengelolaan akun OPN-003/004 tetap terbuka. Halaman kebijakan yang belum diputuskan diberi penanda review, bukan janji bahwa semua aksi tersebut sudah boleh diterapkan.

## 8. Migrasi ID dan perubahan dari IA lama

| ID lama | Identitas baru/kanonis | Perlakuan |
|---|---|---|
| PB-01…05, AU-01…04, PT-01…07, PT-09/10, PR-01/02/03/07, AD-01…07 | Dipertahankan | Isi/aksi diperbaiki sesuai keputusan; PR-07 panel, PT-07 publik, PT-05/06/06a/09/10 bersama |
| PT-08 Prakiraan | PB-04 | Alias peran petani, bukan salinan model/halaman |
| PR-04 Penawaran Saya | PT-05 dengan tampilan pesanan pembeli | Alias/filter dari daftar transaksi bersama; tidak menamai pesanan sebagai tawaran panen |
| PR-05 Kontrak daftar/detail | PT-05 / PT-06 / PT-06a | Alias menuju identitas kanonis, aksi sesuai pembeli |
| PR-06 Harga Beli Wajar dan Prakiraan | PT-07 untuk acuan; PB-04 untuk prakiraan | Tautan, bukan halaman duplikat |
| PR-08 Notifikasi/Profil | PT-09 / PT-10 | Dua tujuan eksplisit, bukan satu ID yang mengaburkan halaman |
| AD-08 Validasi Transaksi Nyata | Tidak ada halaman final | Inkubasi; validasi dataset/model final tetap AD-03/07 tanpa data simulasi latih |
| PD-01… / DN-01… | Tidak ada ruang kerja final | Pendamping/Dinas mengakses layanan publik; tidak ada fungsi delegasi petani |

Perubahan inti: GKP/GKG; transaksi nasional; pembelian parsial dan volume tersendiri; durasi 24 jam dinamis; negosiasi tanpa batas; persetujuan harga aktif; selesai dua pihak; SHAP wilayah tetap target; katalog login; mode gelap; CSV pasokan tanpa data pribadi. Diagram, inventaris dan izin di atas tidak memakai default lama satu listing satu kontrak, tujuh hari atau dua putaran.

## 9. Batas penyelesaian fase 2

SRS dan IA v0.2 adalah pasangan baseline yang telah disetujui pengguna. Semua FR memiliki tujuan halaman atau proses yang ditampilkan, dan proses latar diwakili status/riwayat tanpa dibuat layar transaksi palsu. [Matriks](traceability-matrix.md) mencatat DEC→FR/BR→halaman→AC dan NFR.

Rincian belum diputuskan tercatat sebagai OPN-001…010 pada SRS. Keputusan edit/penarikan/moderasi, kontak, penutupan, katalog/CSV, ukuran/kinerja, presisi dan skala peta yang telah dipilih tetap mengikat. Sisa OPN hanya pada rancangan/bukti teknis yang dicatat, misalnya kalibrasi, autentikasi, anonimisasi dan geometri/warna peta; jangan membukanya kembali sebagai preferensi yang belum dijawab. Detail token, spacing, komponen, kontras dan bentuk navigasi responsif merupakan fase 3. Tidak ada gambar UI atau hasil uji implementasi yang diklaim di IA ini.
