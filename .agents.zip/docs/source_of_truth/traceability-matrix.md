# SAMBUNG — Matriks Ketertelusuran

Versi 0.4 · 6 November 2026 · SRS/IA v0.2 tetap baseline yang disetujui; [UI Guidelines v0.2](UI_GUIDELINES_SAMBUNG.md) adalah draf fase 3 untuk review. Acuan: [SRS](SRS_SAMBUNG.md), [IA](IA_SAMBUNG.md), [catatan keputusan](decision-log.md), [audit](verification-report.md). AC adalah skenario yang direncanakan, bukan hasil uji.

## 1. Sumber dan keputusan → kebutuhan → halaman → penerimaan

Sumber proposal P berarti [proposal.txt](../proposal/proposal.txt) dengan bagian yang disebut. Semua keputusan di bawah telah dijawab; status rincian/ketergantungan masih mengikuti OPN pada SRS. Rentang ID hanya untuk kelompok yang jelas; alias halaman mengikuti IA §8.

| Keputusan | Masalah/sumber | FR dan BR | Halaman IA | AC / NFR | UI fase 3 |
|---|---|---|---|---|---|
| DEC-001 | Target final P §4.3/A.2 | FR-001…031 sesuai lingkup §2 | Semua inventaris final | AC-001…036 | UI-002, UI-015, UI-019, UI-022 |
| DEC-002 | Seluruh wajib/tinggi P A.9; AUD-001/023 | FR-003/005/007/008/011/012/013/015/016/017/029/031 | PT-01/06/07; PB-02/03/04; PR-01; AD-03/07 | AC-003/005/007/008/011/012/013/015/016/017/029/031 | UI-001, UI-002, UI-010, UI-016, UI-020, UI-022 |
| DEC-003 | Ruang kerja P §4.1; AUD-002 | FR-001/003/013/028; BR-019 | PT-01; PR-01; AD-01; PB-01…05 | AC-001/003/013/028 | UI-002, UI-015, UI-019, UI-022 |
| DEC-004 | Simulasi P A.9; AUD-005/012 | FR-007/026/031; BR-001 | PT-06/06a; AD-03/07 | AC-007/026/031; NFR-007 | UI-002, UI-014, UI-016, UI-017, UI-019, UI-022 |
| DEC-005a | Parsial mengganti Q-10; AUD-003 | FR-004/006/007/025; BR-003/004 | PT-03/04; PR-02/03; PT-06 | AC-004/006/007/025; NFR-001 | UI-002, UI-008, UI-014, UI-016, UI-017, UI-018, UI-019 |
| DEC-005b | Reservasi saat pengajuan | FR-007/023/024; BR-003/004 | PR-03; PT-04/06 | AC-007/023/024; NFR-001 | UI-002, UI-014, UI-016, UI-017, UI-019, UI-022 |
| DEC-005c | Tenggat 24 jam dinamis | FR-019/023; BR-005 | AD-02; PT-06 | AC-019/023 | UI-002, UI-008, UI-014, UI-016, UI-017, UI-022 |
| DEC-005d | Hanya pesanan baru | FR-019/023; BR-005 | AD-02; PT-06 | AC-019/023 | UI-002, UI-008, UI-014, UI-016, UI-017, UI-022 |
| DEC-005e | Harga awal/negosiasi | FR-007/009; BR-006 | PR-03; PT-06 | AC-007/009 | UI-002, UI-014, UI-016, UI-017, UI-019, UI-022 |
| DEC-005f | Tanpa batas putaran | FR-009/023; BR-005/006 | PT-06 | AC-009/023 | UI-002, UI-013, UI-014, UI-017, UI-022 |
| DEC-005g | Terima harga aktif | FR-008/009/010; BR-006/012 | PR-03; PT-06 | AC-008/009/010 | UI-002, UI-004, UI-008, UI-016, UI-022 |
| DEC-005h | Selesai dua pihak | FR-025/026; BR-008 | PT-05/06/06a | AC-025/026 | UI-002, UI-013, UI-017, UI-019, UI-022 |
| DEC-005i | Batal Disetujui sepihak | FR-024/017/022; BR-007/008 | PT-06/09; AD-06 | AC-024/017/022 | UI-002, UI-013, UI-014, UI-017, UI-018, UI-021, UI-022 |
| DEC-005j | Alasan tolak/batal Menunggu | FR-024/017/022; BR-007 | PT-06/09; AD-06 | AC-024/017/022 | UI-002, UI-013, UI-014, UI-017, UI-018, UI-021, UI-022 |
| DEC-005k | Definisi ≤ 5 tindakan; AUD-019 | FR-006/007/010/025; BR-020 | PR-02/03; PT-06 | AC-032; NFR-004 | UI-001, UI-002, UI-010, UI-014, UI-016, UI-018, UI-019 |
| DEC-007a | GKP dan GKG; AUD-007 | FR-004/005/006/011/014; BR-002/009 | PT-02/07; PR-02/03; PB-02 | AC-004/005/006/011/014 | UI-002, UI-008, UI-014, UI-016, UI-017, UI-018, UI-019 |
| DEC-007b | Rumus produsen vs eceran | FR-005/014; BR-009 | PT-07; AD-02/07 | AC-005/014 | UI-002, UI-008, UI-016, UI-022 |
| DEC-007c | Mutu tanpa koreksi | FR-004/005/014; BR-010 | PT-02/04/07; PR-03 | AC-004/005/014 | UI-002, UI-008, UI-014, UI-016, UI-017, UI-018, UI-019 |
| DEC-007d | Belum diukur | FR-004/006; BR-002/010 | PT-02/04; PR-02/03 | AC-004/006 | UI-002, UI-008, UI-014, UI-016, UI-017, UI-018, UI-019 |
| DEC-007e | Terbit tanpa acuan | FR-004/005/008/014; BR-009/011 | PT-02/07/06; PR-03 | AC-004/005/008/014 | UI-002, UI-008, UI-014, UI-016, UI-017, UI-018, UI-019 |
| DEC-006a | Merah bukan blokir | FR-004/008/010; BR-012 | PT-02/06; PR-03 | AC-004/008/010 | UI-002, UI-008, UI-014, UI-016, UI-017, UI-018, UI-019 |
| DEC-006b | Atas rentang kuning | FR-008; BR-011 | PT-02/04/06; PR-02/03 | AC-008 | UI-002, UI-004, UI-008, UI-016, UI-022 |
| DEC-006c | Toleransi 3% dinamis | FR-008/019; BR-011 | PT-06; AD-02 | AC-008/019 | UI-002, UI-004, UI-008, UI-016, UI-022 |
| DEC-006d | Snapshot hasil lama | FR-008/019/022; BR-012/019 | PT-06; AD-02/06 | AC-008/019/022; NFR-010 | UI-002, UI-004, UI-008, UI-016, UI-022 |
| DEC-008a | Horizon 2/4; AUD-008 | FR-015/016/031; BR-013 | PB-04; AD-07 | AC-015/016/031/033 | UI-002, UI-005, UI-008, UI-020, UI-022 |
| DEC-008b | Gabah turunan | FR-015/014; BR-009/013 | PB-04; PT-07 | AC-015/014/033 | UI-002, UI-005, UI-008, UI-020, UI-022 |
| DEC-008c | SHAP prakiraan/wilayah | FR-016/029/031; BR-014 | PB-04/03b; AD-07 | AC-016/029/031 | UI-002, UI-005, UI-020, UI-022 |
| DEC-008d | Fallback baseline | FR-015/016/031; BR-015 | PB-04; AD-07 | AC-015/016/031/033 | UI-002, UI-005, UI-008, UI-020, UI-022 |
| DEC-009a | Harga pengamatan; AUD-010 | FR-011/020; BR-016 | PB-02; AD-03 | AC-011/020 | UI-002, UI-005, UI-008, UI-020, UI-022 |
| DEC-009b | Median signed vs disparitas | FR-012/029; BR-017 | PB-03/03a/03b | AC-012/029 | UI-002, UI-005, UI-008, UI-020, UI-022 |
| DEC-009c | Transaksi seluruh provinsi | FR-004/006/007/012; BR-002/004 | PT-02; PR-02/03; PB-03 | AC-004/006/007/012 | UI-002, UI-008, UI-014, UI-016, UI-017, UI-018, UI-019 |
| DEC-010a | OTP petani/pembeli | FR-001; BR-018 | AU-01/02/03 | AC-001; NFR-002 | UI-002, UI-015, UI-019, UI-022 |
| DEC-010b | Kontak setelah Disetujui | FR-027/026; BR-018 | PT-06/06a/10 | AC-027/026 | UI-002, UI-015, UI-019, UI-022 |
| DEC-010c | Notifikasi aplikasi dua peran | FR-017; BR-007/008 | PT-09/06 | AC-017 | UI-002, UI-013, UI-021, UI-022 |
| DEC-003a | Admin bukan pelaku kontrak | FR-021/022/028; BR-019 | AD-01…07; PT-06 mode baca | AC-021/022/028 | UI-002, UI-015, UI-018, UI-019, UI-022 |
| DEC-002a | Gratis; AUD-016 | FR-007/013/028; BR-001 | PR-01/03; PT-06; AD-01 | AC-007/013/028 | UI-002, UI-014, UI-016, UI-017, UI-019, UI-022 |
| DEC-011a | Format sama, arah baru | FR-030; batas UI §2 | Semua shell | AC-030/035 | UI-001, UI-002, UI-003, UI-004, UI-006, UI-007, UI-009, UI-010, UI-011, UI-012, UI-013, UI-023, UI-024 |
| DEC-011b | Palet gambar/modern | FR-030; batas UI §2 | Semua shell | AC-030/035 | UI-001, UI-002, UI-003, UI-004, UI-006, UI-007, UI-009, UI-010, UI-011, UI-012, UI-013, UI-023, UI-024 |
| DEC-011c | Forest Green utama | FR-030; BR-011/012 (batas semantik) | Semua shell/status | AC-030/035 | UI-001, UI-002, UI-003, UI-004, UI-006, UI-007, UI-009, UI-010, UI-011, UI-012, UI-013, UI-023, UI-024 |
| DEC-011d | Plus Jakarta/Atkinson | FR-030 | Semua halaman | AC-030/035 | UI-001, UI-002, UI-003, UI-004, UI-006, UI-007, UI-009, UI-010, UI-011, UI-012, UI-013, UI-023, UI-024 |
| DEC-011e | Terang/gelap | FR-030 | Semua shell | AC-030/035 | UI-001, UI-002, UI-003, UI-004, UI-006, UI-007, UI-009, UI-010, UI-011, UI-012, UI-013, UI-023, UI-024 |
| DEC-007f | P10/P90 rasio historis | FR-005/014/031; BR-009 | PT-07; AD-07 | AC-005/014/031 | UI-002, UI-008, UI-016, UI-022 |
| DEC-012a | SUS ≥ 68 min 5 | NFR-004; BR-020 | PT-02; PR-02/03; PT-06; PB-04 | AC-032 | UI-002, UI-008, UI-014, UI-016, UI-017, UI-018, UI-019 |
| DEC-010d | CSV harga/pasokan | FR-018; BR-018 | PB-02; PR-07 | AC-018; NFR-003 | UI-002, UI-019, UI-021, UI-022 |
| DEC-010e | Login Admin terpisah | FR-028 | AU-04; AD-01 | AC-028; NFR-002 | UI-002, UI-010, UI-015, UI-019, UI-022 |
| DEC-003b | Kataloglogin | FR-006/018; BR-018 | AU-01; PR-02/03/07 | AC-006/018 | UI-001, UI-002, UI-010, UI-014, UI-016, UI-018, UI-019 |
| DEC-003c | Satu peran | FR-001/027/028 | AU-03; PT-10; AU-04 | AC-001/027/028 | UI-002, UI-015, UI-019, UI-022 |
| DEC-010f | Lokasi kecamatan | FR-004/006/027; BR-002/018 | PT-02/04; PR-02/03; PT-10 | AC-004/006/027 | UI-002, UI-008, UI-014, UI-016, UI-017, UI-018, UI-019 |
| DEC-011f | shadcn/Tailwind v4 | FR-030 | Semua shell | AC-030/035 | UI-001, UI-002, UI-003, UI-004, UI-006, UI-007, UI-009, UI-010, UI-011, UI-012, UI-013, UI-023, UI-024 |

### Tambahan keputusan pada klarifikasi fase 2

| Keputusan | Sumber | FR/BR | Halaman | Penerimaan | UI fase 3 |
|---|---|---|---|---|---|
| DEC-013a | Jawaban A pada OPN-003a | FR-004, BR-003/004 | PT-04→PT-02 | AC-004 diperluas: ubah harga/total hanya untuk pesanan baru; kontrak lama tetap; total di bawah volume dicadangkan + Disetujui + Selesai ditolak; pengajuan bersamaan tidak melanggar batas | UI-002, UI-008, UI-014, UI-016, UI-017, UI-018, UI-019 |
| DEC-013b | Jawaban B pada OPN-003b | FR-004/017/024, BR-003/005/007 | PT-04/06/09 | AC-024 diperluas: tarik membatalkan hanya Menunggu yang belum kedaluwarsa, notifikasi, reservasi dilepas sekali; Disetujui tetap dan tawaran Ditarik tidak menerima pesanan baru | UI-002, UI-008, UI-014, UI-016, UI-017, UI-018, UI-019 |
| DEC-013c | Jawaban B pada OPN-003c | FR-017/021/022, BR-019 | AD-04/06; PT-09 petani | AC-021 diperluas: Admin hanya menandai/meminta tindak lanjut; petani diberi notifikasi; tawaran tetap terlihat, pesanan baru tidak diblokir dan kontrak/volume tidak berubah | UI-002, UI-013, UI-021, UI-022 |
| DEC-013d | Jawaban A pada OPN-003d | FR-004, BR-002/004 | PT-02/04 | AC-004 diperluas: jenis/lokasi terkunci setelah pernah menerima pesanan, termasuk pesanan terminal; perubahan harus menjadi tawaran baru, tanpa memindahkan pesanan lama | UI-002, UI-008, UI-014, UI-016, UI-017, UI-018, UI-019 |
| DEC-013e | Jawaban B pada OPN-003e | FR-004, BR-003/007 | PT-03/04; tawaran baru PT-02 | AC-004 diperluas: Ditarik tidak dapat diterbitkan kembali; tawaran baru memiliki identitas baru tanpa memindahkan kontrak/riwayat atau mengaktifkan pesanan yang dibatalkan | UI-002, UI-008, UI-014, UI-016, UI-017, UI-018, UI-019 |
| DEC-013f | Jawaban B pada OPN-003f | FR-006/021, BR-018/019 | PR-02/03; PT-04; AD-04 | AC-006/021 diperluas: pembeli login melihat penanda/ringkasan masalah tanpa data pribadi; penanda bukan lampu harga dan tidak memblokir pemesanan | UI-001, UI-002, UI-010, UI-014, UI-016, UI-018, UI-019 |
| DEC-013g | Jawaban A pada OPN-003g | FR-017/021/022, BR-019 | PT-04/09; AD-04/06 | AC-021 diperluas: petani menyatakan Sudah diperbaiki, penanda tetap sampai Admin menutup; riwayat tetap, temuan lain terbuka tetap ditampilkan, tanpa efek kontrak/volume atau klaim mutu fisik terverifikasi | UI-002, UI-013, UI-021, UI-022 |
| DEC-013h | Jawaban B pada OPN-003h | FR-004/006, BR-002/005 | PT-02/04; PR-03 | AC-004 diperluas: tanggal ketersediaan boleh Belum ditentukan, tetap dapat terbit; tanggal tidak menjadi kedaluwarsa otomatis atau mengubah tenggat kontrak | UI-002, UI-008, UI-014, UI-016, UI-017, UI-018, UI-019 |
| DEC-014a | Jawaban A pada OPN-004a | FR-026/027, BR-018 | PT-06/06a | AC-027 diperluas: setelah Dibatalkan, nomor pihak lawan hilang dari detail/respons/bukti baru pada kontrak itu; riwayat tetap dan akses melalui kontrak lain dinilai terpisah | UI-002, UI-008, UI-017, UI-019, UI-022 |
| DEC-014b | Jawaban A pada OPN-004b | FR-026/027, BR-018 | PT-06/06a | AC-027 diperluas: satu konfirmasi masih Disetujui, dua konfirmasi menjadi Selesai dan kontak disembunyikan pada detail/respons/bukti baru; riwayat tetap | UI-002, UI-008, UI-017, UI-019, UI-022 |
| DEC-014c | Jawaban A pada OPN-004c | FR-021/026/027/028, BR-018/019 | AD-01/05/06; PT-06/06a mode pemantauan | AC-027 diperluas: nomor Admin tersamar pada tampilan/respons/pencarian/log/ekspor/bukti, tanpa aksi buka lengkap; identitas akun tetap dapat ditelusuri | UI-002, UI-015, UI-018, UI-019, UI-022 |
| DEC-014d | Jawaban A pada OPN-004d | FR-021/027, BR-007/008/019 | PT-10/05/06; AD-05 pemantauan | AC-027 diperluas: permintaan dicatat, penutupan menunggu seluruh Menunggu/Disetujui berakhir; akses pengakhiran/penyelesaian tetap, tanpa membatalkan atau melepas volume otomatis | UI-002, UI-015, UI-018, UI-019, UI-022 |
| DEC-014e | Jawaban A pada OPN-004e | FR-004/006/007/027, BR-004 | PT-02/04/10; PR-02/03; PT-06 transaksi lama | AC-004/007/027 diperluas: larangan transaksi baru bagi akun penutupan tertunda serta pesanan baru ke tawarannya; pemrosesan lama tetap, tanpa otomatis Ditarik/batal atau perubahan volume | UI-002, UI-008, UI-014, UI-016, UI-017, UI-018, UI-019 |
| DEC-014f | Jawaban A pada OPN-004f | FR-002/021/022/026/027, BR-018; NFR-002/010 | PT-10/06/06a; AD-05/06 | AC-027 diperluas: saat penutupan diproses, kontak/profil pribadi dihapus dan identitas riwayat dianonimkan, data transaksi nonpribadi tetap; periksa salinan/teks bebas/relasi, bukan hanya ganti nama atau ID | UI-002, UI-015, UI-019, UI-022 |
| DEC-014g | Jawaban A pada OPN-004g | FR-001/002; NFR-002/010 | AU-03; PB-05 | AC-001/002 diperluas: akun baru belum dibuat tanpa persetujuan eksplisit, kontrol awal tidak tercentang, dokumen dapat dibaca, versi/waktu persetujuan cocok dan tidak ditulis ulang | UI-002, UI-015, UI-019, UI-022 |
| DEC-015a | Jawaban B pada OPN-005a | FR-006/018, BR-018 | PR-02/03/07 hanya pembeli/Admin; PT-03/04 milik petani | AC-006/018 diperluas: akun petani tidak membaca katalog/detail/ekspor pasokan petani lain, termasuk URL/respons langsung; informasi harga publik dan tawaran sendiri tetap dapat dibaca | UI-001, UI-002, UI-010, UI-014, UI-016, UI-018, UI-019 |
| DEC-015b | Jawaban A pada OPN-005b | FR-018, BR-003/018 | PR-07, sumber filter PR-02 | AC-018 diperluas: agregasi jenis/wilayah, jumlah tawaran unik, volume tersedia dan harga minta minimum/maksimum; tanpa baris/identitas individual; reservasi dan kontrak tidak menggandakan hitungan | UI-002, UI-019, UI-021, UI-022 |
| DEC-016a | Jawaban B pada OPN-006a | FR-030; NFR-008 | Seluruh halaman dan komponen | AC-035: teks isi ≥ 16 px, target sentuh ≥ 44×44 px, keyboard/zoom 200%, kontras teks normal ≥ 4,5:1 dan indikator fokus ≥ 3:1, kedua mode; belum hasil uji | UI-001, UI-002, UI-003, UI-004, UI-006, UI-007, UI-008, UI-009, UI-010, UI-011, UI-012, UI-013, UI-016, UI-022, UI-023, UI-024 |
| DEC-016b | Jawaban B pada OPN-006b | NFR-009; FR-003/013/028 | PB-01; PT-01; PR-01; AD-01 | AC-036: target konten/tombol utama siap dipakai ≤ 5 detik; catat profil perangkat/jaringan/data serta protokol cache/pengulangan sebelum kesimpulan lulus | UI-001, UI-002, UI-010, UI-013, UI-014, UI-016, UI-017, UI-020, UI-022 |
| DEC-018a | Jawaban A pada OPN-008a | FR-005/008/014, BR-009/011/012 | PT-07/02/06; PR-03; AD-07 | AC-005/008 diperluas: L/U dibulatkan ke rupiah terdekat, 0,5 ke atas; tampilan/penilaian memakai nilai sama; nilai asal dan operasional tersimpan | UI-002, UI-008, UI-016, UI-022 |
| DEC-018b | Jawaban A pada OPN-008b | FR-004/007/009, BR-002/003/004 | PT-02/04/06; PR-03 | AC-004/007/009 diperluas: harga per kg rupiah bulat, volume maksimal dua desimal; presisi berlebih ditolak tanpa pembulatan diam-diam; reservasi/pelepasan pecahan volume konsisten | UI-002, UI-008, UI-014, UI-016, UI-017, UI-018, UI-019 |
| DEC-017a | Jawaban A pada OPN-007a | FR-015/016/031, BR-013/014/015; NFR-005 | PB-04; PT-01; PR-01; AD-07 | AC-015/031/033 diperluas: model/baseline/tidak tersedia dipilih dan dilabeli per provinsi/horizon; SHAP dan turunan mengikuti keluaran terkait, skor agregat tidak meloloskan unit gagal | UI-002, UI-005, UI-008, UI-016, UI-020, UI-022 |
| DEC-019a | Jawaban A pada OPN-009a | FR-012/029, BR-017 | PB-03/03a/03b | AC-012 diperluas: skala kontinu berpusat 0%, arah murah/mahal dan angka persentase jelas;0% valid berbeda dari tanpa data; tidak memakai kategori A–D atau batas kategori tetap | UI-002, UI-005, UI-008, UI-020, UI-022 |
| DEC-020a | Jawaban out of scope pada OPN-010a | FR-001/021/027/028; batas lingkup | AU-03; PT-10; AD-05 | AC-001/021/027/028: satu peran tetap; tidak ada aksi koreksi/pergantian peran oleh pengguna atau Admin pada MVP; opsi A/B tidak diadopsi | UI-002, UI-015, UI-019, UI-022 |

Bagian 1 memetakan 49 keputusan fase 1; tabel tambahan ini memetakan keputusan baru fase 2. Jumlah keputusan kini 73, termasuk satu keputusan mengecualikan koreksi peran dari MVP, tanpa mengubah riwayat persetujuan fase 1.

### Revisi visual pengguna setelah draf fase 3

| Keputusan | Sumber | Kebutuhan | Halaman IA | Penerimaan | Aturan UI |
|---|---|---|---|---|---|
| DEC-021a | Instruksi pengguna: enam mockup, base Jagains, primary saat ini, palet hangat hanya aksen/status | FR-030; NFR-007/008; izin/status tetap mengikuti SRS/IA | Semua shell; PT-01/02/06, PR-01/02, PB-02/03/03a/03b | AC-030/035; audit token bukan hasil uji aplikasi | UI-001, UI-002, UI-003, UI-004, UI-005, UI-006, UI-007, UI-009, UI-010, UI-011, UI-023, UI-024 |

Jumlah terkini **74 keputusan**: 49 fase 1 + 24 klarifikasi fase 2 + 1 revisi visual fase 3. DEC-021a menggantikan penggunaan Warm Cream sebagai base pada DEC-011c; baris historis tetap dipertahankan untuk jejak keputusan. Pemetaan visual keenam gambar dan bagian yang diselaraskan dengan SRS/IA tersedia pada UI Guidelines §1.4.

## 2. Indeks FR → AC dan cakupan halaman

Satu AC dengan nomor sama menguji FR terkait; AC tambahan memperluas pemeriksaan tanpa menambah perilaku yang belum dipilih. Semua proses latar mempunyai representasi status/riwayat; tidak harus menjadi layar tersendiri.

| FR | AC utama | Halaman utama / proses yang diwakili | Ketergantungan penting | Aturan UI |
|---|---|---|---|---|
| FR-001 | AC-001 | AU-01/02/03, PT-10 | OPN-001/004/010 | UI-015, UI-019, UI-022 |
| FR-002 | AC-002 | PB-05, AU-01/03 | OPN-004 | UI-015, UI-019, UI-022 |
| FR-003 | AC-003 | PT-01 | Data harga/model | UI-001, UI-010, UI-016, UI-020, UI-022 |
| FR-004 | AC-004 | PT-02/03/04 | OPN-002/003/008 | UI-008, UI-014, UI-016, UI-017, UI-018, UI-019 |
| FR-005 | AC-005 | PT-07; kalkulasi ditampilkan PT-01/02, PR-01/03 | OPN-002/008 | UI-008, UI-016, UI-022 |
| FR-006 | AC-006 | PR-02/03 | DEC-015a/b; verifikasi implementasi | UI-001, UI-010, UI-014, UI-016, UI-018, UI-019 |
| FR-007 | AC-007 | PR-03→PT-06, volume di PT-04 | OPN-008 | UI-014, UI-016, UI-017, UI-019, UI-022 |
| FR-008 | AC-008 | PT-02/06, PR-03, riwayat AD-06 | OPN-002/008 | UI-004, UI-008, UI-016, UI-022 |
| FR-009 | AC-009 | PT-06 | Versi harga dan waktu | UI-013, UI-014, UI-017, UI-022 |
| FR-010 | AC-010 | PT-06 | AC-008/023 | UI-013, UI-016, UI-017, UI-022 |
| FR-011 | AC-011 | PB-02 | OPN-002/008 | UI-005, UI-008, UI-020, UI-022 |
| FR-012 | AC-012 | PB-03/03a/03b | OPN-009 | UI-005, UI-008, UI-020, UI-022 |
| FR-013 | AC-013 | PR-01 | Akses katalog/model | UI-001, UI-010, UI-016, UI-020, UI-022 |
| FR-014 | AC-014 | PT-07 | OPN-002 | UI-008, UI-016, UI-020, UI-022 |
| FR-015 | AC-015 | PB-04, AD-07; ringkasan PT-01/PR-01 | OPN-002/007 | UI-005, UI-008, UI-020, UI-022 |
| FR-016 | AC-016 | PB-04, AD-07 | OPN-007 | UI-005, UI-020, UI-022 |
| FR-017 | AC-017 | PT-09 dan tautan PT-06 | Peristiwa transaksi | UI-013, UI-021, UI-022 |
| FR-018 | AC-018 | PB-02, PR-07 | DEC-015a/b; verifikasi implementasi | UI-019, UI-021, UI-022 |
| FR-019 | AC-019 | AD-02/06 | OPN-002/008 | UI-008, UI-014, UI-016, UI-017, UI-022 |
| FR-020 | AC-020 | AD-03/06 | OPN-002/009 | UI-005, UI-008, UI-020, UI-022 |
| FR-021 | AC-021 | AD-04/05/06 | OPN-003/004/010 | UI-015, UI-018, UI-019, UI-022 |
| FR-022 | AC-022 | AD-06; log proses bisnis/parameter/data | OPN-004 | UI-017, UI-018, UI-019, UI-020, UI-022 |
| FR-023 | AC-023 | PT-06/09; pemrosesan tenggat di server | Waktu/konkurensi | UI-017, UI-021, UI-022 |
| FR-024 | AC-024 | PT-06/09 dan AD-06 | Alasan/konkurensi | UI-013, UI-014, UI-017, UI-018, UI-021, UI-022 |
| FR-025 | AC-025 | PT-06/05/04 | Konfirmasi per pihak | UI-013, UI-017, UI-019, UI-022 |
| FR-026 | AC-026 | PT-06/06a | OPN-004 | UI-008, UI-017, UI-019, UI-022 |
| FR-027 | AC-027 | PT-10/06/06a | OPN-004/010 | UI-015, UI-019, UI-022 |
| FR-028 | AC-028 | AU-04, AD-01 | OPN-001 | UI-010, UI-015, UI-019, UI-022 |
| FR-029 | AC-029 | PB-03b, AD-07 | OPN-007 | UI-005, UI-020, UI-022 |
| FR-030 | AC-030 | Semua shell publik/peran | UI v0.2; pengujian OPN-006 | UI-001, UI-003, UI-004, UI-006, UI-007, UI-009, UI-010, UI-011, UI-012, UI-013, UI-023, UI-024 |
| FR-031 | AC-031 | AD-07/03/06; publikasi hasil ke PB-04/03b | OPN-002/007 | UI-005, UI-020, UI-022 |

## 3. Target proposal, NFR dan bukti

| Sumber / kebutuhan | Pemetaan | Verifikasi / batas |
|---|---|---|
| P §3/§4.1: posisi tawar, pembeli alternatif, informasi harga | FR-004/005/006/007/011/013/014/015; BR-001/009/016 | AC-004…007/011/013…015; tidak mengklaim dampak ekonomi sudah diukur |
| P §4.2/A.7: empat modul | FR-005/008/015/016/029; BR-009/011/013/014 | AC-005/008/015/016/029; model wilayah perlu bukti |
| P §4.1: MASE ≤ 0,9, baseline/SARIMA, pita 80% cakupan 75–85% | NFR-005, FR-031 | AC-033; OPN-007 untuk protokol, bukan mengubah target |
| P §4.1/A.7: lonjakan recall ≥ 70%, precision ≥ 60% | NFR-006, FR-031 | AC-034; evaluasi laporan, alert otomatis inkubasi |
| P §4.1: ≤ 5 langkah | BR-020, NFR-004 | AC-032 sesuai DEC-005k, bukan target lama sampai Disetujui |
| P §4.3/A.2: TKT 4, backtest/uji pengguna | NFR-004/005/006 | AC-032/033/034; TKT adalah target program, bukan skor yang dinyatakan tercapai oleh dokumen |
| P A.9: prototipe 10 Nov/final/inkubasi | SRS §2, DEC-001/002/004 | Ketertelusuran tahap; tidak memperluas scope penuh produk |
| P A.10: monetisasi/coldstart/pilot | BR-001, DEC-002a/004 | Bisnis hilirisasi/pilot nyata terpisah; gratis final tidak membuktikan model bisnis telah diuji |
| P A.12: kualitas, salah tafsir, privasi | FR-002/020/027/031; NFR-002/007 | AC-002/020/027/031; izin data/kebijakan menunggu bukti |
| NFR-001 Integritas | BR-003/004/005/006/007/008 | AC-007/009/010/023/024/025 |
| NFR-002 Keamanan | FR-001/006/022/027/028 | AC-001/006/022/027/028; OPN-001/004 |
| NFR-003 CSV aman | FR-018 | AC-018; bukan format ekspor data pribadi |
| NFR-004 Usability | BR-020, DEC-012a | AC-032 |
| NFR-005 Prakiraan | FR-015/031 | AC-033 |
| NFR-006 Lonjakan | FR-031 | AC-034 |
| NFR-007 Transparansi | FR-005/011/012/014/015/016/029/031 | AC-005/011/012/014/015/016/029/031 |
| NFR-008 Aksesibilitas | FR-030; seluruh komponen | AC-035; target DEC-016a disetujui, audit token fase 3 tersedia; uji aplikasi belum tersedia |
| NFR-009 Kinerja/operasi | FR-004/007/020/023 | AC-036; target5detik DEC-016b, profil/bukti uji OPN-006 |
| NFR-010 Audit/versi | FR-019/022/031 | AC-019/022/031 |

## 4. Temuan audit → penyelesaian atau tindak lanjut

| Audit | Penanganan fase 2 |
|---|---|
| AUD-001/023 prioritas | SRS §2 semua W/T/D target final; FR-003/013 merujuk fitur prakiraan wajib tersedia, fallback bukan penghapusan |
| AUD-002/014/015/033 peran/akun/halaman bersama | SRS §2.2, FR-001/027/028; IA §2/7/8; akses sensitif mengikuti DEC-014a–g; petani tidak membaca katalog sesuai DEC-015a, kolom CSV agregasi ditetapkan DEC-015b |
| AUD-003/004/005/019/025 transaksi | BR-003…008/020; FR-007/009/010/023/024/025/026; IA §5; editaktif/moderasi OPN-003 |
| AUD-006/020 semantik lampu | BR-011/012; FR-008/019/030; fase 3 memisahkan brand/status; harga atas tetap kuning |
| AUD-007/028 estimator | BR-009/010; FR-005/014; OPN-002/008; F-03 lama tidak diulang sebagai ketidakmungkinan rumus |
| AUD-008/009 horizon/SHAP | BR-013…015; FR-015/016/029/031; OPN-007 |
| AUD-010 harga diamati | BR-016; FR-011/020; periode dan konversi berlabel |
| AUD-011/026 peta | BR-017; FR-012; skala kontinu DEC-019a; geometri/token OPN-009 |
| AUD-012 latih simulasi | BR-001; FR-031/020; AC-031 |
| AUD-013 notifikasi | FR-017 untuk kedua peran, hanya aplikasi |
| AUD-016 monetisasi | SRS §2/BR-001, DEC-002a; tidak ada halaman billing |
| AUD-017/021/022/031 UI/NFR | FR-030, NFR-008; pilihan font/palet/mode/pustaka dicatat, angka/detail fase 3 |
| AUD-018 istilah | Glosarium terpisah, SRS §3.1; “Pesanan/Kontrak” bukan “Penawaran Saya” pembeli |
| AUD-024 referensi FR salah | FR-022 tetap audit, latih/publikasi model menjadi FR-031 |
| AUD-027/032 navigasi | IA §3/4/5/8: tujuan PB-04/PR-07/PT-09/10 eksplisit, tanpa janji 2 klik |
| AUD-029 bukti hilang | Diagram Mermaid mandiri; tidak merujuk PNG hilang; kode/dataset belum tersedia tetap batas audit |
| AUD-030 angka contoh | SRS §1/§3 contoh berlabel; data publik harus bersumber/berperiode, bukan “pekan ini” palsu |

## 5. Kontinuitas ID lama dan batas matriks

FR-001…022 mempertahankan domain utama draf kebutuhan. FR-005 kini khusus rentang; lampu/pemeriksaan dipusatkan FR-008 agar tidak ada dua otoritas. FR-010 adalah penerimaan harga; penyelesaian/bukti dipisahkan FR-025/026. FR-016 hanya SHAP prakiraan; SHAP wilayah FR-029. FR-022 audit tidak dijadikan closed-loop. FR-023…031 menampung perluasan aturan fase 1 dan kebutuhan yang sebelumnya tersembunyi. Persetujuan data FR-002 lama kini dibedakan dari keputusan hukum/retensi yang belum dipilih, OPN-004.

AC-001…036 pada paket ini mulai ditetapkan sejak v0.1 dan dipertahankan pada v0.2; tidak boleh menganggap nomor AC pada draf lama mempunyai arti sama. Matriks lama tidak digunakan untuk klaim kelulusan baru. ID halaman/alias lama dipetakan di IA §8.

Seluruh 49 DEC fase 1, 24 keputusan fase 2 serta revisi visual DEC-021a memiliki baris, semua 31 FR dan 10 NFR memiliki jalur verifikasi; AC-032…036 khusus pemeriksaan lintas kebutuhan. Tidak ada kebutuhan fase 3 yang dianggap selesai hanya karena sudah memiliki kolom. Tabel ini harus diperbarui jika SRS/IA berubah sebelum review atau implementasi.

## 6. Aturan UI → kebutuhan → halaman → penerimaan

Aturan lengkap berada pada [UI Guidelines](UI_GUIDELINES_SAMBUNG.md). Seluruh 31 FR mempunyai representasi UI pada indeks §2; ini tidak memindahkan validasi server ke browser. Perhitungan, reservasi atomik/pelepasan sekali, otorisasi, audit, anonimisasi, impor dan evaluasi model tetap proses backend/data tanpa layar tambahan. UI hanya menyajikan masukan, status, hasil atau laporan melalui halaman IA yang sudah ada. AC backend tetap wajib diuji terpisah.

| Aturan | Kebutuhan / aturan terkait | Halaman / konteks IA | Penerimaan / bukti |
|---|---|---|---|
| UI-001 | FR-003/006/013/030; NFR-004/008 | PT-01, PR-01/02; seluruh hierarki | AC-003/006/013/030/032/035 |
| UI-002 | FR-001/004/006/007/021/027/028; BR-001/018/019 | Semua halaman sesuai izin IA | AC-001/004/006/007/021/027/028 |
| UI-003 | FR-030 | Semua shell terang/gelap | AC-030/035 |
| UI-004 | FR-008/021/030; BR-011/012/019 | PT-02/04/06, PR-02/03, AD-04 | AC-008/021/030/035 |
| UI-005 | FR-011/012/015/016/020/029/031; BR-013/014/017; NFR-007/008 | PB-02/03/03a/03b/04, AD-03/07 | AC-011/012/015/016/020/029/031/033/034/035 |
| UI-006 | FR-030; NFR-008 | Seluruh pasangan token dan mode | AC-030/035; audit warna hanya bukti parsial |
| UI-007 | FR-030; NFR-004/008 | Seluruh teks dan kontrol | AC-030/032/035 |
| UI-008 | FR-004/005/007/008/011/012/014/015/019/020/026; BR-002/003/009/011 | PT-02/04/06/06a/07, PR-03, PB-02/03/04, AD-02/03 | AC-004/005/007/008/011/012/014/015/019/020/026 |
| UI-009 | FR-030; NFR-004/008 | Seluruh layout dan kelompok informasi | AC-030/032/035 |
| UI-010 | FR-003/006/013/028/030; BR-018; NFR-008/009 | Shell publik/petani/pembeli/Admin, PT-10 | AC-003/006/013/028/030/035/036 |
| UI-011 | FR-030; NFR-008 | Seluruh kontrol dan indikator fokus | AC-030/035 |
| UI-012 | FR-030; NFR-008 | Seluruh komposisi primitive | AC-030/035 |
| UI-013 | FR-009/010/017/024/025/030; BR-007/008 | PT-06/09, PT-04, PR-03; kontrol bersama | AC-009/010/017/024/025/030/035 |
| UI-014 | FR-004/006/007/009/019/024; BR-002/003/004 | PT-02/04/06, PR-02/03, AD-02 | AC-004/006/007/009/019/024 |
| UI-015 | FR-001/002/021/027/028; BR-018/019; NFR-002 | AU-01/02/03/04, PB-05, PT-10, AD-05 | AC-001/002/021/027/028 |
| UI-016 | FR-003/004/005/006/007/008/010/013/014/019; BR-009/010/011/012 | PT-01/02/04/06/07, PR-01/02/03, AD-02 | AC-003/004/005/006/007/008/010/013/014/019 |
| UI-017 | FR-004/007/009/010/019/022/023/024/025/026; BR-003/004/005/006/007/008/020; NFR-001/004 | PT-04/05/06/06a, PR-03, AD-02/06 | AC-004/007/009/010/019/022/023/024/025/026/032 |
| UI-018 | FR-004/006/021/022/024; BR-003/005/007/019 | PT-04/09, PR-02/03, AD-04/06 | AC-004/006/021/022/024 |
| UI-019 | FR-001/002/004/006/007/018/021/022/025/026/027/028; BR-004/018/019; NFR-002/010 | PT-10/06/06a, AU-03/04, AD-05/06; akses katalog | AC-001/002/004/006/007/018/021/022/025/026/027/028 |
| UI-020 | FR-003/011/012/013/014/015/016/020/022/029/031; BR-009/013/014/015/016/017; NFR-005/006/007/010 | PB-02/03/03b/04, PT-01/07, PR-01, AD-03/06/07 | AC-003/011/012/013/014/015/016/020/022/029/031/033/034 |
| UI-021 | FR-017/018/023/024; BR-007/008/018; NFR-003 | PT-09/06, PB-02, PR-07 | AC-017/018/023/024 |
| UI-022 | FR-001/002/003/005/007/008/009/010/011/012/013/014/015/016/017/018/019/020/021/022/023/024/025/026/027/028/029/031; NFR-001/002/007 | Semua keadaan K0–K7 yang relevan pada inventaris IA | AC sesuai FR pada indeks §2; keadaan gagal/izin/data/konflik |
| UI-023 | FR-030; NFR-008/009 | Integrasi tema semua shell; penerapan tema v0.2 belum diaudit | AC-030/035/036; kompilasi dan runtime menunggu implementasi |
| UI-024 | FR-030; BR-001/002/003/004/005/006/007/008/009/011/012/013/014/015/017/018/019; NFR-007/008 | Seluruh komponen; larangan tidak menambah halaman | AC terkait pada §2; khusus AC-030/035 |

Audit 106 pasangan token hanya mendukung bagian warna AC-035. Revisi dokumentasi ini tidak membuktikan hasil uji aplikasi, SUS, kinerja, model, privasi atau penerimaan fungsional. SRS §7 tetap mencatat ketergantungan dan bukti yang belum tersedia.
