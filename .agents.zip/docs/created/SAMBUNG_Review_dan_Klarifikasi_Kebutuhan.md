# SAMBUNG — Dokumen Review Proposal, Klarifikasi Kebutuhan, dan Definisi Awal MVP

| | |
|---|---|
| **Proyek** | SAMBUNG: Platform Transaksi dan Intelijen Harga Gabah Berbasis AI Spasio-Temporal Terjelaskan |
| **Tim** | Tim 23.58 — PLAY-IT PLUS Polinema 2026 (subtema Digitalisasi AI Bidang Ketahanan Pangan) |
| **Dokumen** | Hasil Phase 1 (Review), Phase 2 (Klarifikasi), Phase 3 (Definisi MVP) dan kerangka Phase 4 (SRS) |
| **Status** | **DRAFT untuk konfirmasi** — bukan SRS final |
| **Tanggal** | 29 Oktober 2026 |
| **Acuan** | Proposal `PLAY-IT PLUS Polinema 2026 - Tim 23.58.docx`; ISO/IEC/IEEE 29148 (sebagai acuan struktur, **tanpa klaim kepatuhan penuh**) |
| **Tenggat** | Prototipe/Bootcamp II: **10 Nov 2026** · MVP Bootcamp III: **16–26 Nov 2026** · Final: **26–28 Nov 2026** |

### Legenda status item

| Label | Arti |
|---|---|
| **[DISEPAKATI]** | Tertulis jelas di proposal/brief dan tidak bertentangan |
| **[REKOMENDASI]** | Usulan konsultan; belum diputuskan tim |
| **[ASUMSI]** | Dipakai sementara agar pekerjaan berjalan; harus dikonfirmasi |
| **[KONFIRMASI]** | Keputusan bisnis yang hanya bisa diambil tim/pembimbing |

---

## 1. Ringkasan Eksekutif

1. Proposal SAMBUNG kuat pada **masalah, data pendukung, dan visi produk**. Namun ada **25 temuan** yang harus ditutup sebelum implementasi: 8 bersifat kritis karena memblokir alur inti atau metrik uji.
2. Tiga temuan paling berisiko bagi penilaian juri:
   - **F-03:** rentang harga wajar di wireframe (Rp6.650–6.940) **tidak dapat dihasilkan** dari rumus A.7 menggunakan angka pada wireframe yang sama.
   - **F-18:** contoh wireframe Jawa Timur lebih rendah dari narasi proposal sendiri (GKP 2026 rata-rata sekitar Rp7.000, di beberapa daerah Rp8.000).
   - **F-05:** SHAP ditetapkan wajib di MVP, padahal tahap awal harga wajar berbasis aturan sehingga tidak ada model yang dijelaskan.
3. Sisa waktu **12 hari** sampai prototipe dan **28 hari** sampai final. Rekomendasi: MVP berupa **monolit Laravel + Inertia/React**, model dilatih **offline** lalu hasilnya disimpan di PostgreSQL, dan semua kontrak ditandai **simulasi**.
4. Ada **15 keputusan** (Q-01 s.d. Q-15) beserta default yang saya rekomendasikan. Jika semua default disetujui, SRS final dapat langsung disusun.

---

## 2. Pemahaman Proyek

### 2.1 Masalah yang diselesaikan
| # | Masalah | Bukti di proposal |
|---|---|---|
| M1 | Petani tidak tahu harga wajar saat panen dan tidak punya pembeli alternatif selain tengkulak | Bagian 3, 4.1 |
| M2 | Harga pangan berbeda antardaerah tanpa penjelasan | 4.1 (disparitas median 45–58%) |
| M3 | Data harga rutin (PIHPS) berhenti sebagai catatan historis | Bagian 3 |
| M4 | Risiko petani menjual di bawah harga pasar daerahnya karena berpatokan HPP | 4.1 (HPP Rp6.500 vs GKP Rp7.000–8.000 pada 2026) |
| M5 | Literasi digital rendah (indeks 3,65 dari 5,00) | 4.1 [14] |

### 2.2 Proposisi nilai
- **Petani:** harga acuan, lampu harga sebelum menawarkan, pembeli alternatif, bukti kesepakatan.
- **Penggilingan/pengolah:** pasokan, harga beli yang transparan, kontrak yang diperiksa harga.
- **Warga dan Dinas:** transparansi rantai harga dan disparitas daerah.
- **Prinsip bisnis:** tanpa komisi transaksi. Pendapatan dari langganan dasbor produsen dan API (di luar MVP).

### 2.3 Empat modul AI
| Modul | Fungsi | Keluaran | Status di MVP (rekomendasi) |
|---|---|---|---|
| (a) Estimator Harga Wajar | Rentang harga wajar GKP per provinsi | Batas bawah L, batas atas U | **Tahap 1 berbasis aturan** (Must). Tahap 2 GB-kuantil: pasca-MVP |
| (b) Prakiraan Spasio-Temporal | Harga 1–4 pekan beserta pita 80% | Median, P10, P90 | Should (fallback baseline) |
| (c) Penjelas SHAP | Alasan prakiraan | Kontribusi fitur | Hanya pada (b); untuk (a) pakai penjelasan komponen rumus |
| (d) Pemeriksa Kontrak | Lampu hijau/kuning/merah | Warna dan alasan | Must, berbasis aturan atas keluaran (a) |

### 2.4 Daftar istilah (akan dimuat di SRS Bab 1)
| Istilah | Penjelasan |
|---|---|
| **GKP** | Gabah Kering Panen: gabah setelah dipanen, umumnya kadar air hingga ±25% dan kadar hampa hingga ±10% (patokan HPP; **batas persisnya perlu diverifikasi pada regulasi terbaru**) |
| **GKG** | Gabah Kering Giling: gabah yang sudah dikeringkan (umumnya kadar air ±14%), siap digiling |
| **Rendemen** | Persentase beras yang dihasilkan dari gabah. Proposal memakai **53,38% (GKP→beras, SKGB BPS 2018)** |
| **HPP** | Harga Pembelian Pemerintah. Proposal: Rp6.500/kg GKP (2025) |
| **PIHPS** | Pusat Informasi Harga Pangan Strategis (Bank Indonesia) |
| **BPS** | Badan Pusat Statistik |
| **SPHP** | Stabilisasi Pasokan dan Harga Pangan (operasi pasar Bulog) |
| **ENSO / El Niño** | Fenomena iklim yang memengaruhi curah hujan dan produksi pangan |
| **Quantile regression** | Regresi yang memprediksi persentil tertentu (mis. P10 dan P90), bukan hanya rata-rata |
| **SHAP** | Metode penjelas AI: kontribusi tiap fitur terhadap keluaran model |
| **MASE** | Mean Absolute Scaled Error: galat model dibagi galat baseline naif. **<1 berarti lebih baik dari baseline** |
| **MAPE** | Mean Absolute Percentage Error |
| **Cakupan interval 80%** | Proporsi nilai aktual yang jatuh dalam pita P10–P90. Target 75–85% |
| **Walk-forward backtesting** | Evaluasi dengan melatih di masa lalu dan menguji ke depan secara bertahap, tanpa melihat masa depan |
| **SUS** | System Usability Scale; skor 0–100 |
| **TKT** | Tingkat Kesiapterapan Teknologi |
| **UU PDP** | UU No. 27 Tahun 2022 tentang Pelindungan Data Pribadi |

---

## 3. Phase 1 — Temuan Review Proposal (Detail)

Keparahan: **K** = Kritis (memblokir alur inti), **P** = Penting, **R** = Rendah.

### 3.1 Aturan bisnis dan modul AI

#### F-01 [K] Ambang lampu harga tidak didefinisikan
- **Bagian:** A.7 (baris Pemeriksa kontrak: "Aturan di A.3"), A.3 wireframe Jual dan Kontrak.
- **Fakta:** A.3 hanya wireframe. Satu-satunya data: harga Rp6.300 dengan batas bawah Rp6.650 = selisih 350 (5,26%) → **merah**. Wireframe kontrak: Rp6.800 di dalam 6.650–6.940 → **hijau**. Kuning tidak pernah muncul. Harga di atas batas atas tidak dijelaskan.
- **Dampak:** FR pemeriksa kontrak tidak bisa ditulis atau diuji.
- **Rekomendasi:** lihat §6.1.

#### F-02 [K] Interval dan horizon prakiraan tidak konsisten
| Sumber | Interval | Horizon |
|---|---|---|
| 4.1 target | 80% | 2–4 pekan |
| A.7 | pita 80% | keluaran 1–8 pekan; teks "2 dan 4 pekan" |
| Wireframe Beranda | **90%** | "Prediksi 3–4 pekan" |
- **Rekomendasi:** interval 80% (P10–P90), horizon 1–4 pekan, label UI diperbaiki.

#### F-03 [K] Wireframe tidak dapat direproduksi dari rumus A.7
Rumus A.7 Tahap 1: *harga beras produsen × rendemen × rasio kualitas (93–97%)*. Memakai angka dari wireframe Papan Harga (produsen/penggilingan Rp14.380; "petani (beras)" Rp12.730):

| Perhitungan | Hasil | Cocok dengan 6.650–6.940? |
|---|---|---|
| 14.380 × 0,5338 | 7.676 | — |
| 14.380 × 0,5338 × 0,93 s.d. 0,97 | **7.139 – 7.446** | Tidak |
| 12.730 × 0,5338 | 6.795 | Titik tengah rentang |
| 12.730 × 0,5338 × 0,93 s.d. 0,97 | 6.319 – 6.591 | Tidak |
| 6.795 ± 2,1% | 6.652 – 6.938 | **Ya** (≈ rentang wireframe) |

Kesimpulan: rentang wireframe tampaknya ±2,1% dari 6.795 (12.730 × 0,5338), **bukan** hasil rasio 93–97%. Angka "petani (beras)" 12.730 juga tampak diturunkan dari titik tengah harga wajar ÷ rendemen, bukan harga yang diamati.
- **Rekomendasi:** tetapkan satu rumus resmi (§6.2), lalu hitung ulang semua angka wireframe darinya.

#### F-04 [P] Input estimator tidak konsisten
4.2 menyebut harga beras **eceran**, A.7 menyebut harga beras **produsen**. Tahap 2 (GB-kuantil) bergantung pada data transaksi yang belum ada. **Rekomendasi:** MVP hanya Tahap 1; Tahap 2 ditandai pasca-MVP.

#### F-05 [K] Ketergantungan SHAP
- SHAP wajib di MVP (A.9, brief) tetapi Tahap 1 berbasis aturan, jadi tidak ada model untuk di-SHAP.
- "SHAP selisih harga antardaerah" memerlukan model tingkat harga lintas provinsi, yang tidak didesain di A.7. Wireframe Peta hanya berisi teks statis "Mengapa harga bisa berbeda?".
- **Rekomendasi:** SHAP hanya pada model prakiraan (b). Untuk harga wajar: penjelasan komponen rumus ("harga beras produsen Rp… × rendemen 53,38% × rasio …"). Untuk Peta: teks faktor umum, bukan SHAP, pada MVP.

#### F-06 [P] Kelayakan target prakiraan
- Baseline "harga pekan lalu": MAPE 0,42% (14 hari) dan 0,80% (28 hari) nasional; 0,59% dan 1,06% rata-rata provinsi.
- Target MASE ≤0,9 berarti menang ≥10% atas baseline yang sangat kuat.
- Metrik tertulis "MASE ataupun MAPE" (ambigu). Fitur ENSO/curah hujan berisiko **kebocoran data** bila memakai nilai aktual masa depan.
- **Rekomendasi:** MASE per provinsi sebagai metrik utama, MAPE pendamping; fitur eksogen hanya yang tersedia saat prakiraan; sediakan fallback tampilan baseline + pita bila model tidak menang.

#### F-07 [P] Deteksi lonjakan: target tanpa fitur
Target recall ≥70% dan precision ≥60% (4.1) padahal peringatan dini Could Have. **Rekomendasi:** jadikan hasil eksperimen di laporan backtesting, bukan FR MVP.

### 3.2 Alur transaksi dan peran

#### F-08 [K] Mekanisme pasar ganda
BPMN A.5: sistem "mencocokkan petani dengan produsen terdekat" (otomatis) dan produsen "mengajukan pesanan dan harga beli". Wireframe Dasbor: produsen menelusuri dan membandingkan penawaran. **Rekomendasi:** produsen memilih listing secara manual; matching otomatis ditunda.

#### F-09 [K] Siklus kontrak tidak lengkap
- Tidak jelas harga kontrak berasal dari harga minta petani atau harga beli produsen.
- Tidak ada: harga balik, batas putaran, penolakan, pembatalan, kedaluwarsa.
- BPMN: peringatan negosiasi ulang hanya ke petani; produsen "meninjau dan menyetujui". Wireframe: status hanya Draf → Persetujuan → Pelaksanaan, tanpa status selesai.
- Mesin status: lihat §6.3.

#### F-10 [P] "Maksimal 5 langkah" belum terukur
Wireframe Jual: 3 langkah (Detail panen, Tinjau tawaran, Kirim). Produsen: telusur, pesan, tinjau kontrak, setuju. **Rekomendasi:** definisi §6.6.

#### F-11 [K] Closed-loop tanpa sumber data sahih
Pembayaran dan logistik out of scope; kontrak MVP simulasi. Tidak ada peristiwa "transaksi nyata selesai". Harga isian pengguna dapat memanipulasi model. **Rekomendasi:** `is_simulated = true` untuk semua kontrak MVP dan **dikecualikan dari pelatihan**; retraining Could Have dengan validasi outlier dan jumlah minimum.

#### F-12 [P] Selisih scope antara proposal dan brief
| Fitur | A.9 proposal | Brief | Rekomendasi |
|---|---|---|---|
| Registrasi/login, Katalog | tidak disebut | Must (katalog) | **Must** |
| Peta Publik | Tinggi | Must | Must |
| Dasbor Produsen | Tinggi | Must | Must (versi ringkas) |
| Prakiraan 2–4 pekan | Tinggi | Should | Should |
| Notifikasi | Tinggi | Should | Should (dalam aplikasi) |
| Retraining otomatis | Menengah | Could | Could |

#### F-13 [P] Peran tidak selaras
- Proposal: **Penggiat Petani (pendamping)** ada; Admin tidak ada.
- Brief: Admin ada; Penggiat Petani tidak ada.
- Dinas hanya via API tanpa antarmuka wireframe.

#### F-14 [P] Dasbor Produsen bercampur menu petani
Wireframe menyatakan "masih menjadi satu dengan menu petani". **Rekomendasi:** navigasi dan otorisasi per peran (§5.3).

### 3.3 Data dan metrik

#### F-15 [P] "Bagian petani" tidak konsisten
75–81% (4.1), 76–81% (A.8), **83%** (wireframe: 12.730 ÷ 15.350 = 82,9%). Baris "Petani (beras)" tidak dilabeli sebagai ekuivalen. **Rekomendasi:** label "ekuivalen beras" dan tabel *lineage* data per tingkat (§8.3).

#### F-16 [P] Definisi disparitas tidak baku
| Sumber | Nilai |
|---|---|
| 4.1 | median 58% (2023) → 45% (pekan 7 Okt 2026); produsen 59% (2025), 47% (2026); eceran 35% |
| A.8 | produsen 105% (2023) → 47% (2026); eceran 49% → 35% |
| Wireframe Peta | 49% |
Cakupan provinsi juga berbeda: 34 (PIHPS), 26 (analisis, tanpa Riau dan NTB), 17–28 (produsen). **Rekomendasi:** disparitas = (maks − min) ÷ min per komoditas per pekan, hanya provinsi berdata valid, dengan rentang provinsi dicantumkan.

#### F-17 [P] Peta Publik
- Kelas A–D (<20, 20–30, 30–40, >40%) tidak menyebut acuan pembanding.
- PIHPS 34 provinsi; Indonesia kini memiliki 38 provinsi sehingga GeoJSON perlu dipetakan ke data.
- **Rekomendasi:** acuan median nasional (Q-08), tabel pemetaan, provinsi tanpa data berwarna abu-abu.

#### F-18 [K] Contoh harga bertentangan dengan narasi
4.1: GKP 2026 rata-rata sekitar Rp7.000 dan beberapa daerah Rp8.000. Wireframe Jawa Timur: Rp6.650–6.940. Contoh yang lebih rendah dari pasar adalah **tepat risiko yang ingin dihindari proyek**. **Rekomendasi:** pakai data nyata terbaru, atau beri tanda eksplisit "data ilustrasi".

#### F-19 [P] HPP bukan konstanta
Ref. [11]: HET-HPP "masih dikaji". **Rekomendasi:** tabel `hpp_policies` (nilai, jenis, berlaku mulai/sampai) dan semua perbandingan merujuk tabel itu.

#### F-20 [P] Input listing kurang
Ada: komoditas (GKP), volume, kadar air, lokasi (kecamatan), harga minta. Tidak ada: kadar hampa, tanggal siap panen/ketersediaan, foto, catatan mutu. Beranda berjanji "masukkan mutu" tetapi tidak ada isiannya. Kadar air tidak memengaruhi apa pun. GKG tidak dibahas. Verifikasi mutu laboratorium out of scope sehingga **mutu hanya deklarasi mandiri**.

### 3.4 Hukum, privasi, dan keamanan

#### F-21 [P] Kontrak digital dan identitas
- Status hijau "menilai harga, bukan menjamin syarat" (baik, perlu dipertahankan).
- Validitas hukum kontrak digital dan tanda tangan elektronik tidak dibahas. Identitas pihak tanpa mekanisme verifikasi.
- **Rekomendasi:** kontrak MVP berlabel jelas **"Bukti kesepakatan simulasi — bukan dokumen hukum tersertifikasi"**; tanpa tanda tangan elektronik tersertifikasi.

#### F-22 [P] Arsitektur terlalu besar untuk tim mahasiswa
A.4: API Gateway, AI Service Gateway, ETL, Feature Store, Training Pipeline, External Forecast API. Laravel tidak menjalankan SHAP/GBM. **Rekomendasi:** §4.3.

#### F-23 [R] Langganan tanpa mekanisme tagih
Dasbor produsen berstatus Must, tetapi monetisasi tidak ada mekanisme. **Rekomendasi:** MVP gratis tanpa gerbang langganan.

#### F-24 [P] Risiko belum lengkap
A.12 tidak mencakup: listing palsu, manipulasi harga, penyalahgunaan harga acuan, ketergantungan scraping PIHPS (tidak ada API resmi), keandalan data BMKG, dan privasi lokasi. Bagian 6 dan 7 proposal tidak ada (loncat dari 5 ke 8).

#### F-25 [R] Pilihan tema tidak jelas
Bagian 2 menampilkan tiga tema sebagai daftar tanpa penanda pilihan.

### 3.5 Ringkasan keparahan
| Keparahan | ID |
|---|---|
| Kritis (8) | F-01, F-02, F-03, F-05, F-08, F-09, F-11, F-18 |
| Penting | F-04, F-06, F-07, F-10, F-12, F-13, F-14, F-15, F-16, F-17, F-19, F-20, F-21, F-22, F-24 |
| Rendah | F-23, F-25 |

---

## 4. Analisis Aktor, Hak Akses, dan Arsitektur

### 4.1 Aktor
| Aktor | Sumber | MVP | Autentikasi |
|---|---|---|---|
| Petani / Kelompok Tani (penjual) | Proposal & brief | Ya | OTP HP (rekomendasi) |
| Penggilingan / Pengolah (pembeli) | Proposal & brief | Ya | OTP HP |
| Warga / Konsumen | Proposal & brief | Ya (publik) | Tanpa login |
| Admin | Brief saja | Ya (minimal) | Email + sandi |
| Penggiat Petani (pendamping) | Proposal saja | Ditunda **[KONFIRMASI]** | — |
| Dinas Pangan / Pemda | Proposal & brief | Ekspor CSV saja | — |
| Sistem (job terjadwal) | Brief | Ya | — |

### 4.2 Matriks hak akses awal **[REKOMENDASI]**
| Fungsi | Publik | Petani | Penggilingan | Admin |
|---|---|---|---|---|
| Lihat Papan Harga 2 Sisi | ✔ | ✔ | ✔ | ✔ |
| Lihat Peta Publik | ✔ | ✔ | ✔ | ✔ |
| Lihat harga wajar dan prakiraan | ✔ (provinsi) | ✔ | ✔ | ✔ |
| Daftar/login | — | ✔ | ✔ | ✔ |
| Buat, ubah, tarik listing | — | ✔ (milik sendiri) | — | ✔ (moderasi) |
| Telusur katalog | — | ✔ (lihat) | ✔ | ✔ |
| Ajukan pesanan | — | — | ✔ | — |
| Setujui/tolak/negosiasi kontrak | — | ✔ (kontrak sendiri) | ✔ (kontrak sendiri) | — |
| Lihat Dasbor Produsen | — | — | ✔ | ✔ |
| Kelola parameter (HPP, δ, rendemen) | — | — | — | ✔ |
| Jalankan ulang data/model | — | — | — | ✔ |
| Ekspor CSV ringkasan | ✔ | ✔ | ✔ | ✔ |

### 4.3 Arsitektur MVP yang direkomendasikan
```
[React + Inertia]  ──  [Laravel monolit: Auth, Katalog, Kontrak, Papan Harga, Peta, Dasbor, Admin]
                                  │
                           [PostgreSQL]  ◄── job impor terjadwal (PIHPS/BPS/BMKG, Laravel command atau skrip Python)
                                  ▲
        [Notebook/skrip Python OFFLINE: pelatihan, backtesting, SHAP]
          └─ menulis tabel: forecasts, shap_explanations, fair_price_params
```
- Laravel hanya **membaca** keluaran model dari tabel; tidak ada layanan Python permanen di Railway (kurangi biaya dan titik gagal).
- Layanan Python hanya jika Anda butuh perhitungan ulang saat itu juga (**[KONFIRMASI]** Q-12).
- Komponen A.4 yang **ditunda**: External Forecast API, Feature Store terpisah, pelatihan ulang otomatis, AI Service Gateway.

---

## 5. Phase 2 — Pertanyaan Klarifikasi (Detail)

Setiap butir memuat **pertanyaan → pilihan → default → alasan → dampak jika berbeda**.

### 5.1 KRITIS

#### Q-01 Aturan lampu harga
| Pilihan | Keterangan |
|---|---|
| A. Ambang persen simetris | hijau di [L,U]; kuning ≤δ di luar; merah >δ |
| **B. Asimetris (default)** | **Sisi bawah L:** hijau/kuning/merah. **Sisi atas U:** hijau/kuning saja (tidak pernah merah) |
| C. Berbasis rupiah | δ dalam rupiah per kg |
- **Default:** B, δ = **3%** dari batas terdekat, konfigurasi admin. Merah **tidak memblokir**, tetapi butuh konfirmasi eksplisit + alasan tampil.
- **Alasan:** contoh wireframe 5,26% merah → δ harus <5,26%. Di atas U merugikan pembeli, bukan petani; platform memihak posisi tawar petani.
- **Pertanyaan tambahan:** apakah lampu untuk pembeli dihitung terbalik (merah jika harga jauh di atas U)? Default: **ya, kuning saja**.

#### Q-02 Siklus kontrak dan negosiasi
- **Default:**
  1. Petani menerbitkan listing dengan harga minta (lampu harga tampil).
  2. Produsen memesan di harga itu (kontrak otomatis dibuat) **atau** mengajukan harga balik.
  3. Maksimal **2 putaran** harga balik.
  4. Kontrak kedaluwarsa **7 hari** bila tidak ada persetujuan kedua pihak.
  5. Setelah kedua pihak setuju, status menjadi Disetujui, lalu Selesai (konfirmasi manual).
- **Alasan:** batas putaran mencegah negosiasi tanpa akhir; 7 hari sesuai siklus panen.
- **Pertanyaan:** apakah batas putaran dan lama kedaluwarsa sesuai pengetahuan Pak Bambang tentang praktik lapangan?

#### Q-03 Akun, identitas, privasi
- **Default:** login **nomor HP + OTP**, data minimal: nama, peran, kab/kota, nama kelompok/usaha. **Tanpa NIK.** Persetujuan pemrosesan data eksplisit saat daftar. Lokasi listing hanya sampai **kecamatan**. Nomor HP **tidak** ditampilkan sebelum kontrak disetujui kedua pihak.
- **Pertanyaan:** apakah OTP via SMS/WhatsApp berbiaya diterima? Alternatif tanpa biaya: email + sandi (kurang cocok untuk literasi rendah) atau OTP uji coba statis pada demo.

#### Q-04 Rumus harga wajar dan cakupan komoditas
- **Default:** lihat §6.2. Hanya **GKP**; GKG ditunda. Kadar air >25%: **peringatan**, rentang tidak diubah.
- **Pertanyaan:** apakah juri/Pak Bambang mengharapkan penyesuaian mutu (kadar air/hampa) pada rentang? Bila ya, kami perlu tabel faktor koreksi dari sumber resmi.

#### Q-05 Peran dan hak akses
- **Default:** matriks §4.2. Penggiat petani dan Dinas ditunda.
- **Pertanyaan:** bolehkah pendamping membuat listing atas nama petani? (Berdampak pada persetujuan data dan audit.)

#### Q-06 Definisi "transaksi" dan pelatihan ulang
- **Default:** semua kontrak MVP simulasi (`is_simulated=true`), tidak masuk data latih. Model dilatih hanya dari PIHPS/BPS.
- **Dampak jika berbeda:** bila ingin kontrak pilot (5–10 transaksi, A.10) masuk pelatihan, perlu status Selesai terverifikasi dan aturan outlier.

#### Q-07 Prioritas Prakiraan
- **Default:** Should Have untuk final 26 Nov. Fallback: tampilkan **baseline pekan lalu + pita 80% empiris** jika model tidak menang atas baseline pada backtest.
- **Alasan:** F-06; prakiraan ada di wireframe Beranda sehingga halaman tidak boleh kosong.

### 5.2 PENTING

| ID | Pertanyaan | Default | Dampak |
|---|---|---|---|
| Q-08 | Acuan warna Peta | Selisih terhadap **median nasional**; provinsi tanpa data = abu-abu; GeoJSON 38 provinsi dipetakan ke 34 | Menentukan seed data dan legenda |
| Q-09 | Kanal notifikasi | Dalam aplikasi saja | WA/SMS menambah biaya dan integrasi |
| Q-10 | Aturan listing | 1 listing = 1 kontrak, tanpa pembelian parsial; status: Draf, Terbit, Dipesan, Selesai, Kedaluwarsa, Ditarik | Menentukan skema DB dan UI |
| Q-11 | Cakupan wilayah demo | Seluruh provinsi berdata valid pada Papan Harga/Peta; **demo transaksi fokus Jawa Timur** | Mengurangi beban data dan pengujian |
| Q-12 | Infrastruktur ML | Pelatihan offline, hasil batch ke PostgreSQL | Tanpa layanan Python permanen |

### 5.3 DAPAT DITUNDA
| ID | Pertanyaan | Default |
|---|---|---|
| Q-13 | Format ekspor | CSV ringkasan Papan Harga |
| Q-14 | Bahasa | Indonesia saja |
| Q-15 | Uji SUS | 5–8 responden (sebagian petani/penggiat via dosen pembimbing), skenario 3 tugas |

### 5.4 Informasi yang masih dibutuhkan
1. Status dataset bersih PIHPS dan BPS (lokasi, format, kolom, periode, provinsi yang tersedia).
2. Status kode: repositori Laravel/React, sudah ada atau mulai dari nol.
3. Kapasitas nyata per anggota (jam/minggu) sampai 26 Nov.
4. Rubrik penilaian juri atau kriteria khusus Bootcamp II (10 Nov).
5. Konfirmasi izin penggunaan data PIHPS/BPS/BMKG (ketentuan penggunaan, scraping vs unduhan manual).

---

## 6. Rancangan Awal Aturan Bisnis **[REKOMENDASI — menunggu konfirmasi]**

### 6.1 Lampu harga (Pemeriksa Kontrak dan Estimator)
Definisi: L = batas bawah wajar, U = batas atas wajar, P = harga yang diperiksa (Rp/kg), δ = toleransi (default 3%).

| Kondisi | Warna | Pesan |
|---|---|---|
| L ≤ P ≤ U | **Hijau** | "Dalam rentang wajar" |
| L×(1−δ) ≤ P < L | **Kuning** | "Sedikit di bawah rentang wajar" |
| P < L×(1−δ) | **Merah** | "Jauh di bawah rentang wajar — tinjau ulang" |
| U < P ≤ U×(1+δ) | **Kuning** | "Sedikit di atas rentang wajar" |
| P > U×(1+δ) | **Kuning** *(asimetris; [KONFIRMASI])* | "Di atas rentang wajar — pastikan mutu dan syarat" |

Contoh uji: L=6.650, U=6.940, δ=3%.
| P | Hasil |
|---|---|
| 6.800 | Hijau |
| 6.500 | Kuning (selisih 2,26%) |
| 6.300 | **Merah (5,26%)** — cocok dengan wireframe |
| 7.000 | Kuning |
| 7.500 | Kuning |

### 6.2 Harga wajar GKP (Tahap 1)
```
Untuk provinsi p, pekan t:
  Pberas(p,t)  = harga beras medium I tingkat produsen (PIHPS)
  R            = 0,5338                       # rendemen GKP→beras (BPS SKGB 2018) [DISEPAKATI proposal]
  rasio(p)     = P_GKP_aktual / (Pberas × R)  # historis 2022–2025 per provinsi
  Titik tengah = Pberas × R × median(rasio)
  L            = Pberas × R × persentil10(rasio)
  U            = Pberas × R × persentil90(rasio)
```
- Parameter `R` dan persentil dikelola admin, bukan hardcode.
- Peringatan: rendemen 2018 mungkin sudah usang → tampilkan sebagai "acuan".
- Keluaran harus menyertakan komponen (untuk penjelasan): Pberas, R, rasio, tanggal data.
- **Pengujian:** hitung ulang L dan U atas data 2022–2025 dan laporkan proporsi pengamatan GKP yang jatuh dalam [L,U] (target diusulkan 70–90%, **[KONFIRMASI]**).

### 6.3 Siklus status listing dan kontrak
**Listing:** `Draf → Terbit → Dipesan → Selesai`; cabang: `Terbit → Ditarik`, `Terbit → Kedaluwarsa`, `Dipesan → Terbit` (jika kontrak batal/ditolak).

**Kontrak:**
```
Draf ──kirim──► Menunggu_Persetujuan ──setuju kedua pihak──► Disetujui ──konfirmasi──► Selesai
                    │  ▲                                          │
                    │  └──harga balik (maks 2)                    └──dibatalkan sebelum Selesai──► Dibatalkan
                    ├──ditolak──► Ditolak
                    └──7 hari──► Kedaluwarsa
```
| Transisi | Pelaku | Syarat |
|---|---|---|
| Draf → Menunggu | Produsen (membuat pesanan) | Listing berstatus Terbit |
| Menunggu → Disetujui | Kedua pihak | Dua persetujuan; checklist 3 poin wireframe dicentang |
| Menunggu → Menunggu (harga balik) | Salah satu pihak | Putaran <2; harga baru diperiksa lampu |
| Menunggu → Ditolak | Salah satu pihak | — |
| Menunggu → Kedaluwarsa | Sistem | Lewat 7 hari |
| Disetujui → Selesai | Kedua pihak | Konfirmasi manual (tanpa pembayaran) |
| Disetujui → Dibatalkan | Salah satu pihak | Alasan wajib |

### 6.4 Aturan Papan Harga 2 Sisi
- Tingkat: Petani (ekuivalen beras), Penggilingan, Pedagang Besar, Eceran.
- **Bagian petani** = harga ekuivalen beras petani ÷ harga eceran. Sumber setiap tingkat dicatat di §8.3.
- Selalu tampilkan catatan: "Harga gabah dan beras berbeda; bandingkan setara."
- Pembanding tidak langsung: selisih (Rp/kg dan %) tingkat Petani → Eceran.

### 6.5 Aturan Peta Publik
- Metrik: selisih terhadap **median nasional**; disparitas keseluruhan = (maks − min) ÷ min.
- Kelas: A <20%, B 20–30%, C 30–40%, D >40% (sesuai wireframe).
- Provinsi tanpa data: abu-abu + keterangan. Tidak menampilkan lokasi individu.

### 6.6 Definisi "langkah" (kriteria ≤5)
Satu langkah = satu layar atau satu aksi yang mengubah status.
| Peran | Alur | Langkah |
|---|---|---|
| Petani | Beranda → Jual hasil panen (detail) → Tinjau tawaran → Kirim | 3 (+ masuk) |
| Produsen | Telusur katalog → Pilih listing/pesan → Tinjau kontrak → Setujui | 4 |
| Siklus lengkap (katalog sampai kontrak disetujui kedua pihak) | — | **≤5 langkah per peran** |

### 6.7 Aturan data dan kualitas
- Provinsi anomali (Riau, NTB pada data produsen) disaring dan ditandai.
- Tampilkan umur data ("diperbarui pekan …") di setiap halaman harga.
- Prioritas komoditas: Beras Medium I (dan Super II bila tersedia); Super I tidak dipakai (data kosong).

---

## 7. Phase 3 — Definisi Lingkup MVP

### 7.1 Matriks prioritas fitur
Estimasi usaha: S = ≤1 hari, M = 2–3 hari, L = 4–6 hari (satu orang).

| # | Fitur | Prioritas | Tenggat | Usaha | Alasan | Ketergantungan |
|---|---|---|---|---|---|---|
| 1 | Pipeline data PIHPS/BPS bersih + tabel `price_observations` | **Must** | 10 Nov | L | Fondasi semua AI dan papan harga | Q-11, izin data |
| 2 | Auth OTP/akun, peran | **Must** | 10 Nov | M | Semua transaksi butuh identitas | Q-03 |
| 3 | Estimator harga wajar Tahap 1 | **Must** | 10 Nov | M | Inti nilai produk | #1, §6.2 |
| 4 | Lampu harga (a) | **Must** | 10 Nov | S | Output paling terlihat | #3, Q-01 |
| 5 | Papan Harga 2 Sisi | **Must** | 10 Nov | M | Transparansi rantai harga | #1 |
| 6 | Katalog dan listing petani | **Must** | 16 Nov | M | Dasar transaksi | #2, #3, Q-10 |
| 7 | Kontrak simulasi + pemeriksa harga | **Must** | 26 Nov | L | Alur inti ≤5 langkah | #4, #6, Q-02 |
| 8 | SHAP dasar (pada prakiraan) / penjelasan komponen rumus | **Must (versi ringan)** | 26 Nov | M | Transparansi AI | #3 |
| 9 | Peta Publik | **Must** | 26 Nov | M | Disparitas antardaerah | #1, Q-08 |
| 10 | Dasbor Produsen (ringkas) | **Must** | 26 Nov | M | Nilai bagi pembeli | #6, #7 |
| 11 | Panel Admin minimal (parameter, moderasi) | Should→**Must ringan** | 26 Nov | S | Mengelola HPP, δ, rendemen | — |
| 12 | Prakiraan 1–4 pekan + pita 80% | **Should** | 26 Nov | L | Differensiator; risiko akurasi | #1, Q-07 |
| 13 | Notifikasi dalam aplikasi | **Should** | 26 Nov | S | Peringatan harga | #3 |
| 14 | Ekspor CSV ringkasan | **Should** | 26 Nov | S | Jembatan untuk Dinas | #5 |
| 15 | Retraining otomatis | **Could** | Pasca-MVP | L | Butuh data transaksi nyata | Q-06 |
| 16 | Peringatan dini lonjakan | **Could** | Pasca-MVP | M | Target metrik, bukan fitur | #12 |
| 17 | Multibahasa | **Could** | Pasca-MVP | M | Tidak kritis | — |
| 18 | Langganan, gateway pembayaran | **Out of Scope** | — | — | Dikecualikan brief | — |
| 19 | Logistik/pengiriman | **Out of Scope** | — | — | Dikecualikan brief | — |
| 20 | Verifikasi mutu laboratorium | **Out of Scope** | — | — | Dikecualikan brief | — |
| 21 | External Forecast API untuk Dinas | **Could** | Pasca-MVP | M | Konsumen API belum ada | #12 |

### 7.2 Rencana mundur dari tenggat (usulan, bergantung konfirmasi §5.4)
| Periode | Sasaran |
|---|---|
| 29 Okt – 2 Nov | Konfirmasi Q-01…Q-07; dataset bersih; skema DB; kerangka Laravel + Inertia; auth |
| 3 – 7 Nov | Estimator Tahap 1; lampu harga; Papan Harga 2 Sisi; backtest baseline awal; UI Beranda |
| 8 – 10 Nov | Integrasi, data nyata (bukan ilustrasi), pengumpulan **prototipe 10 Nov** |
| 11 – 15 Nov | Katalog + listing; baseline vs model prakiraan; draf kontrak |
| 16 – 22 Nov | Kontrak simulasi dan pemeriksa; Peta; Dasbor Produsen; SHAP; notifikasi |
| 23 – 26 Nov | Backtesting final; uji SUS; perbaikan bug; laporan |
| 26 – 28 Nov | Final Hackathon |

### 7.3 Pemetaan peran tim
| Anggota | Peran proposal | Fokus MVP |
|---|---|---|
| Adelio Rais Fikri | Pengembang aplikasi dan pengujian | UI React/Inertia, Papan Harga, Peta, uji SUS |
| Mohammad Rizki Syahputra | AI/Data Scientist | Pipeline data, estimator, prakiraan, SHAP, backtest |
| Muhammad Reza Hafizzi | Koordinator teknis | Backend Laravel, DB, kontrak, deployment Railway |
| Nugroho Nur Chayo | Bisnis dan hilirisasi | Konten bantuan, narasi, validasi alur dengan dosen |
| Bambang Warsuta | Dosen | Validasi aturan bisnis, akses petani |
| Airlangga Yudiatama | Profesional teknis | Review arsitektur dan kesiapan deployment |

---

## 8. Kerangka Phase 4 — Isi SRS yang Akan Disusun

### 8.1 Struktur dokumen
1. Pendahuluan (tujuan, ruang lingkup, istilah, referensi)
2. Gambaran umum sistem (latar, aktor dan hak akses, lingkungan operasi, batasan, asumsi)
3. Ruang lingkup MVP
4. Kebutuhan fungsional (FR-001, …)
5. Aturan bisnis dan integrasi modul AI
6. Kebutuhan nonfungsional
7. Model data konseptual
8. Integrasi eksternal dan sumber data
9. Diagram alur proses (BPMN/user flow, status kontrak)
10. Kriteria penerimaan sistem
11. Traceability matrix
12. Analisis risiko dan mitigasi

### 8.2 Calon daftar kebutuhan fungsional (draf awal)
| ID | Kebutuhan | Aktor | Prioritas |
|---|---|---|---|
| FR-001 | Registrasi dan login OTP | Petani, Produsen | Must |
| FR-002 | Persetujuan data pribadi saat daftar | Petani, Produsen | Must |
| FR-003 | Beranda petani: harga wajar GKP, HPP, prakiraan | Petani | Must |
| FR-004 | Buat listing hasil panen (draf, terbit) | Petani | Must |
| FR-005 | Hitung rentang harga wajar dan lampu saat input harga | Sistem | Must |
| FR-006 | Telusur dan saring katalog | Produsen | Must |
| FR-007 | Buat pesanan dan kontrak draf otomatis | Produsen | Must |
| FR-008 | Periksa harga kontrak (lampu + alasan) | Sistem | Must |
| FR-009 | Negosiasi harga balik (maks 2 putaran) | Petani, Produsen | Must |
| FR-010 | Persetujuan dua pihak dan bukti kesepakatan | Petani, Produsen | Must |
| FR-011 | Papan Harga 2 Sisi dan bagian petani | Semua | Must |
| FR-012 | Peta Publik selisih antarprovinsi + tabel | Semua | Must |
| FR-013 | Dasbor Produsen (pasokan, rentang, kontrak aktif) | Produsen | Must |
| FR-014 | Penjelasan harga wajar (komponen rumus) | Semua | Must |
| FR-015 | Prakiraan 1–4 pekan + pita 80% | Semua | Should |
| FR-016 | Penjelasan SHAP prakiraan | Semua | Should |
| FR-017 | Notifikasi dalam aplikasi | Petani | Should |
| FR-018 | Ekspor CSV ringkasan | Semua | Should |
| FR-019 | Kelola parameter (HPP, δ, rendemen) | Admin | Must |
| FR-020 | Impor dan validasi data harga | Admin/Sistem | Must |
| FR-021 | Moderasi listing | Admin | Should |
| FR-022 | Log audit perubahan status kontrak | Sistem | Must |

Setiap FR dalam SRS akan memuat: aktor, prasyarat, alur utama, alur alternatif, aturan bisnis terkait, dan kriteria penerimaan yang bisa diuji.

### 8.3 Lineage data per tingkat harga **[ASUMSI — perlu verifikasi dengan data tim]**
| Tingkat di Papan Harga | Sumber | Frekuensi | Catatan |
|---|---|---|---|
| Petani (ekuivalen beras) | Turunan: harga wajar GKP ÷ rendemen, atau BPS GKP ÷ rendemen | Mingguan (turunan) / bulanan (BPS) | **Bukan harga yang diamati** |
| Penggilingan | PIHPS pasar produsen, beras medium I | Mingguan | Cakupan 17–28 provinsi |
| Pedagang Besar | PIHPS pedagang besar | Mingguan | Perlu cek ketersediaan |
| Eceran | PIHPS pasar tradisional | Mingguan | 34 provinsi |

### 8.4 Model data konseptual (entitas utama)
| Entitas | Atribut kunci | Relasi |
|---|---|---|
| `users` | id, phone, role, name, province_id, regency_id, consent_at | 1—N listings/contracts |
| `organizations` | id, type (kelompok_tani/penggilingan), name | N—1 users |
| `regions` | id, level, code, name, parent_id | wilayah |
| `commodities` | id, code (GKP, beras_medium_1), name | — |
| `price_observations` | id, commodity_id, region_id, market_level, week_start, price, source, quality_flag | — |
| `hpp_policies` | id, commodity_id, value, valid_from, valid_to, source | — |
| `conversion_params` | id, name (rendemen), value, source, valid_from | — |
| `fair_price_ranges` | id, region_id, week, low, high, mid, components(json), version | — |
| `forecasts` | id, region_id, issue_week, horizon_wk, p10, p50, p90, model_version | — |
| `shap_explanations` | id, forecast_id, feature, contribution | N—1 forecasts |
| `listings` | id, seller_id, volume_kg, moisture_pct, region_id, ask_price, status, harvest_date | N—1 users |
| `contracts` | id, listing_id, buyer_id, price, volume_kg, status, round_count, is_simulated, expires_at | 1—1 listing aktif |
| `contract_events` | id, contract_id, actor_id, from_status, to_status, price, note, at | audit |
| `price_checks` | id, subject (listing/contract), price, low, high, light, reason | — |
| `notifications` | id, user_id, type, payload, read_at | — |
| `settings` | key, value, updated_by | δ, kedaluwarsa, putaran |

---

## 9. Kebutuhan Nonfungsional — Rencana Awal **[REKOMENDASI]**
| Kategori | Kebutuhan | Cara uji |
|---|---|---|
| Keamanan | HTTPS; sandi/OTP di-hash; otorisasi per peran; rate-limit OTP; perlindungan CSRF/XSS | Uji manual dan pemindaian dasar |
| Privasi (UU PDP) | Minimisasi data; persetujuan eksplisit; lokasi sampai kecamatan; HP disembunyikan sebelum kontrak disetujui; hak hapus akun | Review checklist |
| Performa | Halaman utama ≤3 detik pada jaringan 4G; inferensi dari tabel (bukan real-time) | Pengujian waktu muat |
| Akurasi model | MASE ≤0,9 vs baseline per provinsi (target); cakupan 75–85% (target); laporan jujur bila tak tercapai | Backtesting walk-forward |
| Aksesibilitas | Huruf ≥16 px; kontras WCAG AA; ikon + teks; bahasa sederhana; tidak bergantung warna saja (lampu + teks) | Audit dan uji pengguna |
| Usability | Skor SUS ≥68 (target diusulkan) | Uji 5–8 responden |
| Ketersediaan | Deployment Railway; cadangan DB harian | Pemeriksaan operasional |
| Transparansi | Setiap angka AI diberi label "estimasi, bukan jaminan" dan umur data | Review UI |

---

## 10. Integrasi Eksternal dan Sumber Data
| Sumber | Data | Risiko | Mitigasi |
|---|---|---|---|
| PIHPS (Bank Indonesia) | Harga mingguan 34 provinsi | Tidak ada API resmi; ketentuan penggunaan | Unduhan berkala terdokumentasi; ekspor lokal; cek ketentuan |
| BPS | Harga GKP/GKG, rendemen | Frekuensi bulanan/tahunan; 2026 belum terbit | Gunakan 2022–2025; tandai keterbatasan |
| BMKG | ENSO, curah hujan | Format berubah; proyeksi | Fitur sederhana; hindari kebocoran |
| Kebijakan HPP, serapan Bulog, SPHP | Parameter rezim | Perubahan mendadak | Tabel berlaku-tanggal |

---

## 11. Kriteria Penerimaan Sistem **[REKOMENDASI]**
| ID | Kriteria | Cara ukur |
|---|---|---|
| AC-01 | Lampu harga sesuai tabel §6.1 untuk seluruh kasus uji | Uji otomatis |
| AC-02 | Satu siklus simulasi (listing → kontrak disetujui kedua pihak) selesai ≤5 langkah per peran | Uji walkthrough |
| AC-03 | Semua angka di wireframe/demo berasal dari data atau rumus (tidak hardcode) | Review kode dan data |
| AC-04 | Prakiraan: MASE per provinsi dilaporkan; ≥ target atau fallback aktif | Laporan backtest |
| AC-05 | Cakupan interval 80% antara 75–85% pada backtest | Laporan backtest |
| AC-06 | Peta menampilkan semua provinsi berdata dan abu-abu untuk yang kosong | Uji visual |
| AC-07 | SUS ≥68 pada ≥5 responden | Kuesioner |
| AC-08 | Kontrak dengan `is_simulated=true` tidak masuk data latih | Uji data |
| AC-09 | Akses antar-peran dibatasi sesuai §4.2 | Uji otorisasi |
| AC-10 | Setiap perubahan status kontrak tercatat di log audit | Uji otomatis |

---

## 12. Traceability Matrix (awal)
| Tujuan/Kebutuhan sumber | Temuan | FR/AC terkait |
|---|---|---|
| M1 Harga acuan | F-01, F-03, F-18 | FR-003, FR-005, FR-014, AC-01, AC-03 |
| M2 Disparitas antardaerah | F-16, F-17 | FR-012, AC-06 |
| M3 Data menjadi keputusan | F-04, F-05, F-06 | FR-015, FR-016, AC-04, AC-05 |
| Transaksi tanpa komisi, ≤5 langkah | F-08, F-09, F-10 | FR-006…FR-010, AC-02 |
| Closed-loop | F-11 | FR-022, AC-08 |
| Privasi UU PDP | F-21, F-24 | FR-002, NFR Privasi, AC-09 |
| Dasbor Produsen | F-14, F-23 | FR-013, AC-09 |

---

## 13. Register Risiko (diperluas)
| ID | Risiko | Kemungkinan | Dampak | Mitigasi |
|---|---|---|---|---|
| R-01 | Prakiraan tidak mengalahkan baseline kuat | Tinggi | Sedang | Fallback baseline + pita; laporan jujur |
| R-02 | Angka demo tidak konsisten/ilustrasi | Sedang | Tinggi | Semua angka dari data; perbaikan F-03/F-18 |
| R-03 | Data PIHPS tak dapat diakses otomatis | Sedang | Tinggi | Ekspor manual terdokumentasi; snapshot data |
| R-04 | Waktu tidak cukup (12 hari ke prototipe) | Tinggi | Tinggi | Monolit sederhana; cakup Must dulu |
| R-05 | Salah tafsir harga wajar sebagai jaminan | Sedang | Tinggi | Label "estimasi"; alasan dan interval |
| R-06 | Listing palsu atau manipulasi harga | Sedang | Sedang | Moderasi admin; pengecualian simulasi dari model |
| R-07 | Pelanggaran privasi (lokasi, HP) | Rendah | Tinggi | Minimisasi; tampilkan HP setelah setuju |
| R-08 | HPP berubah mendadak | Sedang | Sedang | Tabel kebijakan berlaku-tanggal |
| R-09 | Literasi digital rendah | Tinggi | Sedang | UI sederhana; uji SUS; bantuan |
| R-10 | Cold start dua sisi | Tinggi | Sedang | Data awal gratis; mitra kelompok tani dan penggilingan |
| R-11 | Kebocoran data pada pelatihan (cuaca/ENSO) | Sedang | Sedang | Hanya fitur tersedia saat prakiraan |
| R-12 | Ketergantungan satu orang pada AI/DS | Sedang | Tinggi | Dokumentasi pipeline; pembagian tugas |

---

## 14. Keputusan yang Dibutuhkan (Ringkasan)
Balas dengan **"setuju semua default"** atau koreksi per ID.

| ID | Keputusan | Default |
|---|---|---|
| Q-01 | Aturan lampu harga | Asimetris, δ=3%, merah tidak memblokir |
| Q-02 | Siklus kontrak | 2 putaran, 7 hari, status §6.3 |
| Q-03 | Akun | HP+OTP, tanpa NIK |
| Q-04 | Rumus harga wajar | §6.2; hanya GKP |
| Q-05 | Peran MVP | Petani, Produsen, Admin, Publik |
| Q-06 | Transaksi dan pelatihan | Semua simulasi; tidak masuk pelatihan |
| Q-07 | Prakiraan | Should + fallback baseline |
| Q-08 | Acuan peta | Median nasional |
| Q-09 | Notifikasi | Dalam aplikasi |
| Q-10 | Aturan listing | 1 listing = 1 kontrak |
| Q-11 | Cakupan demo | Jawa Timur untuk transaksi |
| Q-12 | Infrastruktur ML | Offline + batch ke PostgreSQL |
| Q-13 | Ekspor | CSV |
| Q-14 | Bahasa | Indonesia |
| Q-15 | Uji SUS | 5–8 responden |

---

*Tindakan yang sedang dikerjakan: menyusun dokumen review dan klarifikasi yang lebih detail sebagai pendahulu SRS final.*
