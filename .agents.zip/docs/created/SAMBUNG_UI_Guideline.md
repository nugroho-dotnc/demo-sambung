# SAMBUNG — UI Guideline

| | |
|---|---|
| **Versi** | 1.0 (draft untuk disepakati tim) |
| **Berlaku untuk** | Frontend React + Tailwind v4 (`resources/js`, `resources/css/app.css`) |
| **Pembaca** | Developer, desainer, dan asisten AI (file ini dapat disalin ke `.ai/guidelines/ui.md` agar dibaca Laravel Boost) |
| **Tujuan** | Membuat UI SAMBUNG terasa dirancang untuk **petani dan penggilingan padi di Indonesia**, bukan template aplikasi SaaS generik |

> Aturan paling penting: **setiap keputusan visual harus bisa dijelaskan dengan alasan dari domain** (harga gabah, pasar, nota timbangan, literasi digital rendah). Jika satu-satunya alasan adalah "biasanya begitu", itu tanda UI generik.

---

## 1. Diagnosis: yang masih generik di prototipe saat ini

Temuan dari kode awal (`ui.jsx`, `domain.jsx`, halaman publik, dan ruang kerja):

| # | Gejala | Mengapa terasa generik | Arah perbaikan |
|---|---|---|---|
| D1 | Semua blok dibungkus `Card` (border + bayangan + sudut 12 px) | Kartu seragam untuk semua hal menghilangkan hierarki; halaman jadi tumpukan kotak | Pakai kartu hanya untuk objek yang bisa dibuka atau dipilih (§6) |
| D2 | **Hijau merek (#1F5F46) bertabrakan dengan hijau "lampu hijau" (#1E8E5A)** | Pengguna tidak bisa membedakan "ini merek" dari "ini harga wajar"; kontras antar keduanya hanya 1,82:1 | Merek bukan hijau. Hijau dicadangkan untuk status (§4) |
| D3 | Font Plus Jakarta Sans, warna hijau + biru-hitam, `rounded-xl`, `shadow-sm` | Kombinasi paling umum pada UI hasil generator | Font dan palet yang berangkat dari domain (§4, §5) |
| D4 | Landing: hero dua kolom + "Cara kerja" tiga kartu berikon | Pola template yang muncul di hampir semua landing page | Landing berbasis **papan harga nyata** sebagai pusat halaman (§9) |
| D5 | Ikon Lucide di setiap judul, tombol, dan kartu | Ikon dekoratif menambah noise, bukan makna | Ikon hanya bila memperjelas aksi atau status (§8) |
| D6 | Angka harga ditampilkan dengan font yang sama dengan teks biasa | Harga adalah isi utama produk, tetapi tampil seperti label | Angka mendapat perlakuan khusus: tabular, ukuran, tata letak (§5) |
| D7 | Peta kotak 17 provinsi sebagai pengganti peta | Terlihat seperti placeholder; juri akan menganggapnya belum selesai | Peta sungguhan (GeoJSON) atau cartogram yang diberi nama jelas (§7.8) |
| D8 | Penulisan di UI: "Keputusan panen, lebih terarah", "Pasar pertanian yang lebih adil" | Slogan abstrak yang bisa ditempel di produk apa pun | Kalimat konkret berisi angka dan tindakan (§10) |
| D9 | Warna abu-abu dingin (#F3F5F7) di seluruh halaman | Netral dingin terasa korporat dan tidak berkaitan dengan produk | Netral hangat bernuansa kertas (§4) |
| D10 | Seluruh halaman ruang kerja berpola sama: judul + grid kartu | Halaman petani dan penggilingan tidak punya karakter khusus | Setiap halaman punya satu elemen utama yang jelas (§9) |

---

## 2. Arah desain: "Papan Harga Pasar"

**Metafora:** papan tulis harga di pasar, nota timbangan, dan buku catatan tani. Informasi harga ditampilkan **seperti data yang bisa dipercaya dan dibaca cepat**, bukan seperti dasbor teknologi.

Lima prinsip:

1. **Angka adalah bintang.** Harga, rentang, dan selisih tampil paling besar, paling kontras, dan dengan angka tabular. Dekorasi tidak boleh bersaing dengan angka.
2. **Satu layar, satu keputusan.** Setiap layar punya satu pertanyaan yang dijawab (mis. "Apakah harga saya wajar?"). Elemen lain bersifat pendukung.
3. **Lampu adalah bahasa.** Hijau, kuning, dan merah **hanya** berarti status harga. Tidak ada elemen dekoratif yang memakai ketiganya.
4. **Jujur soal ketidakpastian.** Estimasi selalu diberi label, interval, dan umur data. Tidak ada angka AI yang tampil seolah-olah pasti.
5. **Rendah literasi, tinggi hormat.** Bahasa lugas, tombol besar, tidak menggurui, tidak memakai singkatan teknis tanpa penjelasan.

---

## 3. Struktur token (Tailwind v4)

Semua nilai visual **hanya boleh** berasal dari token di `@theme`. Dilarang memakai warna heksa, ukuran piksel, atau bayangan langsung di komponen.

```css
/* resources/css/app.css */
@import "tailwindcss";
@source "../js";

@theme {
  /* Kertas & tinta (netral hangat) */
  --color-paper: #f7f3ea;        /* latar halaman */
  --color-surface: #fffdf8;      /* permukaan terangkat: form, dialog */
  --color-ink: #23201b;          /* teks utama */
  --color-muted: #5e5849;        /* teks sekunder */
  --color-rule: #ddd5c3;         /* garis pemisah dekoratif */
  --color-edge: #8c8370;         /* batas input/kontrol (≥3:1) */

  /* Merek: biru tinta. BUKAN hijau, supaya tidak bentrok dengan lampu */
  --color-tinta: #1e3a5f;
  --color-tinta-hover: #152b47;
  --color-tinta-soft: #e6ebf2;

  /* Status harga — HANYA untuk status */
  --color-ok: #17704a;      --color-ok-bg: #e4f2e8;
  --color-warn: #7a4e00;    --color-warn-bg: #fff0c9;
  --color-bad: #b3261e;     --color-bad-bg: #fbe4e1;

  /* Tipografi */
  --font-sans: "Atkinson Hyperlegible Next", ui-sans-serif, system-ui, sans-serif;
  --font-display: "Source Serif 4", ui-serif, Georgia, serif;

  /* Bentuk: satu radius utama, bukan tiga */
  --radius-ctl: 0.5rem;    /* tombol, input */
  --radius-box: 0.25rem;   /* panel, tabel */
}

@layer base {
  html { font-size: 17px; }                       /* dasar sedikit di atas 16 px */
  body { @apply bg-paper font-sans text-ink antialiased; font-variant-numeric: tabular-nums; }
  :focus-visible { outline: 3px solid var(--color-tinta); outline-offset: 2px; }
}

@utility num-xl { font-family: var(--font-display); font-size: clamp(2.25rem, 8vw, 3.5rem); line-height: 1; font-weight: 600; letter-spacing: -0.01em; font-variant-numeric: tabular-nums lining-nums; }
@utility num-lg { font-family: var(--font-display); font-size: 1.75rem; line-height: 1.1; font-weight: 600; font-variant-numeric: tabular-nums lining-nums; }
@utility rule { border-top: 1px solid var(--color-rule); }
```

### Kontras yang sudah dihitung (WCAG 2.x)

| Pasangan | Rasio | Syarat |
|---|---|---|
| ink di atas paper | 14,7:1 | ≥4,5 ✓ |
| muted di atas paper / surface | 6,4 / 7,0 | ≥4,5 ✓ |
| putih di atas tinta | 11,5 | ≥4,5 ✓ |
| ok di atas ok-bg | 5,3 | ≥4,5 ✓ |
| warn di atas warn-bg | 6,4 | ≥4,5 ✓ |
| bad di atas bad-bg | 5,4 | ≥4,5 ✓ |
| edge (batas input) di atas surface | 3,7 | ≥3 (komponen UI) ✓ |

Setiap token baru harus lolos hitungan ini sebelum dipakai.

---

## 4. Warna: aturan pemakaian

| Peran | Token | Boleh dipakai untuk | Dilarang |
|---|---|---|---|
| Latar | `paper`, `surface` | Latar halaman dan form | Gradien, pola acak |
| Teks | `ink`, `muted` | Semua teks | Abu-abu lain, opasitas di bawah 70% |
| Aksi utama | `tinta` | Tombol utama, tautan, fokus | Dekorasi |
| **Status** | `ok`, `warn`, `bad` | **Hanya** lampu harga, status kontrak, validasi | Ikon dekoratif, tombol merek, latar bagian |
| Garis | `rule` (dekoratif), `edge` (kontrol) | Pemisah dan batas input | Bayangan untuk memisahkan |

Aturan tambahan:

- **Merah bukan error biasa.** Pada SAMBUNG, merah berarti "jauh di bawah rentang wajar". Untuk galat form gunakan teks + ikon + pesan jelas, bukan latar merah penuh.
- Hanya **satu warna aksen** (`tinta`) per layar. Jika ada dua tombol penting, yang kedua memakai gaya garis (outline), bukan warna lain.
- Jangan membuat varian warna "kreatif" (ungu, teal, gradien) di luar token.

---

## 5. Tipografi

| Fungsi | Font | Ukuran | Catatan |
|---|---|---|---|
| Teks dan kontrol | Atkinson Hyperlegible Next | 17 px dasar, 15 px minimal untuk keterangan | Dirancang untuk keterbacaan; cocok untuk literasi rendah |
| Judul halaman | Source Serif 4 | 28–36 px | Memberi suasana "koran/nota", bukan SaaS |
| Angka harga | Source Serif 4, `num-xl` / `num-lg` | 28–56 px | **Selalu** tabular dan lining |
| Kode/ID kontrak | Font sans, tabular | 14 px | |

Aturan:

1. **Angka harga selalu memakai `num-xl` atau `num-lg`** dan satuan `/kg` dengan ukuran lebih kecil di sebelahnya.
2. Format Indonesia: `Rp6.650`, rentang dengan tanda en dash (`Rp6.650–6.940`), desimal koma (`83,1%`). Gunakan `lib/format.js`, jangan format manual.
3. Maksimal **dua keluarga font** dan tiga bobot. Jangan memakai bobot `extrabold` untuk semua judul.
4. Panjang baris teks bacaan 45–70 karakter. Paragraf lebih panjang dibungkus `max-w-prose`.
5. Dilarang huruf kapital semua untuk kalimat. Boleh untuk label pendek (eyebrow) dengan jarak huruf.
6. **Verifikasi ketersediaan font** di Google Fonts sebelum rilis. Siapkan fallback sistem dan `font-display: swap`; jaringan petani lambat.

---

## 6. Tata letak dan kedalaman

**Kartu bukan default.** Pilih berdasarkan tujuan:

| Kebutuhan | Pakai | Hindari |
|---|---|---|
| Daftar baris data (tawaran, kontrak, harga) | **Baris berdivider** (`rule`) seperti buku besar | Kartu per baris |
| Satu angka penting | **Blok tanpa bingkai** dengan angka besar dan label kecil | Kartu dengan bayangan |
| Objek yang bisa dibuka (tawaran di katalog) | Kartu bergaris `rule`, tanpa bayangan | Bayangan bertingkat |
| Pemisah bagian | Spasi + judul bagian + `rule` | Kotak berwarna tiap bagian |
| Peringatan penting | Panel dengan garis kiri tebal berwarna status + teks | Banner penuh berwarna |

Aturan:

- **Tanpa bayangan** pada konten. Bayangan hanya untuk elemen melayang (menu, dialog).
- **Satu radius**: `radius-ctl` untuk kontrol, `radius-box` untuk panel. Jangan memakai `rounded-2xl`.
- Grid: 4 px dasar; jarak antar bagian 32–48 px; jarak antar elemen satu kelompok 8–16 px. Jangan seragam di mana-mana: **kelompokkan dengan jarak**, bukan dengan kotak.
- **Asimetri diperbolehkan.** Kolom kiri yang lebih lebar untuk isi utama, kolom kanan sempit untuk keterangan. Hindari grid tiga kolom sama lebar untuk konten yang tidak sejajar.
- Maksimal satu bagian "hero" per halaman, dan hanya di Landing.
- Mobile-first pada 360 px. Bilah navigasi bawah memakai label teks, bukan ikon saja.

---

## 7. Spesifikasi komponen

### 7.1 Lampu harga (komponen paling penting)

| Aspek | Aturan |
|---|---|
| Bentuk | Lampu sebagai **lingkaran penuh** di kiri (bukan hanya ikon dalam kotak), diikuti judul tebal dan alasan satu kalimat |
| Isi wajib | Warna + ikon (centang / segitiga / silang) + teks ("Dalam rentang wajar") + selisih dalam Rp dan % |
| Perilaku merah | Memperingatkan, **tidak memblokir**; tombol lanjut meminta konfirmasi eksplisit |
| Lokasi | Segera di bawah kolom harga, berubah **langsung** saat angka diketik (di bawah 150 ms) |
| Pembaca layar | `role="status"` dan `aria-live="polite"` |
| Larangan | Lampu tanpa teks; lampu yang hanya memakai warna; lampu merah untuk hal selain harga |

### 7.2 Blok harga wajar (pengganti `FairPriceCard`)

```
Harga wajar GKP · Jawa Timur · pekan ini
Rp6.650–6.940 /kg            ← num-xl
Rentang acuan, bukan jaminan harga jual.
──────────────────────────────────────────
Harga pembelian pemerintah   Rp6.500/kg
Rendemen acuan               53,38%
```

Tanpa bingkai kartu. Pemisah memakai `rule`. Label kecil di atas angka, bukan di bawah.

### 7.3 Tombol

| Jenis | Gaya | Pakai untuk |
|---|---|---|
| Utama | Latar `tinta`, teks putih | Satu aksi terpenting per layar |
| Sekunder | Garis `edge`, latar transparan | Aksi pendukung |
| Bahaya | Garis `bad`, teks `bad` | Tolak, batalkan |

Tinggi ≥48 px, radius `radius-ctl`, teks kata kerja ("Setujui kontrak", bukan "OK"). Tidak ada tombol dengan ikon saja.

### 7.4 Form

- Label **di atas** kolom, selalu terlihat (tidak memakai placeholder sebagai label).
- Satuan di dalam kolom (kg, %, Rp/kg).
- Batas input memakai `edge` (kontras ≥3:1).
- Galat: teks di bawah kolom + ikon + kalimat yang menjelaskan cara memperbaiki.
- Satu pertanyaan utama per langkah pada alur panjang; gunakan bagian bertahap, bukan form panjang.

### 7.5 Status kontrak

Lencana teks pendek dengan titik kecil berwarna (bukan latar penuh). Urutan dan warna:

| Status | Penanda |
|---|---|
| Draf | netral |
| Menunggu persetujuan | `warn` |
| Disetujui | `ok` |
| Selesai | `tinta` |
| Ditolak / Dibatalkan | `bad` |
| Kedaluwarsa | netral (`muted`) |

### 7.6 Tabel dan daftar

- Baris dengan pemisah `rule`, tanpa zebra.
- Angka rata kanan, tabular.
- Pada layar sempit, tabel berubah menjadi daftar dengan label di atas nilai; **tidak menggulir ke samping**.

### 7.7 Grafik

| Aturan | Keterangan |
|---|---|
| Gaya | Garis tipis, tanpa gradien, tanpa bayangan |
| Seri | Dibedakan oleh **gaya garis dan label langsung** di ujung garis, bukan hanya warna |
| Pita ketidakpastian | Warna `tinta-soft`, dengan label "Kemungkinan 80%" |
| Sumbu | Maksimal 4 penanda; angka tabular |
| Interaksi | Dapat dibaca tanpa hover; tersedia ringkasan teks di bawah grafik |

### 7.8 Peta

- Ganti peta kotak dengan **peta provinsi nyata (GeoJSON)** atau cartogram yang diberi keterangan jelas.
- Warna memakai satu skala berurutan (satu hue) untuk jarak dari median; **jangan memakai warna lampu** pada peta.
- Provinsi tanpa data: pola garis diagonal abu-abu + keterangan.
- Selalu sediakan "Lihat sebagai tabel".

### 7.9 Peringatan dan penjelasan AI

- Penjelasan prakiraan memakai frasa **"faktor yang paling memengaruhi"**, bukan "penyebab".
- Setiap angka AI diikuti: *Estimasi · diperbarui [tanggal]*.
- Jangan memakai kata SHAP, quantile, atau MASE di antarmuka pengguna. Boleh di halaman admin dan laporan.

---

## 8. Ikon dan visual

| Aturan | Keterangan |
|---|---|
| Ikon hanya untuk makna | Aksi (tambah, unduh), status (lampu), navigasi bawah. Bukan hiasan judul |
| Gaya | Satu set (Lucide), ketebalan garis 2, ukuran 20 atau 24 px |
| Dilarang | Ikon di dalam kotak berwarna di atas setiap judul; emoji sebagai ikon; ikon berbeda gaya |
| Ilustrasi | Hanya jika benar-benar berasal dari konteks (foto sawah, gabah, timbangan). **Jangan memakai stok foto generik atau ilustrasi vektor orang tersenyum** |
| Foto | Gunakan foto lapangan dari kelompok tani mitra setelah mendapat izin; kompres dan beri teks alternatif |
| Ikon merek | Tunas atau butir gabah sederhana; tidak memakai daun hijau generik |

---

## 9. Pola halaman

### Landing
- **Pusat halaman: papan harga nyata** (harga wajar per provinsi + prakiraan singkat), bukan kalimat slogan.
- Judul memakai satu kalimat konkret, mis. *"Harga wajar GKP Jawa Timur pekan ini: Rp6.650–6.940/kg."*
- Dilarang: hero dua kolom dengan ilustrasi, tiga kartu "Cara kerja" berikon, penghitung statistik palsu, testimoni palsu.
- "Cara kerja" ditulis sebagai daftar bernomor singkat dengan contoh angka nyata.

### Beranda Petani
- Elemen utama: **harga wajar + posisi harga saya**.
- Urutan: harga wajar → arah harga (grafik) → tindakan berikutnya → ringkasan tawaran/kontrak.
- Satu tombol utama: "Jual hasil panen".

### Jual Hasil Panen
- Pertanyaan utama: *"Apakah harga yang saya minta wajar?"*
- Lampu harga menempel dekat kolom harga dan berubah saat mengetik.
- Panel pembanding (rentang, HPP) tetap terlihat di desktop; di HP muncul di atas kolom harga.

### Kontrak
- Pertanyaan utama: *"Apakah saya setuju?"*
- Urutan: pemeriksaan harga → rincian → riwayat → tindakan.
- Tombol "Setujui" tidak aktif sampai tiga centang dipenuhi, dengan penjelasan mengapa.

### Papan Harga dan Peta (publik)
- Dapat dipahami tanpa login dan tanpa penjelasan. Sumber dan umur data selalu terlihat.

### Admin
- Padat dan teknis boleh; gunakan tabel dan formulir rapat. Tetap memakai token yang sama.

---

## 10. Bahasa dan microcopy

| Prinsip | Contoh baik | Contoh buruk |
|---|---|---|
| Konkret dan berangka | "Harga Anda Rp6.300/kg, Rp350 di bawah batas bawah." | "Harga Anda kurang optimal." |
| Kata kerja pada tombol | "Kirim tawaran", "Setujui kontrak" | "Lanjut", "OK", "Submit" |
| Bahasa sehari-hari | "Harga wajar", "tawaran" | "Estimasi kuantil", "listing" |
| Jujur soal batas | "Ini perkiraan, bukan jaminan harga jual." | "Harga terbaik untuk Anda!" |
| Tidak menggurui | "Periksa mutu sebelum menyetujui." | "Anda harus berhati-hati!" |
| Tidak berlebihan | Tanpa tanda seru beruntun | "Luar biasa!!" |

Kata yang **dilarang** di UI pengguna: *revolusi, cerdas, seamless, powerful, platform inovatif, empower, game-changer*. Slogan hanya boleh di satu tempat (header Landing) dan harus tetap konkret.

Istilah baku: **GKP**, **HPP**, **rendemen**, **lampu harga**, **rentang wajar**, **tawaran**, **kontrak simulasi**. Setiap istilah teknis diberi penjelasan singkat pada kemunculan pertama (tooltip yang juga dapat dibuka dengan sentuhan) dan di halaman Bantuan.

---

## 11. Gerak (motion)

- Gerak hanya untuk memberi umpan balik: perubahan lampu harga (transisi warna 150 ms), muncul/hilang panel, status tombol.
- Dilarang: animasi masuk berurutan, efek memantul, parallax, penghitung angka yang bergerak, pemuatan kerangka (skeleton) bergemerlap berlebihan.
- Hormati `prefers-reduced-motion`: matikan semua transisi non-esensial.

---

## 12. Aksesibilitas dan literasi digital rendah

| Aspek | Aturan |
|---|---|
| Ukuran teks | Isi ≥17 px; keterangan ≥15 px; tidak ada teks <14 px |
| Area sentuh | ≥48×48 px, jarak antar target ≥8 px |
| Kontras | Teks ≥4,5:1; kontrol dan batas input ≥3:1 |
| Warna | Informasi tidak boleh hanya berupa warna: wajib ikon + teks |
| Fokus | Cincin fokus 3 px terlihat di semua elemen interaktif |
| Navigasi | Maksimal 3 tingkat; label teks pada navigasi bawah; tidak ada menu tersembunyi di balik ikon |
| Form | Label terlihat, galat spesifik, tidak menghapus isian saat galat |
| Bahasa | Kalimat pendek, satu gagasan per kalimat |
| Pembaca layar | Landmark yang benar (`header`, `nav`, `main`), `aria-live` untuk lampu harga |
| Zoom | Layout tetap berfungsi pada zoom 200% |
| Kinerja | Halaman utama dapat dipakai pada 4G lambat: font terbatas, tanpa pustaka grafik berat, gambar dikompres |

---

## 13. Daftar periksa "bukan AI slop"

Sebelum menggabungkan perubahan UI, jawab semua pertanyaan ini. Satu jawaban "ya" pada bagian merah berarti ubah dulu.

**Tanda bahaya (harus TIDAK ada):**
- [ ] Gradien ungu/biru/hijau pada latar atau tombol
- [ ] Hero dua kolom dengan ilustrasi generik
- [ ] Tiga kartu berikon sejajar sebagai "fitur" atau "cara kerja"
- [ ] Ikon di dalam kotak berwarna sebagai hiasan judul
- [ ] Bayangan bertingkat atau efek kaca (glassmorphism)
- [ ] Semua blok berupa kartu bersudut besar yang identik
- [ ] Emoji sebagai ikon atau penekanan
- [ ] Teks slogan abstrak tanpa angka atau tindakan
- [ ] Statistik, testimoni, atau logo mitra yang dibuat-buat
- [ ] Stok foto generik atau ilustrasi vektor orang
- [ ] Warna di luar token, atau lebih dari satu aksen per layar
- [ ] Lampu hijau/kuning/merah dipakai untuk dekorasi

**Tanda baik (harus ADA):**
- [ ] Angka harga adalah elemen terbesar di layar yang menampilkannya
- [ ] Ada satu pertanyaan utama yang dijawab per layar
- [ ] Estimasi AI diberi label, interval, dan umur data
- [ ] Bahasa konkret dan berangka
- [ ] Hierarki dibentuk oleh jarak dan ukuran, bukan oleh kotak
- [ ] Dapat dipakai dengan satu tangan di layar 360 px
- [ ] Lampu harga terbaca tanpa warna (ikon + teks)

---

## 14. Rencana refactor berdasarkan prioritas

| Prioritas | Pekerjaan | Berkas utama | Hasil yang diharapkan |
|---|---|---|---|
| **P0** | Ganti token: paper, tinta, lampu terpisah dari merek | `app.css` | Tidak ada tabrakan hijau merek vs hijau lampu |
| **P0** | Tipografi angka (`num-xl`/`num-lg`) dan font baru | `app.css`, `index.html`, `blade` | Harga menjadi pusat visual |
| **P0** | Ganti `FairPriceCard` menjadi blok harga tanpa kartu | `components/domain.jsx` | Beranda dan Landing langsung berubah |
| **P0** | Lampu harga sebagai lingkaran + teks + selisih | `components/domain.jsx` | Komponen inti terasa khas |
| **P1** | Hapus pembungkus `Card` untuk daftar; pakai baris berdivider | `Listings`, `Contracts`, `Notifications`, `Catalog` | Hierarki jelas |
| **P1** | Landing berbasis papan harga nyata | `pages/public/Landing.jsx` | Tidak mirip template |
| **P1** | Peta provinsi nyata | `pages/public/PublicMap.jsx` | Tidak terlihat placeholder |
| **P2** | Microcopy: ganti slogan dan tombol generik | semua halaman | Bahasa konkret |
| **P2** | Grafik: label langsung, ringkasan teks | `domain.jsx`, `PriceBoard.jsx` | Terbaca tanpa warna |
| **P3** | Foto lapangan dan ikon merek | `public/`, `Layouts.jsx` | Identitas khas |

### Contoh refactor P0 (sebelum → sesudah)

**Sebelum** (`FairPriceCard`, generik):
```jsx
<Card>
  <p className="text-sm font-semibold text-muted">{title} · {data.province}</p>
  <p className="mt-1 text-3xl font-extrabold text-brand-600">…</p>
```

**Sesudah** (blok harga tanpa kartu):
```jsx
export function FairPriceBlock({ data, title = 'Harga wajar GKP' }) {
  return (
    <section aria-labelledby="fp">
      <p id="fp" className="text-sm text-muted">{title} · {data.province} · pekan ini</p>
      <p className="num-xl text-ink">
        {rp(data.low)}–{data.high.toLocaleString('id-ID')}
        <span className="ml-1 font-sans text-lg font-normal text-muted">/kg</span>
      </p>
      <p className="mt-1 text-sm text-muted">Rentang acuan, bukan jaminan harga jual.</p>
      <dl className="rule mt-4 grid grid-cols-2 gap-4 pt-4 text-sm">
        <div><dt className="text-muted">Harga pembelian pemerintah</dt><dd className="font-semibold">{rpKg(data.hpp)}</dd></div>
        <div><dt className="text-muted">Rendemen acuan</dt><dd className="font-semibold">{(data.rendemen * 100).toFixed(2).replace('.', ',')}%</dd></div>
      </dl>
    </section>
  );
}
```

**Lampu harga** (lingkaran + teks + selisih):
```jsx
const LAMP = {
  green:  { dot: 'bg-ok',   box: 'border-ok bg-ok-bg text-ok',     mark: '✓' },
  yellow: { dot: 'bg-warn', box: 'border-warn bg-warn-bg text-warn', mark: '!' },
  red:    { dot: 'bg-bad',  box: 'border-bad bg-bad-bg text-bad',   mark: '✕' },
};
export function PriceLamp({ result }) {
  if (!result) return null;
  const l = LAMP[result.light];
  return (
    <div role="status" aria-live="polite" className={`flex items-start gap-3 border-l-4 p-3 ${l.box}`} style={{ borderRadius: 'var(--radius-box)' }}>
      <span aria-hidden className={`mt-0.5 grid size-7 shrink-0 place-items-center rounded-full text-base font-bold text-white ${l.dot}`}>{l.mark}</span>
      <div><p className="font-semibold">{result.title}</p><p className="text-sm">{result.reason}</p></div>
    </div>
  );
}
```

**Daftar tawaran** (baris berdivider, bukan kartu):
```jsx
<ul className="rule">
  {data.map((l) => (
    <li key={l.id} className="rule flex flex-wrap items-baseline justify-between gap-2 py-4">
      <div><p className="font-semibold">{l.seller}</p><p className="text-sm text-muted">{l.region} · siap {dateId(l.harvest)}</p></div>
      <p className="num-lg">{rp(l.ask)}<span className="text-sm font-normal text-muted">/kg</span></p>
    </li>
  ))}
</ul>
```

---

## 15. Definisi selesai untuk perubahan UI

Setiap PR UI harus memenuhi:

1. Hanya memakai token dari `@theme`; tidak ada heksa atau ukuran piksel langsung.
2. Lolos §13 (daftar periksa bukan AI slop).
3. Diuji pada lebar **360 px** dan **1280 px**, serta zoom 200%.
4. Lampu harga dan status terbaca tanpa warna.
5. Seluruh teks pengguna dalam bahasa Indonesia yang konkret; tidak ada istilah teknis AI.
6. Navigasi keyboard berjalan; fokus terlihat.
7. Data ilustrasi diberi penanda "Data ilustrasi" selama masih di tahap demo.
8. Tangkapan layar sebelum/sesudah dilampirkan pada PR.

## 16. Hal yang masih perlu dikonfirmasi tim

1. **Font akhir:** verifikasi Atkinson Hyperlegible Next dan Source Serif 4 di Google Fonts, dan uji kecepatan muat pada jaringan lambat.
2. **Warna merek biru tinta:** setujui perubahan dari hijau, mengingat logo dan materi lomba mungkin sudah memakai hijau.
3. **Foto lapangan:** apakah kelompok tani mitra bersedia difoto untuk demo.
4. **Peta:** sumber GeoJSON 38 provinsi dan lisensinya.
5. **Slogan:** pilih satu kalimat tetap atau hapus; jangan lebih dari satu.
