# SAMBUNG — Information Architecture (Halaman, Fitur Wajib, dan Alur Navigasi)

| | |
|---|---|
| **Sumber** | Proposal SAMBUNG, Dokumen Review & Klarifikasi (default Q-01…Q-15), dan kamus istilah AI |
| **Status** | DRAFT — mengikuti keputusan default yang belum dikonfirmasi |
| **Gambar** | `IA_01…IA_08.png` (diagram di bawah juga tersedia sebagai kode Mermaid yang dapat disunting) |

**Legenda warna:** hijau = Must Have · kuning = Should Have · abu putus-putus = Could Have / ditunda · biru-hitam = halaman pusat (hub). Panah bergaris putus = alur opsional atau ditunda.

## 0. Koreksi dari review sebelumnya
Kamus Anda menunjukkan contoh: beras produsen Rp13.400 × 0,5338 = Rp7.153; × 93% dan 97% = **Rp6.652–6.938 ≈ Rp6.650–6.940**. Jadi rumus A.7 **bisa** menghasilkan rentang wireframe. Temuan F-03 saya revisi: masalahnya bukan rumus, tetapi **Papan Harga di wireframe menampilkan Penggilingan Rp14.380, bukan Rp13.400** yang dipakai sebagai masukan. Satu sumber angka "harga beras produsen" harus ditetapkan (Papan Harga dan Estimator harus memakai angka yang sama).

## 1. Prinsip IA
1. **Tiga lapis akses:** Publik (tanpa login) → Ruang kerja berperan (Petani, Penggilingan) → Panel Admin. Pendamping dan Dinas ditunda.
2. **Satu beranda per peran**, berfungsi sebagai pusat; semua fitur dicapai maksimal 2 klik dari beranda.
3. **Halaman bersama** (Papan Harga, Peta, Notifikasi, Profil) dibuka dari semua beranda, bukan diduplikasi.
4. **Alur transaksi** memakai satu objek bersama, yaitu **Kontrak**, yang dibuka dari sisi petani maupun produsen.
5. Setiap angka AI membawa label *estimasi, bukan jaminan* dan *umur data*.

## 2. Peta Situs Tingkat Atas (Landing → Login → Beranda per aktor)
![IA_01](IA_01.png)

```mermaid
flowchart LR
L["<b>LANDING PAGE</b><br/>• Hero + tombol Masuk / Daftar<br/>• Harga wajar GKP ringkas (provinsi)<br/>• Cara kerja 3 langkah<br/>• Mini Papan Harga + mini Peta<br/>• Label estimasi + umur data"]:::hub
L -->|"Lihat harga"| PUB1["Papan Harga 2 Sisi<br/>(publik)"]:::must
L -->|"Lihat peta"| PUB2["Peta Publik<br/>selisih antarprovinsi"]:::must
L -->|"Cek harga wajar"| PUB3["Harga Wajar & Prakiraan<br/>per provinsi (publik)"]:::should
L -->|"Pelajari"| PUB4["Cara Kerja, Bantuan,<br/>Privasi & Syarat"]:::must
L -->|"Masuk / Daftar"| LOGIN{{"Masuk / Daftar"}}:::dec
L -.->|"tautan footer"| ADL["Masuk Admin<br/>email + sandi"]:::must
LOGIN --> OTP["Nomor HP → kode OTP<br/>(daftar baru: pilih peran,<br/>isi profil singkat,<br/>setuju data pribadi)"]:::must
OTP --> ROLE{"Peran akun?"}:::dec
ROLE -->|"Petani / Kelompok Tani"| DT["BERANDA PETANI"]:::must
ROLE -->|"Penggilingan / Pengolah"| DP["DASBOR PRODUSEN"]:::must
ADL --> DA["PANEL ADMIN"]:::must
ROLE -.->|"Pendamping (ditunda)"| DD["DASBOR PENDAMPING"]:::could
ROLE -.->|"Dinas (ditunda)"| DN["RINGKASAN DINAS<br/>+ ekspor"]:::could
PUB1 -->|"Ingin jual/beli"| LOGIN
PUB2 -->|"Ingin jual/beli"| LOGIN
PUB3 -->|"Ingin jual/beli"| LOGIN
classDef must fill:#E6F1EB,stroke:#1F5F46,stroke-width:2px,color:#10281e;
classDef should fill:#FFF6D9,stroke:#B98A00,stroke-width:2px,color:#3a2d00;
classDef could fill:#F1F1F1,stroke:#888,stroke-dasharray:5 4,color:#444;
classDef hub fill:#1B2A3A,stroke:#1B2A3A,color:#fff;
classDef dec fill:#fff,stroke:#1B2A3A,stroke-width:2px;
```

**Landing Page — komponen wajib:** hero + tombol Masuk/Daftar; harga wajar GKP ringkas (provinsi terpilih); cara kerja 3 langkah; mini Papan Harga dan mini Peta; label estimasi dan umur data; tautan footer (Bantuan, Privasi, Syarat, Masuk Admin).

**Alur Masuk/Daftar:** nomor HP → OTP → (akun baru) pilih peran → profil singkat (nama, kab/kota, nama kelompok/usaha) → persetujuan data pribadi → diarahkan ke beranda sesuai peran. Admin memakai halaman masuk terpisah (email + sandi).

## 3. Aktor Publik (Warga / Konsumen / Dinas tanpa login)
![IA_02](IA_02.png)

```mermaid
flowchart LR
subgraph PUBLIK["AKTOR: WARGA / KONSUMEN / DINAS (tanpa login)"]
direction LR
LP["Landing Page"]:::hub
PB["<b>PAPAN HARGA 2 SISI</b><br/>• Filter komoditas, wilayah, periode<br/>• 4 tingkat: Petani(ekuivalen), Penggilingan,<br/>  Pedagang Besar, Eceran<br/>• Bagian harga petani (%) + selisih Rp<br/>• Grafik 12 pekan<br/>• Catatan 'gabah ≠ beras'<br/>• Unduh ringkasan CSV"]:::must
PM["<b>PETA PUBLIK</b><br/>• Peta provinsi, 4 kelas selisih (A–D)<br/>• Termurah / termahal / selisih %<br/>• Provinsi tanpa data = abu-abu<br/>• Kartu provinsi (harga, selisih, umur data)<br/>• Tombol 'Lihat sebagai tabel'<br/>• Banner 'Mengapa harga berbeda?'"]:::must
PT["Tampilan Tabel Peta<br/>(aksesibel)"]:::must
PK["<b>HARGA WAJAR & PRAKIRAAN</b><br/>• Rentang wajar GKP per provinsi<br/>• Prakiraan 1–4 pekan + pita 80%<br/>• 'Faktor yang memengaruhi'"]:::should
PH["<b>CARA KERJA & BANTUAN</b><br/>• Cara membaca lampu harga<br/>• Arti istilah (GKP, HPP, rendemen)<br/>• Batas: estimasi, bukan jaminan<br/>• Privasi (UU PDP) & Syarat"]:::must
PD["Detail Provinsi<br/>(kartu/halaman)"]:::must
LP --> PB
LP --> PM
LP --> PK
LP --> PH
PM -->|"Lihat tabel"| PT
PM -->|"Sentuh provinsi"| PD
PD -->|"Lihat rantai harga provinsi"| PB
PD --> PK
PB -->|"Unduh"| CSV["File CSV ringkasan"]:::should
PK -->|"Istilah?"| PH
PB -->|"Istilah?"| PH
end
PB -->|"Ingin jual/beli"| LG["Masuk / Daftar"]:::hub
PM --> LG
classDef must fill:#E6F1EB,stroke:#1F5F46,stroke-width:2px,color:#10281e;
classDef should fill:#FFF6D9,stroke:#B98A00,stroke-width:2px,color:#3a2d00;
classDef could fill:#F1F1F1,stroke:#888,stroke-dasharray:5 4,color:#444;
classDef hub fill:#1B2A3A,stroke:#1B2A3A,color:#fff;
classDef dec fill:#fff,stroke:#1B2A3A,stroke-width:2px;
```

## 4. Aktor Petani / Kelompok Tani
![IA_03](IA_03.png)

```mermaid
flowchart LR
IN["Masuk (OTP)"]:::hub --> B
B["<b>BERANDA PETANI</b><br/>• Kartu Harga Wajar GKP (rentang, wilayah)<br/>• Harga pembelian pemerintah (HPP) + rendemen<br/>• Prakiraan 1–4 pekan + pita 80%<br/>• 'Mengapa prakiraan naik?' (faktor)<br/>• Banner peringatan harga naik/turun<br/>• Ringkasan: tawaran terbit, pesanan masuk,<br/>  kontrak menunggu saya<br/>• Langkah berikutnya (3 tombol)<br/>• Tombol besar: Jual hasil panen<br/>• Lonceng notifikasi"]:::hub
B -->|"Jual hasil panen"| W1
subgraph WIZ["JUAL HASIL PANEN (3 langkah)"]
direction LR
W1["<b>Langkah 1 Detail panen</b><br/>komoditas GKP (terkunci), volume kg,<br/>kadar air %, kecamatan, tgl siap panen,<br/>harga minta Rp/kg<br/>+ LAMPU HARGA langsung & selisih<br/>+ 'Gunakan batas bawah'"]:::must
W2["<b>Langkah 2 Tinjau tawaran</b><br/>ringkasan, nilai kotor,<br/>lampu + alasan;<br/>MERAH: wajib centang konfirmasi"]:::must
W3["<b>Langkah 3 Kirim</b><br/>tawaran terbit di katalog"]:::must
W1 --> W2 --> W3
end
W1 -.->|"Simpan draf"| TS
W3 --> TS
B -->|"kartu harga wajar"| HW["<b>Detail Harga Wajar</b><br/>komponen rumus: harga beras produsen,<br/>rendemen, rasio, tanggal data;<br/>perbandingan dengan HPP"]:::must
B -->|"kartu prakiraan"| PRK["<b>Prakiraan & Penjelasan</b><br/>grafik + pita 80%, faktor pendorong<br/>(+/−), pemakaian: 'bukan jaminan'"]:::should
B -->|"Bandingkan harga"| PBS["Papan Harga 2 Sisi"]:::must
B -->|"Peta"| PMS["Peta Publik"]:::must
B -->|"ringkasan tawaran"| TS["<b>TAWARAN SAYA</b><br/>daftar + status: Draf, Terbit,<br/>Dipesan, Selesai, Kedaluwarsa, Ditarik"]:::must
TS -->|"pilih"| TD["<b>Detail Tawaran</b><br/>data panen, lampu harga,<br/>pesanan masuk, Ubah/Tarik"]:::must
TD -->|"Terima pesanan / lihat"| KD
B -->|"Periksa kontrak"| KL["<b>KONTRAK SAYA</b><br/>daftar + lencana status"]:::must
KL --> KD["<b>DETAIL KONTRAK</b><br/>para pihak, rincian, periode, nilai<br/>PEMERIKSAAN HARGA (lampu + alasan)<br/>riwayat harga balik (putaran x/2)<br/>3 centang sebelum setuju<br/>sisa waktu 7 hari"]:::must
KD -->|"Setujui"| KS["Disetujui kedua pihak<br/>→ nomor HP pembeli terbuka"]:::must
KD -->|"Negosiasi ulang"| NG["Ajukan harga balik<br/>(maks 2 putaran, lampu dicek)"]:::must
KD -->|"Tolak"| KT["Ditolak"]:::must
NG --> KD
KS -->|"Tandai selesai"| BK["<b>Bukti Kesepakatan</b><br/>berlabel SIMULASI"]:::must
B -->|"lonceng"| NT["<b>NOTIFIKASI</b><br/>pesanan baru, harga balik,<br/>kontrak disetujui/kedaluwarsa,<br/>peringatan harga"]:::should
NT --> PR["<b>Pengaturan Peringatan</b><br/>saklar + ambang perubahan %"]:::should
NT -->|"buka"| KD
B -->|"avatar"| PF["<b>PROFIL & PENGATURAN</b><br/>ubah data, persetujuan data,<br/>hapus akun, keluar"]:::must
PRK --> PBS
HW --> W1
classDef must fill:#E6F1EB,stroke:#1F5F46,stroke-width:2px,color:#10281e;
classDef should fill:#FFF6D9,stroke:#B98A00,stroke-width:2px,color:#3a2d00;
classDef could fill:#F1F1F1,stroke:#888,stroke-dasharray:5 4,color:#444;
classDef hub fill:#1B2A3A,stroke:#1B2A3A,color:#fff;
classDef dec fill:#fff,stroke:#1B2A3A,stroke-width:2px;
```

## 5. Aktor Penggilingan / Pengolah (Produsen)
![IA_04](IA_04.png)

```mermaid
flowchart LR
IN["Masuk (OTP)"]:::hub --> B
B["<b>DASBOR PRODUSEN</b><br/>Tab 1 Pasokan sekitar: tabel wilayah, GKP, volume,<br/>'volume ≠ stok terverifikasi'<br/>Tab 2 Rentang harga beli wajar + prakiraan + faktor<br/>Tab 3 Ringkasan kontrak (aktif, menunggu, selesai)<br/>• Kartu: harga beli wajar, kontrak aktif, pemeriksaan<br/>• Filter: komoditas, wilayah, tampilan<br/>• Panel 'Alur pembelian' 3 langkah<br/>• Tombol: Cari pasokan, Kelola penawaran"]:::hub
B -->|"Cari pasokan / Lihat"| KAT["<b>KATALOG PASOKAN</b><br/>filter: wilayah, volume min,<br/>urut terdekat/harga terendah<br/>kartu tawaran + lampu harga<br/>keadaan kosong"]:::must
KAT -->|"pilih tawaran"| DT["<b>DETAIL TAWARAN</b><br/>volume, kadar air, lokasi kecamatan,<br/>catatan mutu (deklarasi petani),<br/>pemeriksaan harga"]:::must
DT -->|"Pesan di harga ini"| KD
DT -->|"Ajukan harga lain<br/>(lampu langsung berubah)"| KD
B -->|"tab Kontrak"| KL["<b>KONTRAK SAYA</b><br/>daftar + status"]:::must
KL --> KD["<b>DETAIL KONTRAK</b><br/>pemeriksaan harga, riwayat harga balik,<br/>centang 3 poin, sisa waktu"]:::must
KD -->|"Setujui"| KS["Disetujui kedua pihak<br/>→ HP penjual terbuka"]:::must
KD -->|"Harga balik (maks 2)"| KD
KD -->|"Tolak / Batalkan"| KT["Ditolak / Dibatalkan<br/>(alasan wajib)"]:::must
KS -->|"Tandai selesai"| BK["Bukti Kesepakatan (SIMULASI)"]:::must
B -->|"tab Rentang harga"| HB["<b>Harga Beli Wajar & Prakiraan</b><br/>rentang, prakiraan 1–4 pekan,<br/>faktor pendorong"]:::should
B -->|"Kelola penawaran"| PN["<b>Penawaran Saya</b><br/>daftar pesanan yang diajukan,<br/>status"]:::must
PN --> KD
B -->|"Bandingkan rantai harga"| PBS["Papan Harga 2 Sisi"]:::must
B -->|"Peta"| PMS["Peta Publik"]:::must
B -->|"Ekspor"| EX["CSV ringkasan"]:::should
B -->|"lonceng"| NT["Notifikasi"]:::should
B -->|"avatar"| PF["Profil usaha & Pengaturan"]:::must
classDef must fill:#E6F1EB,stroke:#1F5F46,stroke-width:2px,color:#10281e;
classDef should fill:#FFF6D9,stroke:#B98A00,stroke-width:2px,color:#3a2d00;
classDef could fill:#F1F1F1,stroke:#888,stroke-dasharray:5 4,color:#444;
classDef hub fill:#1B2A3A,stroke:#1B2A3A,color:#fff;
classDef dec fill:#fff,stroke:#1B2A3A,stroke-width:2px;
```

## 6. Aktor Admin
![IA_05](IA_05.png)

```mermaid
flowchart LR
IN["Masuk Admin<br/>(email + sandi)"]:::hub --> A
A["<b>RINGKASAN ADMIN</b><br/>• Jumlah pengguna per peran<br/>• Listing & kontrak per status<br/>• Status impor data terakhir<br/>• Antrean moderasi & peringatan sistem"]:::hub
A --> P["<b>PARAMETER</b><br/>HPP berlaku-tanggal, rendemen,<br/>toleransi lampu δ, kedaluwarsa kontrak,<br/>maks putaran; catatan alasan ubah"]:::must
A --> D["<b>DATA HARGA</b><br/>status impor PIHPS/BPS/BMKG,<br/>unggah manual, validasi,<br/>provinsi anomali ditandai"]:::must
A --> M["<b>MODERASI LISTING</b><br/>antrean: Setujui / Sembunyikan<br/>laporan listing mencurigakan"]:::should
A --> U["<b>PENGGUNA</b><br/>daftar, ubah status,<br/>reset, hapus data (UU PDP)"]:::must
A --> L["<b>LOG AUDIT</b><br/>perubahan status kontrak,<br/>perubahan parameter"]:::must
A --> MD["<b>MODEL & BACKTESTING</b><br/>versi model, MASE per provinsi,<br/>cakupan interval, publikasi hasil<br/>ke tabel prakiraan"]:::should
A --> V["<b>VALIDASI DATA LATIH</b><br/>transaksi terverifikasi → boleh masuk<br/>pelatihan; simulasi dikecualikan"]:::could
D -->|"hasil impor"| FS["Tabel harga bersih"]:::hub
MD -->|"publikasi"| FP["Tabel prakiraan + SHAP"]:::hub
P -->|"dipakai"| RULE["Aturan lampu & harga wajar<br/>di seluruh aplikasi"]:::hub
V --> MD
classDef must fill:#E6F1EB,stroke:#1F5F46,stroke-width:2px,color:#10281e;
classDef should fill:#FFF6D9,stroke:#B98A00,stroke-width:2px,color:#3a2d00;
classDef could fill:#F1F1F1,stroke:#888,stroke-dasharray:5 4,color:#444;
classDef hub fill:#1B2A3A,stroke:#1B2A3A,color:#fff;
classDef dec fill:#fff,stroke:#1B2A3A,stroke-width:2px;
```

## 7. Aktor Ditunda: Pendamping dan Dinas
![IA_06](IA_06.png)

```mermaid
flowchart LR
subgraph PD["PENDAMPING / PENGGIAT PETANI (ditunda, perlu konfirmasi)"]
direction LR
PD1["<b>DASBOR PENDAMPING</b><br/>petani binaan, tawaran & kontrak mereka"]:::could
PD2["Petani Binaan<br/>(persetujuan data per petani)"]:::could
PD3["Bantu buat tawaran<br/>atas nama petani"]:::could
PD4["Validasi data transaksi<br/>sebelum masuk pelatihan"]:::could
PD1 --> PD2 --> PD3
PD1 --> PD4
end
subgraph DN["DINAS PANGAN / PEMDA (ditunda)"]
direction LR
DN1["<b>RINGKASAN WILAYAH</b><br/>harga wajar, prakiraan,<br/>selisih provinsi"]:::could
DN2["Peringatan Dini Lonjakan<br/>(rekayasa eksperimen)"]:::could
DN3["Ekspor CSV / API prakiraan"]:::could
DN1 --> DN2
DN1 --> DN3
end
classDef must fill:#E6F1EB,stroke:#1F5F46,stroke-width:2px,color:#10281e;
classDef should fill:#FFF6D9,stroke:#B98A00,stroke-width:2px,color:#3a2d00;
classDef could fill:#F1F1F1,stroke:#888,stroke-dasharray:5 4,color:#444;
classDef hub fill:#1B2A3A,stroke:#1B2A3A,color:#fff;
classDef dec fill:#fff,stroke:#1B2A3A,stroke-width:2px;
```

## 8. Siklus Status Listing dan Kontrak
![IA_07](IA_07.png)

```mermaid
stateDiagram-v2
direction LR
state "LISTING (Petani)" as LST {
[*] --> Draf
Draf --> Terbit: Kirim
Terbit --> Dipesan: Produsen memesan
Dipesan --> Terbit: Kontrak ditolak / batal / kedaluwarsa
Dipesan --> Selesai: Kontrak selesai
Terbit --> Ditarik: Petani menarik
Terbit --> Kedaluwarsa: Lewat tanggal siap
}
state "KONTRAK" as KTR {
[*] --> DrafK
DrafK --> Menunggu: Produsen kirim pesanan
Menunggu --> Menunggu: Harga balik
Menunggu --> Disetujui: Kedua pihak setuju
Menunggu --> Ditolak: Ditolak
Menunggu --> KedaluwarsaK: 7 hari tanpa persetujuan
Disetujui --> SelesaiK: Konfirmasi manual
Disetujui --> Dibatalkan: Alasan wajib
}
```

## 9. Hubungan Sumber Data → Modul AI → Halaman yang Menampilkan
![IA_08](IA_08.png)

```mermaid
flowchart LR
subgraph SRC["SUMBER DATA"]
S1["PIHPS<br/>harga mingguan"]:::hub
S2["BPS<br/>GKP/GKG, rendemen"]:::hub
S3["BMKG<br/>ENSO, curah hujan"]:::hub
S4["Kebijakan<br/>HPP, Bulog, SPHP"]:::hub
end
ETL["Impor & validasi<br/>(Admin › Data Harga)"]:::must
BD[("Tabel harga bersih<br/>PostgreSQL")]:::hub
S1 --> ETL
S2 --> ETL
S3 --> ETL
S4 --> ETL
ETL --> BD
BD --> MA["<b>(a) Estimator Harga Wajar</b><br/>Tahap 1 aturan: harga beras produsen<br/>× rendemen × rasio historis (93–97%)"]:::must
BD --> MB["<b>(b) Prakiraan Spasio-Temporal</b><br/>gradient boosting kuantil + baseline + SARIMA<br/>(offline → hasil batch ke tabel)"]:::should
MB --> MC["<b>(c) Penjelas SHAP</b><br/>faktor pendorong prakiraan"]:::should
MA --> MD["<b>(d) Pemeriksa Kontrak</b><br/>aturan lampu atas keluaran (a)<br/>(bukan model ML)"]:::must
MA --> H1["Beranda Petani: kartu harga wajar<br/>Detail Harga Wajar<br/>Landing/Harga Wajar publik"]:::must
MA --> H2["Dasbor Produsen: harga beli wajar"]:::must
MD --> H3["Jual Hasil Panen: lampu live<br/>Tawaran & Katalog: lampu<br/>Detail Kontrak: pemeriksaan harga"]:::must
MB --> H4["Beranda Petani: prakiraan + pita 80%<br/>Dasbor Produsen: prakiraan<br/>Halaman Prakiraan"]:::should
MC --> H5["'Mengapa prakiraan naik?'<br/>Beranda Petani & Dasbor Produsen"]:::should
BD --> H6["Papan Harga 2 Sisi<br/>Peta Publik (selisih vs median nasional)"]:::must
KONTRAK[("Kontrak berlabel SIMULASI")]:::hub -.->|"DIKECUALIKAN dari pelatihan"| MB
KONTRAK2[("Transaksi terverifikasi<br/>(pasca-MVP)")]:::could -.->|"validasi Admin/Pendamping"| MA
classDef must fill:#E6F1EB,stroke:#1F5F46,stroke-width:2px,color:#10281e;
classDef should fill:#FFF6D9,stroke:#B98A00,stroke-width:2px,color:#3a2d00;
classDef could fill:#F1F1F1,stroke:#888,stroke-dasharray:5 4,color:#444;
classDef hub fill:#1B2A3A,stroke:#1B2A3A,color:#fff;
classDef dec fill:#fff,stroke:#1B2A3A,stroke-width:2px;
```

## 10. Inventaris Halaman dan Fitur Wajib

Prioritas: **M** = Must, **S** = Should, **C** = Could/ditunda.

### 10.1 Publik
| ID | Halaman | Pr | Komponen dan fitur wajib | Menuju |
|---|---|---|---|---|
| PB-01 | Landing Page | M | Hero, CTA Masuk/Daftar, harga wajar ringkas, cara kerja, mini papan/peta, label estimasi | PB-02, PB-03, PB-04, PB-05, AU-01 |
| PB-02 | Papan Harga 2 Sisi | M | Filter komoditas/wilayah/periode; 4 tingkat harga; bagian petani (%) dan selisih Rp; grafik 12 pekan; catatan gabah ≠ beras; label sumber tiap tingkat; unduh CSV (S) | PB-05, AU-01 |
| PB-03 | Peta Publik | M | Peta provinsi 4 kelas; termurah/termahal/selisih; abu-abu bila tak ada data; kartu provinsi; tombol tabel; teks "mengapa harga berbeda" (statis pada MVP) | PB-03a, PB-03b, AU-01 |
| PB-03a | Tampilan Tabel Peta | M | Tabel provinsi, harga, selisih vs median, umur data, urut | PB-03 |
| PB-03b | Detail Provinsi | M | Harga, selisih, mini rantai harga | PB-02, PB-04 |
| PB-04 | Harga Wajar & Prakiraan (publik) | S | Rentang wajar GKP per provinsi, prakiraan 1–4 pekan + pita 80%, faktor pengaruh | PB-05, AU-01 |
| PB-05 | Cara Kerja & Bantuan | M | Cara membaca lampu, glosarium (GKP, HPP, rendemen), batas AI, kebijakan privasi, syarat | — |

### 10.2 Autentikasi
| ID | Halaman | Pr | Fitur wajib |
|---|---|---|---|
| AU-01 | Masuk / Daftar | M | Input HP, kirim kode, pesan galat ramah |
| AU-02 | Verifikasi OTP | M | 6 kotak kode, kirim ulang bertimer, batas percobaan |
| AU-03 | Pilih peran + profil | M | Dua kartu peran, form singkat, persetujuan data pribadi (wajib) |
| AU-04 | Masuk Admin | M | Email + sandi, pembatasan percobaan |

### 10.3 Petani
| ID | Halaman | Pr | Komponen dan fitur wajib | Menuju |
|---|---|---|---|---|
| PT-01 | Beranda Petani | M | Kartu harga wajar + HPP + rendemen; prakiraan 1–4 pekan + pita 80% (S); "Mengapa prakiraan naik?" (S); banner peringatan (S); ringkasan tawaran/pesanan/kontrak; langkah berikutnya; tombol Jual hasil panen; lonceng | PT-02, PT-03, PT-05, PT-06, PT-07, PB-02, PB-03, PT-09, PT-10 |
| PT-02 | Jual Hasil Panen (3 langkah) | M | L1: volume, kadar air, kecamatan, tgl siap, harga minta + lampu langsung + "gunakan batas bawah"; L2: tinjau, nilai kotor, centang konfirmasi bila merah; L3: terbit; simpan draf | PT-03 |
| PT-03 | Tawaran Saya | M | Daftar + status (Draf, Terbit, Dipesan, Selesai, Kedaluwarsa, Ditarik); filter status | PT-04 |
| PT-04 | Detail Tawaran | M | Data panen, lampu harga, pesanan masuk, ubah/tarik | PT-06 |
| PT-05 | Kontrak Saya | M | Daftar + lencana status, sisa waktu | PT-06 |
| PT-06 | Detail Kontrak | M | Para pihak, rincian, pemeriksaan harga (lampu + alasan), riwayat harga balik (x/2), 3 centang, tombol Setujui/Negosiasi/Tolak, HP terbuka setelah setuju, Tandai selesai | PT-06a |
| PT-06a | Bukti Kesepakatan | M | Ringkasan, label **SIMULASI**, cetak/unduh | — |
| PT-07 | Detail Harga Wajar | M | Komponen rumus: harga beras produsen, rendemen, rasio, tanggal data; perbandingan HPP | PT-02 |
| PT-08 | Prakiraan & Penjelasan | S | Grafik, pita 80%, faktor pendorong (+/−), tautan Papan Harga | PB-02 |
| PT-09 | Notifikasi + Pengaturan Peringatan | S | Daftar per jenis, belum dibaca, saklar peringatan, ambang % | PT-06 |
| PT-10 | Profil & Pengaturan | M | Ubah data, persetujuan data, hapus akun, keluar |

### 10.4 Penggilingan / Produsen
| ID | Halaman | Pr | Komponen dan fitur wajib | Menuju |
|---|---|---|---|---|
| PR-01 | Dasbor Produsen | M | 3 tab (Pasokan sekitar, Rentang harga beli, Ringkasan kontrak); kartu harga beli wajar, kontrak aktif; filter; panel alur pembelian; tombol Cari pasokan, Kelola penawaran | PR-02, PR-04, PR-05, PR-06, PB-02, PB-03 |
| PR-02 | Katalog Pasokan | M | Filter wilayah/volume/urut; kartu tawaran + lampu; keadaan kosong | PR-03 |
| PR-03 | Detail Tawaran | M | Data, catatan mutu deklarasi, pemeriksaan harga, Pesan / Ajukan harga lain | PR-05 |
| PR-04 | Penawaran Saya | M | Pesanan yang diajukan + status | PR-05 |
| PR-05 | Kontrak (daftar + detail) | M | Sama dengan PT-05/PT-06 dari sisi pembeli | — |
| PR-06 | Harga Beli Wajar & Prakiraan | S | Rentang, prakiraan, faktor | — |
| PR-07 | Ekspor CSV | S | Ringkasan pasokan/harga | — |
| PR-08 | Notifikasi, Profil usaha | S/M | Seperti petani | — |

### 10.5 Admin
| ID | Halaman | Pr | Fitur wajib |
|---|---|---|---|
| AD-01 | Ringkasan | M | Statistik pengguna, listing, kontrak, status impor |
| AD-02 | Parameter | M | HPP berlaku-tanggal, rendemen, δ lampu, kedaluwarsa, maks putaran, alasan ubah |
| AD-03 | Data Harga | M | Status impor, unggah manual, validasi, provinsi anomali |
| AD-04 | Moderasi Listing | S | Setujui/sembunyikan, laporan |
| AD-05 | Pengguna | M | Daftar, status, hapus data |
| AD-06 | Log Audit | M | Status kontrak dan parameter |
| AD-07 | Model & Backtesting | S | Versi model, MASE per provinsi, cakupan interval, publikasi ke tabel prakiraan |
| AD-08 | Validasi Data Latih | C | Transaksi terverifikasi saja; simulasi dikecualikan |

### 10.6 Ditunda
| ID | Aktor | Halaman |
|---|---|---|
| PD-01…03 | Pendamping | Dasbor, petani binaan, bantu buat tawaran, validasi data transaksi |
| DN-01…03 | Dinas | Ringkasan wilayah, peringatan dini, ekspor/API |

## 11. Matriks Akses Halaman
| Halaman | Publik | Petani | Penggilingan | Admin |
|---|---|---|---|---|
| Landing, Papan Harga, Peta, Bantuan | ✔ | ✔ | ✔ | ✔ |
| Beranda Petani, Jual, Tawaran Saya | — | ✔ | — | lihat |
| Katalog, Dasbor Produsen, Penawaran Saya | — | katalog: lihat | ✔ | lihat |
| Kontrak | — | milik sendiri | milik sendiri | lihat + audit |
| Parameter, Data, Pengguna, Log, Model | — | — | — | ✔ |

## 12. Pemetaan Modul AI ke Halaman
| Modul | Tampil di | Catatan MVP |
|---|---|---|
| (a) Estimator harga wajar | PB-01, PB-04, PT-01, PT-02, PT-07, PR-01, PR-06 | Tahap 1 berbasis aturan |
| (b) Prakiraan | PB-04, PT-01, PT-08, PR-01, PR-06 | Should; fallback baseline + pita |
| (c) SHAP | "Mengapa prakiraan naik?" di PT-01 dan PR-01 | Hanya untuk (b); gunakan kata "faktor yang paling memengaruhi", bukan "penyebab" |
| (d) Pemeriksa kontrak | PT-02, PR-03, PT-06, PR-05, katalog | Aturan di atas keluaran (a), bukan model ML |
| Umpan balik tertutup | AD-08 | Pasca-MVP |

## 13. Keputusan IA yang Masih Terbuka
1. **SHAP untuk selisih antardaerah (Peta):** kamus menyebut membandingkan kontribusi fitur dua wilayah, tetapi fitur jarak dan surplus produksi belum ada di model. Default: teks statis di Peta pada MVP.
2. Apakah **Pendamping** dan **Dinas** masuk MVP atau dihapus dari IA (kini ditunda).
3. Apakah **Landing Page** menampilkan harga per provinsi pilihan pengguna atau satu provinsi tetap (Jawa Timur) untuk demo.
4. Apakah petani dapat **melihat katalog** produsen lain (default: ya, hanya lihat).
