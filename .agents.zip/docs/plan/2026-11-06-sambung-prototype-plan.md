# SAMBUNG — Prototype Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Membangun prototipe web responsif interaktif aplikasi SAMBUNG berbasis Vite + React (TypeScript) + Tailwind CSS v4 + shadcn/ui + Lucide Icons yang mencakup seluruh peran (Publik, Petani, Pembeli, Admin) dan siklus transaksi simulasi 5 langkah sesuai spesifikasi SRS v0.2, IA v0.2, dan UI Guidelines v0.1.

**Architecture:** Single Page Application (SPA) modular berbasis React TypeScript dengan state store reaktif in-memory/localStorage untuk mensimulasikan persistence multi-role secara mulus. Antarmuka menggunakan kontrak token resmi OKLCH Tailwind v4 (`sambung-theme.css`), tipografi Plus Jakarta Sans & Atkinson Hyperlegible Next, kalkulator Lampu Harga & Rentang Wajar terintegrasi, serta Role Switcher mengambang untuk keperluan demonstrasi/penjurian lomba.

**Tech Stack:** 
- Vite 6+ + React 18/19 + TypeScript
- Tailwind CSS v4 (`@tailwindcss/vite` + OKLCH custom theme)
- Lucide React (Ikonografi)
- Radix UI primitives & shadcn/ui design patterns
- Local Reactive Store (Zustand atau React Context dengan sync localStorage)
- Web Fonts (Plus Jakarta Sans & Atkinson Hyperlegible Next)

**Spec:**
- SRS: `docs/source_of_truth/SRS_SAMBUNG.md`
- IA: `docs/source_of_truth/IA_SAMBUNG.md`
- UI Guidelines: `docs/source_of_truth/UI_GUIDELINES_SAMBUNG.md`
- Theme Contract: `docs/source_of_truth/assets/sambung-theme.css`
- Decision Log: `docs/source_of_truth/decision-log.md`

## Global Constraints

- **Gratis & Simulasi (BR-001):** Semua kontrak transaksi berlabel tegas `SIMULASI`, tanpa komisi/pembayaran uang nyata.
- **Dua Jenis Gabah (BR-002):** GKP dan GKG dibedakan tegas dalam tawaran, rendemen, dan acuan harga wajar.
- **Presisi & Pembulatan (DEC-018a/b):** Input harga berupa Rupiah bulat, volume maksimal 2 desimal kg; batas L/U dibulatkan ke rupiah terdekat (0,5 ke atas).
- **Lampu Harga (BR-011/012):** Hijau ($L \le P \le U$), Kuning (dalam toleransi $\delta=3\%$ di bawah $L$ atau di atas $U$), Merah ($< L \times 0.97$). Merah tidak memblokir, melainkan meminta konfirmasi eksplisit.
- **Reservasi Atomik & 5 Langkah (BR-003/004/020):** Pembelian parsial mencadangkan volume; alur normal 5 langkah: Pilih tawaran $\rightarrow$ Kirim pesanan $\rightarrow$ Terima harga $\rightarrow$ Konfirmasi selesai 1 $\rightarrow$ Konfirmasi selesai 2.
- **Privasi Kontak (BR-018, DEC-014a/b/c):** Nomor HP hanya terbuka bagi kedua pihak saat kontrak berstatus `Disetujui`. Setelah Batal/Selesai, kontak disembunyikan kembali. Admin hanya melihat nomor tersamar (`0812-****-1234`).
- **Aksesibilitas & UI (DEC-016a):** Teks isi $\ge 16\text{ px}$, area sentuh kontrol $\ge 44 \times 44\text{ px}$, kontras teks normal $\ge 4.5:1$, fokus $\ge 3:1$, mode Terang & Gelap.
- **Peran Terisolasi (DEC-015a, DEC-020a):** Satu peran per akun; petani tidak melihat katalog tawaran petani lain; pergantian peran di luar MVP.

## Review Focus

1. **Volume Reservation Integrity:** Pengajuan pesanan parsial mencadangkan volume; pembatalan/penolakan melepaskan volume tepat satu kali; sisa volume tidak boleh negatif.
2. **Kontrak Status & Privasi Kontak:** Nomor telepon hanya tampil pada status `Disetujui`; ketika kontrak dibatalkan atau selesai, kontak lawan langsung tertutup kembali.
3. **Penyelesaian Dua Pihak:** Kontrak tidak boleh langsung `Selesai` hanya dengan 1 konfirmasi (harus menunggu pihak kedua).
4. **Peringatan Harga Merah:** Menawarkan harga merah memunculkan dialog konfirmasi eksplisit; acuan harga yang belum tersedia ditandai netral tanpa lampu palsu.
5. **Role Switcher & Guard:** Admin tidak dapat melakukan aksi tawar/terima/batal/selesai atas nama pihak transaksi; petani tidak dapat melihat katalog pasokan petani lain.

---

### Task 1: Scaffolding Proyek & Konfigurasi Fondasi UI

**Files:**
- Create: `package.json`, `vite.config.ts`, `tsconfig.json`, `index.html`
- Create: `src/main.tsx`, `src/App.tsx`, `src/index.css`
- Create: `src/lib/utils.ts` (helper `cn` dengan `clsx` dan `tailwind-merge`)
- Create: `src/types/domain.ts`

- [x] Inisialisasi Vite + React + TypeScript di direktori root.
- [x] Instal dependensi: Tailwind CSS v4 (`@tailwindcss/vite`), `clsx`, `tailwind-merge`, `lucide-react`, `@radix-ui/react-dialog`, `@radix-ui/react-dropdown-menu`, `@radix-ui/react-tabs`, `@radix-ui/react-slot`, `class-variance-authority`.
- [x] Impor font Plus Jakarta Sans dan Atkinson Hyperlegible Next melalui Google Fonts di `index.html`.
- [x] Pasang seluruh isi stylesheet kanonis dari `docs/source_of_truth/assets/sambung-theme.css` ke dalam `src/index.css`.
- [x] Buat helper `src/lib/utils.ts` untuk penggabungan class CSS (`cn`).
- [x] Buat definisi antarmuka TypeScript untuk domain models di `src/types/domain.ts` (TawaranPanen, KontrakSimulasi, StatusKontrak, LampuHarga, RiwayatHarga, UserRole).
- [x] Jalankan `npm run build` untuk memverifikasi kompilasi TypeScript dan Tailwind v4 bekerja tanpa error.

---

### Task 2: Domain Engine & Reactive Mock Store

**Files:**
- Create: `src/lib/priceEngine.ts` (kalkulasi rentang wajar, pembulatan rupiah DEC-018a, dan klasifikasi lampu harga)
- Create: `src/mock/seedData.ts` (data awal harga observasi BPS, tawaran petani, dan prakiraan wilayah)
- Create: `src/store/sambungStore.ts` (state management reaktif + localStorage persistence)

- [x] Implementasikan `calculateFairPriceRange(berasPrice, rendemen, p10, p90)` dan `evaluatePriceLamp(price, L, U, delta = 0.03)` di `src/lib/priceEngine.ts`.
- [x] Sediakan fungsi pembulatan L/U ke rupiah terdekat (0,5 ke atas) dan validasi input bilangan bulat/desimal $\le 2$.
- [x] Susun `src/mock/seedData.ts` dengan data realistik:
  - Data harga beras produsen & rasio historis untuk 10+ provinsi utama (Jawa Barat, Jawa Tengah, Jawa Timur, Sulawesi Selatan, Sumatera Utara, dll).
  - 5+ tawaran panen awal dari petani (GKP & GKG dengan variasi harga hijau, kuning, merah, dan mutu Belum diukur).
  - Data prakiraan 2 pekan & 4 pekan, interval 80%, serta fitur SHAP penjelas harga.
- [x] Bangun `src/store/sambungStore.ts` untuk menangani:
  - Status autentikasi & peran aktif (`currentRole`: 'public' | 'petani' | 'pembeli' | 'admin').
  - State theme ('light' | 'dark').
  - Koleksi tawaran panen (tambah tawaran baru, edit harga/volume tawaran, tarik tawaran).
  - Mesin status kontrak simulasi (ajukan pesanan $\rightarrow$ reservasi volume atomik $\rightarrow$ tawar harga $\rightarrow$ terima $\rightarrow$ konfirmasi 1/2 $\rightarrow$ batalkan).
  - Log audit aktivitas dan notifikasi pengguna.
- [x] Verifikasi logika store: lakukan unit check bahwa volume dicadangkan saat pesanan dibuat dan dikembalikan saat pesanan dibatalkan/ditolak.

---

### Task 3: Komponen Reusable & Shell Navigasi Bersama

**Files:**
- Create: `src/components/ui/button.tsx`
- Create: `src/components/ui/card.tsx`
- Create: `src/components/ui/badge.tsx`
- Create: `src/components/ui/input.tsx`
- Create: `src/components/ui/dialog.tsx`
- Create: `src/components/domain/PriceLampBadge.tsx`
- Create: `src/components/domain/ContractStatusBadge.tsx`
- Create: `src/components/domain/ConfirmationModal.tsx`
- Create: `src/components/layout/Navbar.tsx`
- Create: `src/components/layout/RoleSwitcher.tsx` (Floating Demo Toolbar)

- [x] Buat komponen Button, Card, Badge, Input sesuai aturan target sentuh $\ge 44\text{ px}$ (`min-h-[44px]`).
- [x] Buat `PriceLampBadge`: menampilkan warna indikator semantik (`price-within`, `price-caution`, `price-low`), ikon penjelas (CheckCircle, AlertTriangle, AlertOctagon), dan teks deskriptif (bukan warna saja).
- [x] Buat `ContractStatusBadge`: menampilkan status kontrak netral (`secondary`) dengan badge Menunggu, Disetujui, Selesai, Ditolak, Dibatalkan, Kedaluwarsa.
- [x] Buat `ConfirmationModal` untuk konfirmasi harga Merah ("Harga di bawah batas wajar...") dan modal alasan wajib saat membatalkan/menolak kontrak.
- [x] Buat `Navbar`: responsif desktop/mobile dengan navigasi sesuai peran aktif, switch mode Terang/Gelap, tombol logout/ganti akun, dan badge notifikasi.
- [x] Buat `RoleSwitcher` mengambang di pojok kanan bawah yang memudahkan juri/penguji beralih langsung antara:
  - 🌐 Publik (Tanpa Login)
  - 🌾 Petani (Pak Subur)
  - 🏭 Pembeli (CV Sumber Pangan)
  - 🛡️ Admin (Super Admin)
  - Tombol Reset Mock Data ke kondisi awal.

---

### Task 4: Halaman Publik (PB-01 s.d. PB-05) & Autentikasi (AU-01 s.d. AU-04)

**Files:**
- Create: `src/pages/public/HomePage.tsx` (PB-01)
- Create: `src/pages/public/PriceBoardPage.tsx` (PB-02)
- Create: `src/pages/public/PriceMapPage.tsx` (PB-03 & PB-03a)
- Create: `src/pages/public/ForecastPage.tsx` (PB-04)
- Create: `src/pages/public/HelpAndPrivacyPage.tsx` (PB-05)
- Create: `src/pages/auth/LoginPage.tsx` (AU-01, AU-02, AU-03, AU-04)

- [x] Implementasikan `HomePage` (PB-01): Hero section ramah pertanian modern, kartu periksa harga cepat, cuplikan disparitas wilayah, dan penjelasan simulasi tanpa komisi.
- [x] Implementasikan `PriceBoardPage` (PB-02): Filter komoditas (GKP, GKG, Beras), tabel harga rantai setara (Petani, Penggilingan/Produsen, Eceran), ekuivalen beras, dan tombol unduh CSV publik.
- [x] Implementasikan `PriceMapPage` (PB-03 & PB-03a):
  - Visualisasi peta tematik provinsi interaktif dengan skala kontinu berpusat 0% selisih terhadap median.
  - Tab alternatif Tabel Provinsi (PB-03a) dengan pengurutan termurah $\rightarrow$ termahal dan penanda netral data belum tersedia.
  - Panel rincian disparitas harga maksimum-minimum.
- [x] Implementasikan `ForecastPage` (PB-04): Prakiraan harga 2 pekan dan 4 pekan, grafik pita interval keyakinan 80%, penjelasan faktor fitur SHAP, serta label transparan fallback baseline.
- [x] Implementasikan `HelpAndPrivacyPage` (PB-05): Glosarium istilah, penjelasan 5 langkah transaksi, dan transparansi kebijakan data pribadi.
- [x] Implementasikan `LoginPage` (AU-01 s.d. AU-04):
  - Tab Login Pengguna (No HP + simulasi OTP cepat) vs Login Admin (Email/Password).
  - Alur pendaftaran akun baru dengan pemilihan peran tunggal (Petani / Pembeli) dan persetujuan syarat tidak tercentang otomatis (DEC-014g).

---

### Task 5: Ruang Kerja Petani (PT-01 s.d. PT-06a)

**Files:**
- Create: `src/pages/petani/PetaniDashboard.tsx` (PT-01)
- Create: `src/pages/petani/CreateOfferPage.tsx` (PT-02)
- Create: `src/pages/petani/MyOffersPage.tsx` (PT-03, PT-04)
- Create: `src/pages/shared/ContractsListPage.tsx` (PT-05)
- Create: `src/pages/shared/ContractDetailPage.tsx` (PT-06)
- Create: `src/pages/shared/SimulationReceiptModal.tsx` (PT-06a)

- [x] Implementasikan `PetaniDashboard` (PT-01): Ringkasan pasokan milik sendiri, status pesanan masuk, harga wajar lokal hari ini, dan tombol cepat "Jual Panen".
- [x] Implementasikan `CreateOfferPage` (PT-02):
  - Form input: Jenis gabah (GKP / GKG), lokasi kecamatan, volume kg (maksimal 2 desimal), harga minta Rp/kg (rupiah bulat).
  - Mutu terukur atau checkbox "Belum diukur".
  - Tanggal ketersediaan opsional ("Belum ditentukan").
  - Live feedback kalkulator lampu harga wajar. Jika harga masuk zona Merah, munculkan peringatan dengan dialog konfirmasi eksplisit.
- [x] Implementasikan `MyOffersPage` (PT-03 & PT-04):
  - Menampilkan daftar tawaran panen milik petani yang sedang login.
  - Detail visualisasi pemecahan volume: Total = Tersedia + Dicadangkan (Menunggu) + Disetujui + Selesai.
  - Aksi "Tarik Tawaran" (otomatis membatalkan pesanan Menunggu dengan alasan tercatat, menjaga kontrak Disetujui).
- [x] Implementasikan `ContractsListPage` (PT-05) dan `ContractDetailPage` (PT-06):
  - Menampilkan daftar pesanan masuk dari pembeli.
  - Halaman detail kontrak simulasi: Timeline status, tenggat waktu 24 jam, riwayat negosiasi harga.
  - Aksi Petani: "Terima Harga", "Ajukan Harga Balik" (Counter-offer), atau "Tolak" (dengan alasan wajib).
  - Ketika status `Disetujui`: Nama dan Nomor HP Pembeli terbuka (`0812-3456-7890`) untuk koordinasi simulasi fisik.
  - Aksi "Konfirmasi Selesai": Menampilkan progres 1/2 konfirmasi sampai kedua pihak selesai.
  - Aksi "Batalkan Kontrak" sebelum selesai dengan alasan wajib.
- [x] Implementasikan `SimulationReceiptModal` (PT-06a): Lembar cetak bukti kesepakatan dengan watermark `SIMULASI LOMBA`.

---

### Task 6: Ruang Kerja Pembeli (PR-01 s.d. PR-03, PR-07)

**Files:**
- Create: `src/pages/pembeli/PembeliDashboard.tsx` (PR-01)
- Create: `src/pages/pembeli/SupplyCatalogPage.tsx` (PR-02)
- Create: `src/pages/pembeli/SupplyDetailPage.tsx` (PR-03)
- Create: `src/pages/pembeli/ExportSupplyModal.tsx` (PR-07)

- [x] Implementasikan `PembeliDashboard` (PR-01): Metrik ringkasan pasokan gabah nasional, pesanan yang sedang diproses, dan pintasan pencarian pasokan.
- [x] Implementasikan `SupplyCatalogPage` (PR-02):
  - Katalog tawaran panen dari seluruh petani: filter jenis (GKP/GKG), provinsi/wilayah, dan rentang harga.
  - Tampilkan label volume deklaratif tersedia, lampu harga wajar, dan badge moderasi "Sedang diminta perbaikan" jika ada catatan admin.
  - Tombol unduh CSV Agregasi Pasokan (PR-07): hanya agregasi per wilayah/komoditas tanpa data identitas individu (DEC-015b).
- [x] Implementasikan `SupplyDetailPage` (PR-03):
  - Rincian tawaran petani: volume tersedia, mutu deklaratif, estimasi wajar.
  - Form Pemesanan Parsial: input volume pesanan ($\le$ volume tersedia) dan harga penawaran (bisa sama dengan harga minta atau mengajukan harga negosiasi).
  - Pengecekan otomatis stok atomik: saat klik "Ajukan Pesanan", volume tawaran langsung tercadangkan dan dibuatkan kontrak Menunggu Kesepakatan.
- [x] Sinkronisasikan pembeli ke `ContractDetailPage` (PT-06):
  - Pembeli dapat menerima harga balik petani, mengajukan harga baru, membatalkan pesanan, dan melakukan konfirmasi selesai.
  - Kontak petani terbuka saat Disetujui, dan tertutup kembali setelah Selesai/Batal.

---

### Task 7: Ruang Kerja Admin (AD-01 s.d. AD-07)

**Files:**
- Create: `src/pages/admin/AdminDashboard.tsx` (AD-01)
- Create: `src/pages/admin/AdminParametersPage.tsx` (AD-02)
- Create: `src/pages/admin/AdminDataManagementPage.tsx` (AD-03)
- Create: `src/pages/admin/AdminModerationPage.tsx` (AD-04)
- Create: `src/pages/admin/AdminUsersPage.tsx` (AD-05)
- Create: `src/pages/admin/AdminAuditLogPage.tsx` (AD-06)
- Create: `src/pages/admin/AdminModelEvalPage.tsx` (AD-07)

- [x] Implementasikan `AdminDashboard` (AD-01): Ringkasan status sistem (total kontrak simulasi, tawaran aktif, status model AI, data harga terkini).
- [x] Implementasikan `AdminParametersPage` (AD-02): Pengaturan parameter global (durasi tenggat pesanan baru dari 24 jam ke durasi lain, toleransi $\delta=3\%$, rendemen GKP/GKG).
- [x] Implementasikan `AdminDataManagementPage` (AD-03): Simulasi impor data harga BPS/PIHPS dan snapshot versi data.
- [x] Implementasikan `AdminModerationPage` (AD-04): Menandai tawaran yang butuh perbaikan tanpa membatalkan kontrak yang sedang berjalan.
- [x] Implementasikan `AdminUsersPage` (AD-05): Daftar pengguna terdaftar dengan **nomor HP tersamar** (`0812-****-8899`) sesuai DEC-014c. Simulasi permohonan penutupan akun.
- [x] Implementasikan `AdminAuditLogPage` (AD-06): Tabel kronologis jejak peristiwa bisnis (waktu, aktor, aksi, status kontrak, tanpa membocorkan kredensial).
- [x] Implementasikan `AdminModelEvalPage` (AD-07): Laporan metrik model per provinsi (MASE, interval 80%, status fallback baseline).
- [x] Mode pemantauan kontrak PT-06 untuk Admin: Admin dapat melihat detail transaksi untuk audit, namun tombol aksi tawar/terima/batal/selesai dinonaktifkan sepenuhnya.

---

### Task 8: Integrasi, Verifikasi Alur 5 Langkah & Polishing UI

**Files:**
- Modify: `src/App.tsx` (Wiring router dan role switcher)
- Test/Verification: Walkthrough checklist & UI polish

- [x] Lakukan integrasi penuh seluruh halaman ke dalam router utama dengan proteksi hak akses per peran.
- [x] Verifikasi uji coba Walkthrough Alur Transaksi 5 Langkah:
  1. Pembeli membuka PR-02 $\rightarrow$ Memilih tawaran petani $\rightarrow$ Mengajukan pesanan parsial (Volume dicadangkan).
  2. Beralih peran ke Petani melalui Role Switcher $\rightarrow$ Melihat notifikasi pesanan masuk $\rightarrow$ Menerima harga (Status menjadi Disetujui).
  3. Periksa kontak: Nomor HP kedua pihak kini saling terbuka.
  4. Petani klik "Konfirmasi Selesai" (Status tetap Disetujui, indikator 1/2 konfirmasi aktif).
  5. Beralih ke Pembeli $\rightarrow$ Pembeli klik "Konfirmasi Selesai" (Status menjadi Selesai).
  6. Periksa kontak pasca-selesai: Nomor HP kedua belah pihak langsung disembunyikan kembali.
- [x] Verifikasi skenario pembatalan & pelepasan volume atomik (Volume tawaran kembali utuh tepat 1 kali).
- [x] Verifikasi mode Gelap / Terang di semua halaman (warna OKLCH kontras tinggi, teks tidak redup).
- [x] Pastikan tidak ada console error atau broken links.
- [x] Jalankan build produksi (`npm run build`) dan pastikan paket siap di-run/preview.
