"""Check documentation references and preserve original inputs; not an app test."""
from pathlib import Path
import hashlib
import re
from urllib.parse import unquote

WORKSPACE = Path(__file__).resolve().parents[2]
ROOT = WORKSPACE / "docs/source_of_truth"
srs = (ROOT / "SRS_SAMBUNG.md").read_text(encoding="utf-8")
ia = (ROOT / "IA_SAMBUNG.md").read_text(encoding="utf-8")
ui = (ROOT / "UI_GUIDELINES_SAMBUNG.md").read_text(encoding="utf-8")
matrix = (ROOT / "traceability-matrix.md").read_text(encoding="utf-8")
decisions = (ROOT / "decision-log.md").read_text(encoding="utf-8")

defs = {
    "FR": set(re.findall(r"^### (FR-\d{3})", srs, re.M)),
    "AC": set(re.findall(r"\*\*(AC-\d{3}):", srs)),
    "BR": set(re.findall(r"^\| (BR-\d{3}) \|", srs, re.M)),
    "NFR": set(re.findall(r"^\| (NFR-\d{3}) \|", srs, re.M)),
    "UI": set(re.findall(r"^\*\*(UI-\d{3}) —", ui, re.M)),
}
for prefix, count in (("FR", 31), ("AC", 36), ("BR", 20), ("NFR", 10), ("UI", 24)):
    assert defs[prefix] == {f"{prefix}-{n:03}" for n in range(1, count + 1)}, prefix
    print(f"{prefix}: {count} definitions verified")
assert re.findall(r"^## (\d)\.", ui, re.M) == list("12345678")
assert len(re.findall(r"^\*\*UI-\d{3} —", ui, re.M)) == 24
for name, text in (("UI", ui), ("matrix", matrix)):
    for prefix, valid in defs.items():
        refs = set(re.findall(rf"\b{prefix}-\d{{3}}\b", text))
        assert refs <= valid, (name, refs - valid)
assert set(re.findall(r"^\| (FR-\d{3}) \|", matrix, re.M)) == defs["FR"]
assert set(re.findall(r"^\| (UI-\d{3}) \|", matrix, re.M)) == defs["UI"]
for line in matrix.splitlines():
    if re.match(r"^\| FR-\d{3} \|", line):
        assert "UI-" in line.split("|")[-2], line
decision_ids = set(re.findall(r"^### (DEC-\d{3}[a-z]?) —", decisions, re.M))
matrix_ids = re.findall(r"^\| (DEC-\d{3}[a-z]?) \|", matrix, re.M)
assert len(matrix_ids) == len(set(matrix_ids)) == 74
assert set(matrix_ids) == decision_ids, (set(matrix_ids) ^ decision_ids)
print("8 sections; 24 UI rows; 31 FR with UI coverage; 74 decisions mapped")

files = list(ROOT.glob("*.md")) + [WORKSPACE / "docs/plan" / name for name in (
    "2026-11-06-source-of-truth-plan.md", "2026-11-06-source-of-truth-progress.md"
)]
links_checked = 0
for path in files:
    text = path.read_text(encoding="utf-8")
    assert len(re.findall(r"^```", text, re.M)) % 2 == 0, path
    # Inspect rendered Markdown, not code examples.
    rendered = re.sub(r"```[\s\S]*?```", "", text)
    for target in re.findall(r"!?\[[^\]\n]*\]\(([^)]+)\)", rendered):
        target = unquote(target.strip("<>").split("#", 1)[0])
        if not target or re.match(r"(?:https?://|mailto:)", target):
            continue
        assert (path.parent / target).exists(), (path, target)
        links_checked += 1
    columns = None
    for line in rendered.splitlines():
        if line.startswith("|") and line.endswith("|"):
            current = len(re.split(r"(?<!\\)\|", line))
            if columns is None:
                columns = current
            assert current == columns, (path.name, line)
        else:
            columns = None
print(f"{links_checked} local links; Markdown tables/code fences verified")
inventory = ia.split("## 4.", 1)[1].split("## 5.", 1)[0]
page_ids = re.findall(r"^\| ((?:PB|AU|PT|PR|AD)-\d{2}[ab]?) [^|]+\|", inventory, re.M)
assert len(page_ids) == len(set(page_ids)) == 32, page_ids
print("32 canonical IA pages/panels retained; Mermaid fences balanced (not rendered)")

css = (ROOT / "assets/sambung-theme.css").read_text(encoding="utf-8")
variables = set(re.findall(r"(--[\w-]+)\s*:", css))
references = set(re.findall(r"var\((--[\w-]+)", css))
assert references <= variables, references - variables
print("CSS custom property references resolve within the proposed theme")
sources = {
    "docs/proposal/proposal.txt": "B72A7F8428C5116103615FEAFBD74FE4250FB128A370FD021F6A06591474D64A",
    "docs/created/SAMBUNG_Review_dan_Klarifikasi_Kebutuhan.md": "16751F88F374E534D73A932C77C0C9943BDEF1A9A620D8446B1CE7D55892C086",
    "docs/created/SAMBUNG_Information_Architecture.md": "FFC526A91DFC35FE0171187BF9EDAB44286D5E1C97C81BD6464C6F2471564361",
    "docs/created/SAMBUNG_UI_Guideline.md": "E1888011FC1CDDB29A1B9F70EA2058A04C27574850CA16C1FFD2DBCAC3811B77",
    "docs/ui_reference/contoh-ui-guidelines.md": "0D87B40F97E34F5C9FBC2B09AF6DCF2AC128B5EDB9338F7F708747863EF79F5D",
}
for source, expected in sources.items():
    assert hashlib.sha256((WORKSPACE / source).read_bytes()).hexdigest().upper() == expected, source
print("5 original source SHA-256 hashes unchanged")
print("Documentation checks passed. No application/runtime assertions were tested.")
