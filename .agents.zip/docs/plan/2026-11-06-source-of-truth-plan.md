# SAMBUNG Source of Truth — Implementation Plan

> **For agentic workers:** Gunakan skill `executing-plans` untuk menjalankan rencana ini per tugas. Langkah menggunakan checkbox. Eksekusi tiga fase dilakukan setelah rencana ditinjau pengguna; pembuatan rencana ini tidak berarti keputusan produk di dalam dokumen lama telah disetujui.

**Goal:** Menghasilkan satu paket dokumentasi acuan SAMBUNG yang berisi Software Requirements Specification (SRS), Information Architecture (IA), dan UI Guidelines yang saling konsisten serta dapat ditelusuri ke proposal dan keputusan pengguna.

**Architecture:** Audit sumber terlebih dahulu, selesaikan konflik melalui keputusan yang tercatat, lalu turunkan kebutuhan menjadi halaman dan aturan UI. SRS menjadi acuan perilaku, IA menjadi acuan struktur dan navigasi, dan UI Guidelines menjadi acuan penyajian; ketiganya terhubung melalui ID dan matriks ketertelusuran.

**Tech Stack:** Markdown, tabel keputusan dan ketertelusuran, Mermaid untuk diagram yang dapat disunting. Tidak ada perubahan kode aplikasi pada pekerjaan ini.

**Spec:** Brief pengguna tentang tiga fase; `../proposal/proposal.txt`; tiga dokumen di `../created/`; referensi format `../ui_reference/contoh-ui-guidelines.md`.

**Tanggal:** 6 November 2026 · **Status:** Rencana untuk ditinjau, belum dieksekusi.

## Batas pekerjaan dan penggunaan skill

- Hasil pekerjaan saat ini hanya rencana di `docs/plan/`. Berkas di `docs/source_of_truth/` merupakan keluaran eksekusi berikutnya.
- `brainstorming`: mengidentifikasi tujuan, pilihan pendekatan, asumsi, dan keputusan yang perlu dibahas sebelum dokumen dijadikan acuan resmi.
- `grill-me`: ditemukan di `.agents/skills/grill-me/SKILL.md`, tetapi isinya hanya menginstruksikan pemanggilan skill `grilling`. Skill tersebut tidak ditemukan pada pencarian lokal dan tidak ada tool `Skill` yang tersedia. Karena itu, alur skill ini belum dapat dijalankan secara utuh. Agenda pertanyaan di bawah adalah persiapan klarifikasi, bukan klaim bahwa `grilling` sudah dijalankan. Pada eksekusi, periksa kembali dependensinya; bila tetap tidak tersedia, sepakati penggunaan wawancara langsung sebagai pengganti.
- `writing-plan` ditafsirkan sebagai skill tersedia `writing-plans`: rencana dipecah menjadi tugas dengan masukan, keluaran, langkah, dan kriteria penerimaan. Lokasi mengikuti permintaan pengguna, yaitu `docs/plan/`.
- Keputusan bisnis yang belum dijawab tidak boleh diberi label disepakati. Pekerjaan pada bagian yang tidak bergantung pada keputusan itu dapat terus berjalan.

## Konteks dan pilihan pendekatan

Tujuan paket ini adalah memberi tim satu acuan kebutuhan, struktur aplikasi, dan aturan UI. Proposal menjelaskan visi dan batas produk; dokumen lama menambahkan rekomendasi MVP yang sebagian masih menunggu konfirmasi. Karena itu, menyatukan teks saja tidak cukup.

| Pendekatan | Manfaat | Keterbatasan |
|---|---|---|
| Menyalin dan menggabungkan dokumen lama | Cepat | Mengangkat default yang belum disetujui serta kontradiksi menjadi aturan resmi |
| Menulis ulang seluruh dokumen langsung dari proposal | Sederhana dari sisi sumber | Menghilangkan analisis, koreksi, dan inventaris halaman yang sudah berguna |
| Audit berbasis bukti, konfirmasi keputusan, lalu susun ulang | Mempertahankan materi berguna dan memperjelas dasar setiap keputusan | Memerlukan klarifikasi untuk konflik yang memengaruhi produk |

**Usulan pendekatan:** pilihan ketiga, sesuai urutan tiga fase pengguna. Ini merupakan usulan penyusun rencana, belum keputusan pengguna tentang isi produk. Ukuran pekerjaan adalah penyusunan paket dokumentasi, bukan pembangunan atau perombakan aplikasi.

## Inventaris sumber yang ditemukan

| ID | Berkas aktual | Peran dan batas kepercayaan |
|---|---|---|
| SRC-01 | `docs/proposal/proposal.txt` | Sumber visi, pengguna, modul, target, serta lingkup lomba. Konflik internal tetap perlu dicatat |
| SRC-02 | `docs/created/SAMBUNG_Review_dan_Klarifikasi_Kebutuhan.md` | Review, pertanyaan Q-01…Q-15, rekomendasi MVP, dan kerangka SRS; secara eksplisit bukan SRS final |
| SRC-03 | `docs/created/SAMBUNG_Information_Architecture.md` | Sitemap, peran, halaman, status, dan hubungan data–AI–halaman; mengikuti default yang belum dikonfirmasi |
| SRC-04 | `docs/created/SAMBUNG_UI_Guideline.md` | Draf arah visual, token, komponen, aksesibilitas, serta pertanyaan terbuka |
| SRC-05 | `docs/ui_reference/contoh-ui-guidelines.md` | Referensi struktur UI Guidelines milik Jagains; bukan sumber kebutuhan SAMBUNG |

Dokumen lama berada di `docs/created/`, berbeda dari lokasi dalam brief. Jangan memindahkan atau menimpa sumber. SRC-01 berupa teks: beberapa lampiran gambar hanya tersisa sebagai judul. Kamus, brief tambahan, kode prototipe, serta gambar `IA_01…IA_08.png` yang dirujuk dokumen lama belum tersedia dalam inventaris ini; pernyataan yang bergantung padanya diberi status belum terverifikasi.

## Global Constraints

1. Bahasa dokumen dan contoh microcopy adalah Bahasa Indonesia; istilah teknis dijelaskan dalam glosarium.
2. Pertahankan tujuan memperkuat posisi tawar petani dan prinsip tanpa komisi transaksi yang tertulis di proposal.
3. Pembayaran, logistik, dan verifikasi mutu fisik berada pada kategori “Tidak untuk saat ini” di proposal A.9; jangan memasukkannya ke MVP tanpa keputusan perubahan lingkup.
4. Bedakan fakta proposal, rekomendasi lama, asumsi, keputusan terkonfirmasi, dan konflik terbuka. Label `[DISEPAKATI]` pada sumber lama bukan bukti persetujuan baru.
5. Jangan mengubah prioritas proposal atau menetapkan OTP, ambang lampu, rumus, font, warna, maupun teknologi hanya karena dokumen lama mengusulkannya.
6. Angka harga contoh bukan bukti harga terkini. Klaim hukum, kebijakan, atau data terkini yang diperlukan saat eksekusi harus diperiksa ke sumber primer; audit awal memeriksa konsistensi isi yang diberikan.
7. Jangan mengklaim kepatuhan standar, aksesibilitas, hasil uji model, atau validitas hukum tanpa bukti. Nilai target harus dibedakan dari hasil yang sudah dicapai.

## Review Focus

| Risiko | Pemeriksaan yang wajib masuk tugas |
|---|---|
| Default berubah menjadi keputusan resmi tanpa persetujuan | Tugas 1–2: telusuri status serta bukti keputusan setiap aturan penting |
| Koreksi lama atau angka ilustrasi dianggap fakta final | Tugas 1–2: periksa F-03, horizon prakiraan, rumus dan asal data |
| Diagram, tabel halaman, dan izin akses berbeda | Tugas 3: cocokkan aktor, status, prioritas, dan aksi di semua representasi |
| UI menetapkan perilaku yang tidak ada di SRS | Tugas 4: hubungkan aturan komponen ke FR/BR dan halaman IA |
| Dokumen terlihat final meski referensi atau keputusan penting hilang | Tugas 5: audit tautan, keterlacakan, blocker, dan persetujuan paket |

## Struktur keluaran saat rencana dieksekusi

| Berkas | Tanggung jawab |
|---|---|
| `docs/source_of_truth/README.md` | Indeks, versi paket, status persetujuan, cara membaca, hierarki acuan, dan aturan perubahan |
| `docs/source_of_truth/verification-report.md` | Inventaris sumber, matriks konsistensi, temuan berbukti, serta keterbatasan sumber |
| `docs/source_of_truth/decision-log.md` | Pertanyaan, pilihan, jawaban, alasan, dampak, pemberi keputusan, dan tanggal |
| `docs/source_of_truth/SRS_SAMBUNG.md` | Kebutuhan, aturan bisnis, data, batas sistem, serta kriteria penerimaan |
| `docs/source_of_truth/IA_SAMBUNG.md` | Aktor, sitemap, inventaris halaman, navigasi, izin dan alur |
| `docs/source_of_truth/UI_GUIDELINES_SAMBUNG.md` | Sistem visual dan aturan komponen menurut format contoh |
| `docs/source_of_truth/traceability-matrix.md` | Pemetaan sumber → keputusan → kebutuhan → halaman → aturan UI → kriteria penerimaan |

Paket terdiri dari tiga dokumen utama dan dokumen pendukung audit. Jangan menyalin aturan yang sama sebagai otoritas terpisah: IA dan UI menautkan aturan bisnis pada SRS. Perubahan SRS wajib memicu pemeriksaan dampak terhadap IA dan UI.

## Fase 1 — Membaca proposal dan memverifikasi konsistensi

### Tugas 1: Audit sumber dan susun matriks konsistensi

**Baca:** SRC-01…SRC-05 secara utuh.
**Buat:** `verification-report.md`, draf `decision-log.md`.
**Menghasilkan:** temuan `AUD-001` dan seterusnya, daftar keputusan `DEC-001` dan seterusnya, serta daftar sumber yang tidak tersedia.

- [x] Inventarisasi setiap sumber, versi/status, bagian yang tersedia, serta referensi yang hilang. Gunakan heading dan nomor baris untuk bukti temuan.
- [x] Ekstrak janji proposal: masalah, aktor, fitur, lingkup MVP/inkubasi, empat modul AI, alur transaksi, data dan target evaluasi.
- [x] Buat matriks per topik dengan kolom: proposal, draf kebutuhan, IA, UI, status konsistensi, bukti, dampak, dan keputusan yang diperlukan.
- [x] Periksa topik: peran dan izin; katalog/listing; pesanan dan negosiasi; kontrak simulasi; lampu harga; estimator; prakiraan dan SHAP; papan harga; peta; pelatihan ulang; notifikasi; autentikasi; privasi; monetisasi; aksesibilitas; dan istilah.
- [x] Uji kembali F-01…F-25 serta Q-01…Q-15 dari review lama. Beri status tetap relevan, direvisi, tidak dapat diverifikasi, atau selesai dengan bukti. Jangan mengadopsi ringkasan temuan lama tanpa pemeriksaan.
- [x] Catat ketidaksesuaian antarbagian dalam satu dokumen, termasuk diagram vs tabel vs contoh kode; bukan hanya perbedaan antardokumen.
- [x] Pisahkan kontradiksi, kekurangan informasi, perubahan usulan, dan variasi representasi yang masih dapat diterima.

**Temuan awal yang menjadi agenda audit, bukan hasil verifikasi final:**

| Topik | Bukti awal | Pemeriksaan lanjutan |
|---|---|---|
| Rumus F-03 | SRC-03 §0 merevisi SRC-02 F-03 memakai harga beras produsen Rp13.400 | Periksa aritmetika dan asal angka. Kamus yang disebut IA belum tersedia; bedakan kebenaran hitungan dari kebenaran masukan |
| Horizon prakiraan | Proposal A.7: “Harga 1–8 pekan terakhir” adalah masukan; keluarannya 2 dan 4 pekan. IA menulis 1–4 pekan | Jangan mengulang pembacaan 1–8 pekan sebagai keluaran. Konfirmasikan target UI terhadap narasi 2–4 pekan dan keluaran 2/4 pekan |
| Prioritas fitur AI | Proposal A.9 mewajibkan SHAP dasar, sedangkan draf kebutuhan/IA memberi batasan dan prioritas Should | Pisahkan keterbatasan metode, kebutuhan demonstrasi, dan usulan penurunan lingkup |
| Kontrak dan data latih | Proposal menjelaskan closed-loop, A.9 menyebut kontrak simulasi; IA mengecualikan simulasi dari pelatihan | Tentukan batas MVP vs inkubasi dan bukti transaksi yang boleh dipakai |
| Makna warna | SRC-04 §2/§4 mencadangkan warna lampu untuk harga, tetapi §7.3/§7.5 memakainya untuk aksi bahaya dan status kontrak | Tentukan pemisahan token serta aturan semantik yang tidak saling melarang |
| Arah visual dan format | Draf SAMBUNG memakai Atkinson/Source Serif, referensi memakai Plus Jakarta/Inter dan domain Jagains | Adopsi struktur format, bukan otomatis mengganti identitas maupun menyalin domain |

**Kriteria penerimaan:** semua topik memiliki perbandingan empat sumber substantif, setiap konflik punya bukti dan dampak, serta tidak ada rekomendasi lama yang otomatis berstatus terkonfirmasi.

### Tugas 2: Klarifikasi keputusan sebelum membakukan kebutuhan

**Baca:** laporan audit dan pertanyaan lama yang masih relevan.
**Ubah:** `decision-log.md`, status temuan di `verification-report.md`.
**Menghasilkan:** keputusan yang menjadi masukan resmi fase 2; sisa pertanyaan dengan dampak dan bagian yang tertahan.

- [x] Dahulukan pertanyaan yang memengaruhi transaksi, harga, lingkup AI, dan data. Jangan menanyakan ulang hal yang sudah terjawab sumber atau percakapan.
- [x] Ajukan satu pertanyaan utama per giliran, jelaskan konflik konkret dan konsekuensinya; pertanyaan berikut mengikuti jawaban pengguna.
- [x] Untuk setiap keputusan, catat sumber masalah, pilihan yang masuk akal, rekomendasi beserta alasan, jawaban eksplisit, dan dampak pada dokumen. Default tetap usulan sampai dijawab.
- [x] Bedakan keputusan pengguna dari validasi yang memerlukan pembimbing, tim data, atau bukti teknis; catat siapa yang perlu memvalidasi tanpa menghubungi pihak lain otomatis.
- [x] Tinjau ringkasan keputusan bersama pengguna sebelum menyebutnya baseline fase 2.

**Urutan agenda klarifikasi:**

1. Target dokumen: baseline prototipe/final yang mana, dan fitur mana tetap kewajiban proposal atau berubah lingkup?
2. Estimator harga wajar: sumber harga, komoditas/mutu, rumus, pembulatan, cakupan wilayah/waktu, serta kondisi data tidak tersedia.
3. Lampu harga: batas hijau/kuning/merah, tepat pada batas, harga di atas rentang, dan konsekuensi melanjutkan saat merah.
4. Transaksi: simulasi vs nyata; hubungan listing–pesanan–kontrak, volume parsial, negosiasi, persetujuan kedua pihak, selesai/batal/kedaluwarsa.
5. Prakiraan dan penjelasan: horizon, interval, prioritas SHAP, fallback, serta pemisahan target evaluasi dari hasil eksperimen.
6. Aktor, akun, izin akses, data pribadi dan batas visibilitas kontak; pastikan pendamping, Dinas, dan Admin tidak diasumsikan sepihak.
7. Data peta/papan harga: konversi gabah–beras, pembanding selisih, wilayah tanpa data, sumber/tanggal, HPP berlaku-tanggal, dan validasi data latih.
8. Keputusan visual: identitas SAMBUNG, font, palet, navigasi, pustaka komponen, mode terang/gelap dan kesetiaan format referensi.

**Gerbang fase 1:** konflik kritis memiliki jawaban atau keputusan penundaan lingkup yang eksplisit. Bagian yang belum terjawab tetap berstatus terbuka; fase 2 boleh menyusun bagian independen, tetapi tidak memfinalkan aturan yang bergantung padanya.

## Fase 2 — Menyusun SRS dan Information Architecture

### Tugas 3: Susun kebutuhan, lalu turunkan struktur aplikasi

**Baca:** SRC-01, audit, dan keputusan terkonfirmasi.
**Buat:** `SRS_SAMBUNG.md`, `IA_SAMBUNG.md`, draf `traceability-matrix.md`.
**Menghasilkan:** kebutuhan `FR-xxx`, `NFR-xxx`, aturan `BR-xxx`, kriteria `AC-xxx`, dan halaman ber-ID stabil.

- [x] Susun SRS: metadata/status; tujuan dan lingkup; referensi/glosarium; gambaran sistem; aktor dan izin; MVP vs ditunda; kebutuhan fungsional; aturan bisnis; kebutuhan data/antarmuka; NFR; asumsi/ketergantungan; serta kriteria penerimaan.
- [x] Untuk setiap FR, tulis aktor, pemicu, prasyarat, perilaku yang diwajibkan, hasil, kondisi gagal, prioritas, sumber/keputusan dan AC yang dapat diperiksa. Bedakan spesifikasi produk dari usulan implementasi teknis.
- [x] Formalisasikan aturan yang sudah diputuskan: rumus dan satuan, batas lampu, kualitas/umur data, mesin status, izin setiap transisi, batas negosiasi/waktu, dan pengecualian data simulasi jika disepakati.
- [x] Tetapkan NFR terukur hanya dengan dasar sumber/keputusan. Target baru seperti SUS, latensi atau batas aksesibilitas diberi label usulan sampai disetujui; jangan menyatakan hasil uji.
- [x] Susun IA dari FR dan aktor: prinsip IA, sitemap, navigasi per aktor, halaman bersama, inventaris halaman, matriks akses, alur utama/alternatif, serta pemetaan modul AI dan data ke halaman.
- [x] Pertahankan ID halaman lama yang masih sesuai (`PB-*`, `AU-*`, `PT-*`, `PR-*`, `AD-*`); catat penggabungan/penghapusan agar rujukan tidak putus. Untuk halaman bersama, nyatakan satu identitas dan variasi izin per peran.
- [x] Setiap halaman mencantumkan tujuan, aktor, FR/BR terkait, informasi wajib, aksi dan tujuan navigasi, prioritas, serta keadaan memuat/kosong/gagal/tanpa izin/data usang yang relevan.
- [x] Gambar ulang sitemap, alur, dan diagram status sebagai Mermaid mandiri. Hapus ketergantungan pada PNG yang tidak tersedia.
- [x] Periksa jalur katalog → pemesanan → persetujuan kontrak terhadap target ≤5 langkah proposal; tetapkan awal, akhir, aktor, dan definisi langkah yang disetujui. Jangan menyamakan tiga langkah menerbitkan listing dengan keseluruhan transaksi.
- [x] Isi matriks sumber/DEC → FR/BR/NFR → halaman → AC. Kebutuhan latar belakang yang tidak memerlukan layar diberi alasan; halaman tanpa kebutuhan harus dihapus atau diputuskan lingkupnya.

**Kriteria penerimaan:** tidak ada FR tanpa AC dan sumber; tidak ada halaman/aksi tanpa kebutuhan; diagram dan tabel sepakat tentang peran, izin, prioritas dan status. Keputusan kritis fase 1 tercermin di kedua dokumen dan tidak ada label final pada bagian yang masih terbuka.

**Gerbang fase 2:** pengguna meninjau SRS dan IA sebagai satu pasangan. Catat versi baseline yang akan dipakai fase 3, beserta pertanyaan nonkritis yang masih tersisa.

## Fase 3 — Membuat UI Guidelines sesuai format contoh

### Tugas 4: Adaptasi format dan kaitkan aturan UI dengan kebutuhan

**Status 6 November 2026:** penyusunan dan verifikasi revisi mockup selesai untuk review; UI v0.2 belum disetujui sebagai keseluruhan dokumen. DEC-021a mencatat instruksi visual terbaru.

**Baca:** SRS/IA baseline fase 2, SRC-04 dan SRC-05.
**Buat:** `UI_GUIDELINES_SAMBUNG.md`.
**Ubah:** `traceability-matrix.md`, `decision-log.md` bila ada keputusan visual baru.
**Menghasilkan:** aturan UI `UI-xxx`, token dan spesifikasi komponen yang mengacu pada kebutuhan serta halaman.

- [x] Buat tabel pemetaan delapan bagian utama referensi ke bagian SAMBUNG berikut. Pertahankan urutan dan tujuan bagian; catat adaptasi yang dibutuhkan.

| Bagian format contoh | Isi yang harus disusun untuk SAMBUNG |
|---|---|
| 1. Pendahuluan & Filosofi Desain Antarmuka | Acuan versi SRS/IA, petani/penggilingan, keterbacaan harga, literasi digital rendah, dan arah visual yang disepakati |
| 2. Sistem Warna & Semantic Tokens (OKLCH) | Token inti/permukaan/aksi, grafik, lampu harga dan status kontrak; pemisahan semantik, pasangan kontras, dan dukungan mode yang diputuskan |
| 3. Tipografi: Skala Rasio Emas | Tabel skala, dasar hitung/pembulatan, font terpilih, ukuran responsif, bobot dan penggunaan. Jelaskan penyesuaian jika skala draf 17 px dipertahankan |
| 4. Spacing, Tata Letak, & Hukum Kedekatan | Tabel spacing/radius, breakpoint, pola navigasi per aktor, tabel/daftar mobile, target sentuh dan fokus |
| 5. Standar Komponen shadcn/ui | Pemetaan komponen yang tersedia atau diusulkan; lampu harga, blok harga, form, kontrak, grafik/peta, toast, dialog, teks bantu dan seluruh keadaan penting |
| 6. Implementasi di `resources/css/app.css` | Spesifikasi token CSS, pemetaan Tailwind, varian dan migrasi nama token. Nyatakan sebagai kontrak implementasi yang diusulkan karena kode aplikasi belum tersedia |
| 7. Aturan Pantangan (UI Anti-Patterns) | Larangan khusus SAMBUNG: status hanya warna, estimasi seolah kepastian, contoh tanpa label, informasi penting hanya di hover, serta aksi tanpa izin |
| 8. Ringkasan Perubahan | Perubahan dari draf SAMBUNG, alasan, ID keputusan dan dampaknya; jangan mengarang versi resmi sebelumnya |

- [x] Pakai struktur contoh tanpa menyalin kebutuhan Jagains: tiket, SLA, kuorum, Auditor, kewajiban kamera, kode FR/NFR dan paletnya tidak otomatis berlaku bagi SAMBUNG.
- [x] Konfirmasikan pustaka/stack sebelum menyatakan shadcn, Base UI, Sonner, atau path komponen sebagai fakta implementasi. Jika belum dipilih, labeli spesifikasi sebagai usulan dan jelaskan pemetaan yang diperlukan.
- [x] Tentukan font/palet melalui keputusan visual; jangan mengganti identitas hanya untuk menyerupai contoh. Verifikasi sumber, lisensi dan cara pemuatan font saat diperlukan.
- [x] Tulis aturan presentasi harga dan AI: Rp/kg, desimal/persen, gabah vs ekuivalen beras, sumber/tanggal data, interval, alasan lampu, data ilustrasi, dan kondisi data belum cukup.
- [x] Tulis microcopy Indonesia untuk konfirmasi, galat field, kosong, gagal jaringan, serta data usang; hubungkan dengan FR/BR dan halaman yang memakainya.
- [x] Periksa contoh CSS/kode terhadap aturan dokumen sendiri, khususnya semantik warna, ukuran teks, token dan aksesibilitas. Hitung kontras dari nilai token yang benar-benar dipilih; laporkan hasil dan pasangan yang diuji, bukan klaim menyeluruh.
- [x] Bedakan verifikasi spesifikasi dari pengujian UI nyata. Uji sentuh, keyboard, zoom, pembaca layar, responsif dan performa menjadi checklist implementasi bila prototipe belum tersedia.

**Kriteria penerimaan:** delapan bagian format contoh tercakup; tidak ada sisa aturan domain Jagains; aturan UI tidak menambah perilaku di luar SRS; status/aksi cocok dengan IA; token dan contoh konsisten; hasil hitung kontras memiliki bukti atau ditandai belum diverifikasi.

### Tugas 5: Audit akhir dan terbitkan baseline paket

**Status 6 November 2026:** audit paket v0.4 selesai untuk review setelah penyesuaian enam mockup dan base netral Jagains. Penyajian akhir dan persetujuan pengguna atas UI/baseline paket masih menjadi gerbang terakhir; SRS/IA tetap v0.2 yang sudah disetujui.

**Baca:** seluruh keluaran fase 1–3 dan brief pengguna.
**Buat:** `README.md`.
**Ubah:** status, rujukan dan matriks ketertelusuran seluruh paket.

- [x] Cocokkan lagi semua janji proposal dengan kebutuhan diterima, ditunda, ditolak, atau pertanyaan terbuka beserta alasan/keputusannya.
- [x] Periksa konsistensi istilah, komoditas, satuan, horizon/interval, rumus, contoh angka, aktor, izin, prioritas, mesin status dan navigasi di tiga dokumen utama.
- [x] Lengkapi matriks hingga aturan UI dan AC; tandai kebutuhan backend/data yang tidak memiliki elemen UI dengan alasan eksplisit.
- [x] Periksa semua tautan lokal, ID rujukan dan Mermaid; diagram harus dapat dibaca tanpa gambar eksternal yang hilang.
- [x] Buat indeks yang menjelaskan status paket, versi ketiga dokumen, sumber resmi, daftar keputusan, pertanyaan terbuka dan aturan pembaruan berantai SRS → IA → UI.
- [x] Lakukan pembacaan ulang sebagai pelaksana baru: pastikan langkah, sumber dan aturan cukup jelas tanpa bergantung pada percakapan yang tidak dicatat.
- [ ] Sajikan tiga dokumen dan daftar keputusan tersisa untuk ditinjau pengguna. Catat persetujuan eksplisit, pihak dan tanggal sebelum menaikkan status menjadi baseline terkonfirmasi. Jika belum disetujui, serahkan sebagai draf untuk review.

**Kriteria selesai paket:** tiga dokumen utama tersedia, format UI sesuai pemetaan, semua aturan penting terlacak, tidak ada konflik kritis yang belum diputuskan, sumber asli tetap utuh, dan status persetujuan ditulis jujur.

## Urutan dan batas eksekusi

`Tugas 1 → Tugas 2 → Tugas 3 → Tugas 4 → Tugas 5`

Penyusunan awal bagian independen dapat berlanjut sambil menunggu jawaban, tetapi keputusan yang belum dijawab tidak boleh ditetapkan melalui asumsi diam-diam. Rencana ini tidak menjadwalkan pembangunan aplikasi, pelatihan model, deployment, perubahan proposal, atau pengiriman pesan kepada pihak lain. Tenggat relatif pada dokumen 29 Oktober perlu dihitung ulang saat eksekusi; jangan menyalin “12 hari lagi” sebagai kondisi saat ini.

## Pemeriksaan rencana sebelum diserahkan

- [x] Mencakup tiga fase yang diminta dan menyimpan rencana di `docs/plan/`.
- [x] Memakai lokasi aktual dokumen serta membedakan draf kebutuhan dari SRS final.
- [x] Menetapkan keluaran, ketergantungan, langkah dan kriteria penerimaan setiap tugas.
- [x] Memasukkan temuan awal sebagai agenda verifikasi, bukan keputusan final.
- [x] Menjelaskan keterbatasan `grill-me` dan dependensi `grilling`.
- [x] Menetapkan klarifikasi, ketertelusuran, adaptasi format UI, dan review akhir.
- [x] Tidak mengeksekusi fase dokumentasi atau mengubah sumber pada tahap pembuatan rencana ini.

