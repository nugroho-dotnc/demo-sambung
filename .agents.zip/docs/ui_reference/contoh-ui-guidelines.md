# Jagains UI Guidelines (v1.1)
**Standar Desain Antarmuka, Token Warna, Tipografi Rasio Emas, Tata Letak, & Komponen shadcn/ui Jagains**

Perubahan dari v1.0 dirangkum di bagian 8.

---

## 1. Pendahuluan & Filosofi Desain Antarmuka

Dokumen ini adalah panduan antarmuka resmi platform **Jagains**. Acuannya:
- `docs/source_of_truth/SRS_JAGAINS.md` (SRS v1.0)
- `docs/design_guidelines/01_UX_JOURNEY_AND_GUIDELINES.md` (alur pengguna multi-peran)
- `components.json` dan `resources/css/app.css` (shadcn base-vega, Tailwind CSS v4, OKLCH)

### Prinsip Utama: *Editorial Civic Craftsmanship (Anti-Slop)*
1. **Credible & Authoritative:** bersih, presisi, dapat dipercaya warga.
2. **Intentional Visual Hierarchy:** tanpa gradien dekoratif dan tanpa kartu di dalam kartu di dalam kartu. Data disajikan lewat tipografi, badge berstatus, dan whitespace.
3. **Strict Color Semantics:** warna terikat pada fungsi. Status SLA dan tahap tiket punya kode visual yang sama di semua layar, dan selalu disertai teks atau ikon.
4. **Zero Hardcoded Colors:** dilarang menulis warna arbitrer (`bg-[#123456]`, style inline) **dan dilarang memakai palet Tailwind mentah** (`bg-emerald-500`, `text-rose-700`, dan sejenisnya). Semua warna berasal dari token di `resources/css/app.css`.
5. **Neutral-first:** permukaan, teks, garis, dan sidebar tetap netral. Warna hanya muncul pada tiga tempat: **primary oranye** untuk aksi, **deret biru** untuk grafik, dan **token status** untuk SLA dan tahap tiket.

---

## 2. Sistem Warna & Semantic Tokens (OKLCH)

OKLCH menjaga kecerahan persepsi tetap konsisten antara mode terang dan gelap. Target kontras **WCAG 2.1 AA**: minimal 4,5:1 untuk teks biasa, 3:1 untuk teks besar, garis fokus, dan elemen grafis.

```mermaid
graph LR
    subgraph Color Architecture
        A[OKLCH Base Engine] --> B[Neutral Surface & Text]
        A --> C[Primary Orange]
        A --> D[Destructive Crimson]
        A --> E[Chart Blue Ramp]
        A --> F[Domain Status: SLA & Tahap Tiket]
    end
    subgraph Implementation
        B --> G[Tailwind CSS v4 Variables]
        C --> G
        D --> G
        E --> G
        F --> G
        G --> H[shadcn/ui Components]
    end
```

### 2.1 Palet Inti (Theme Tokens)

| Token | Light (`:root`) | Dark (`.dark`) | Peruntukan |
|:---|:---|:---|:---|
| `--background` | `oklch(1 0 0)` | `oklch(0.145 0 0)` | Latar halaman |
| `--foreground` | `oklch(0.145 0 0)` | `oklch(0.985 0 0)` | Teks utama, judul, ikon |
| `--card` / `--popover` | `oklch(1 0 0)` | `oklch(0.205 0 0)` | Permukaan kartu, popover |
| `--card-foreground` / `--popover-foreground` | `oklch(0.145 0 0)` | `oklch(0.985 0 0)` | Teks di kartu, popover |
| **`--primary`** | **`oklch(0.732 0.169 38.7)`** *(#FF7D52)* | **`oklch(0.732 0.169 38.7)`** | Tombol aksi utama, tab/menu aktif, indikator fokus pilihan |
| **`--primary-foreground`** | **`oklch(0.145 0 0)`** | **`oklch(0.145 0 0)`** | Teks di atas primary (kontras 7,8:1) |
| `--secondary` | `oklch(0.967 0.001 286.375)` | `oklch(0.274 0.006 286.033)` | Tombol sekunder, chip filter |
| `--secondary-foreground` | `oklch(0.21 0.006 285.885)` | `oklch(0.985 0 0)` | Teks di atas secondary |
| `--muted` | `oklch(0.97 0 0)` | `oklch(0.269 0 0)` | Baris tabel selang-seling, input nonaktif |
| `--muted-foreground` | `oklch(0.556 0 0)` | `oklch(0.708 0 0)` | Teks sekunder, helper text, metadata |
| `--accent` / `--accent-foreground` | `oklch(0.97 0 0)` / `oklch(0.205 0 0)` | `oklch(0.269 0 0)` / `oklch(0.985 0 0)` | Hover item menu dan baris. Netral, bukan oranye |
| `--destructive` | `oklch(0.577 0.245 27.325)` | `oklch(0.704 0.191 22.216)` | Tolak, sanggah, galat |
| `--border` | `oklch(0.922 0 0)` | `oklch(1 0 0 / 10%)` | Garis kartu dan pemisah |
| `--input` | `oklch(0.922 0 0)` | `oklch(1 0 0 / 15%)` | Border input |
| `--ring` | `oklch(0.708 0 0)` | `oklch(0.556 0 0)` | Cincin fokus |
| `--radius` | `0.625rem` (10 px) | sama | Basis radius |

**Sidebar**

| Token | Light | Dark |
|:---|:---|:---|
| `--sidebar` | `oklch(0.985 0 0)` | `oklch(0.205 0 0)` |
| `--sidebar-foreground` | `oklch(0.145 0 0)` | `oklch(0.985 0 0)` |
| `--sidebar-primary` | `oklch(0.732 0.169 38.7)` | `oklch(0.732 0.169 38.7)` |
| `--sidebar-primary-foreground` | `oklch(0.145 0 0)` | `oklch(0.145 0 0)` |
| `--sidebar-accent` / `-foreground` | `oklch(0.97 0 0)` / `oklch(0.205 0 0)` | `oklch(0.269 0 0)` / `oklch(0.985 0 0)` |
| `--sidebar-border` | `oklch(0.922 0 0)` | `oklch(1 0 0 / 10%)` |
| `--sidebar-ring` | `oklch(0.708 0 0)` | `oklch(0.556 0 0)` |

**Aturan memakai primary oranye**
- Primary **hanya sebagai isi (fill)** dengan `text-primary-foreground`. Oranye di atas putih hanya mencapai kontras 2,53:1, jadi **dilarang** dipakai sebagai warna teks, tautan, atau ikon kecil di atas latar terang (`text-primary` di latar terang tidak boleh).
- Tautan teks memakai `text-foreground underline underline-offset-4`.
- Satu tombol primary per area pandang. Aksi lain memakai `secondary` atau `outline`.
- Jangan pakai oranye untuk status. Oranye adalah warna merek dan aksi, sehingga bisa dibaca sebagai peringatan oleh pengguna.

### 2.2 Token Grafik (Chart)

Deret biru dari terang ke gelap, urutan `chart-1` terang sampai `chart-5` pekat, berdasarkan `#0052D4`. Nilainya berbeda antar mode agar tiap tanda grafik tetap berkontras minimal 3:1 terhadap latarnya.

| Token | Light | Dark |
|:---|:---|:---|
| `--chart-1` | `oklch(0.66 0.135 259.4)` | `oklch(0.8 0.1 259.5)` |
| `--chart-2` | `oklch(0.625 0.151 259.1)` | `oklch(0.725 0.13 259.5)` |
| `--chart-3` | `oklch(0.576 0.173 259.3)` | `oklch(0.65 0.15 259.5)` |
| `--chart-4` | `oklch(0.528 0.193 260.1)` | `oklch(0.6 0.17 259.5)` |
| `--chart-5` | `oklch(0.487 0.211 261)` *(#0052D4)* | `oklch(0.55 0.19 259.5)` |

Aturan grafik:
- Deret biru cocok untuk **satu ukuran dengan tingkat berbeda** (heatmap, bar bertingkat, urutan waktu).
- Untuk **beberapa kategori berbeda** (jenis kerusakan, instansi), ganti satu atau dua posisi dengan `--primary` (oranye) atau `--foreground` (netral) agar kategori bisa dibedakan sekilas.
- Selalu beri label langsung atau legenda bertulis. Jangan mengandalkan perbedaan biru saja.
- Pakai warna solid, bukan biru transparan, agar area yang bertumpuk tidak bocor.
- Di komponen `Chart` shadcn, rujuk dengan `var(--chart-1)` dan seterusnya melalui `ChartConfig`, bukan nilai langsung.

### 2.3 Token Status SLA & Tahap Tiket

Sesuai **BR-SLA-06** dan **BR-STS-02**. Semua berupa token, bukan kelas palet Tailwind. Warna adalah teks dan garis. Latar adalah warna yang sama pada opasitas 10% (mode gelap 15%).

| Kondisi | Token | Kelas pemakaian | Makna |
|:---|:---|:---|:---|
| SLA aman (sisa > 50%) | `--sla-safe` (hijau) | `border-sla-safe/30 bg-sla-safe/10 text-sla-safe dark:bg-sla-safe/15` | Dalam batas waktu |
| SLA waspada (sisa ≤ 50%) | `--sla-warn` (kuning-cokelat, hue 80–95) | `border-sla-warn/30 bg-sla-warn/10 text-sla-warn dark:bg-sla-warn/15` | Mendekati batas |
| SLA terlambat | `--sla-late` (merah) | `border-sla-late/30 bg-sla-late/10 text-sla-late dark:bg-sla-late/15` | Lewat batas, eskalasi ke Auditor |
| Verifikasi warga | `--stage-verify` (biru, selaras deret chart) | `border-stage-verify/30 bg-stage-verify/10 text-stage-verify dark:bg-stage-verify/15` | `MENUNGGU_VERIFIKASI`, bar kuorum |
| Audit & sengketa | `--stage-audit` (ungu) | `border-stage-audit/30 bg-stage-audit/10 text-stage-audit dark:bg-stage-audit/15` | `MENUNGGU_KEPUTUSAN_AUDITOR`, `DISENGKETAKAN` |
| Ditutup / selesai / ditolak | token netral | `border bg-transparent text-muted-foreground` | `TERTUTUP_WARGA`, `TERTUTUP_AUDITOR`, `DITOLAK` |

Nilai token ada di bagian 6. Kontras teks terhadap latar tint sudah dihitung: semua ≥ 4,5:1 (terendah 5,0:1).

Aturan:
- Setiap badge status memuat **teks dan ikon** (lucide). Jangan membedakan status hanya dengan warna.
- `--sla-warn` sengaja memakai hue kuning-cokelat agar tidak tertukar dengan oranye primary.
- Penanda peta: pin mengikuti token status di atas. **Pin yang sedang dipilih ditandai dengan cincin tebal `foreground`**, bukan dengan primary, supaya tidak terbaca sebagai status.
- Jangan menaruh teks `text-muted-foreground` kecil di atas `bg-muted` (kontras sekitar 4,3:1). Pakai `text-foreground` di sana, atau taruh di atas `bg-card`/`bg-background`.

---

## 3. Tipografi: Skala Rasio Emas ($\phi = 1{,}618$)

- **Display:** **Plus Jakarta Sans** untuk judul, angka metrik kunci, dan judul halaman.
- **Body:** **Inter Variable** untuk paragraf, label form, tabel, berita acara, metadata.
- **Teks isi minimum:** **16 px** (`text-body-base`). `text-body-sm` (14 px) hanya untuk metadata sekunder. `text-caption-xs` (12 px) hanya untuk badge, chip, tooltip.

### 3.1 Skala

Ukuran dasar 16 px dikalikan $\phi^n$. Nilai pada kolom ukuran dibulatkan ke piksel yang nyaman.

| Kelas | Ukuran | Dasar hitung | Line-height | Bobot | Tracking | Pemakaian |
|:---|:---:|:---:|:---:|:---:|:---:|:---|
| `text-display-hero` | 48–110 px | $\phi^4 \approx 110$ | 1,08 | 800 | -0,035em | Judul landing page publik |
| `text-display-xl` (H1) | 36–68 px | $\phi^3 \approx 68$ | 1,12 | 700 | -0,025em | Judul halaman detail tiket dan dashboard |
| `text-display-lg` (H2) | 28–42 px | $\phi^2 \approx 42$ | 1,18 | 700 | -0,02em | Judul seksi utama |
| `text-display-md` (H3) | 26 px | $\phi^1 \approx 26$ | 1,25 | 600 | -0,015em | Judul kartu, dialog, panel |
| `text-display-sm` (H4) | 21 px | $\phi^{0,5} \approx 20{,}4$ (dibulatkan ke 21) | 1,30 | 600 | -0,01em | Judul grup form, sub-seksi |
| `text-body-lg` | 18 px | $\phi^{0,25} \approx 18{,}1$ | 1,60 | 400 | normal | Paragraf pembuka |
| `text-body-base` | 16 px | dasar | 1,625 | 400 | normal | Teks isi, input, select |
| `text-body-medium` | 16 px | dasar | 1,625 | 500 | normal | Label field, tab aktif |
| `text-body-sm` | 14 px | $16 / \phi^{0,25} \approx 14{,}2$ | 1,50 | 400 | normal | Helper text, metadata |
| `text-caption-xs` | 12 px | $16 / \phi^{0,5} \approx 12{,}6$ (dibulatkan ke 12) | 1,40 | 500 | +0,01em | Badge, chip, tooltip |

Aturan pemakaian:
- Judul kartu shadcn (`CardTitle`) memakai `text-display-md` atau `text-display-sm`. Deskripsi (`CardDescription`) memakai `text-body-sm text-muted-foreground`.
- Teks tombol memakai `text-body-medium`.
- Angka dalam tabel dan metrik memakai `tabular-nums`.
- Satu kata atau frasa kunci pada judul halaman publik boleh diberi `text-foreground` dengan bobot lebih tebal. Jangan mewarnainya dengan `text-primary` di latar terang (lihat aturan kontras bagian 2.1).

---

## 4. Spacing, Tata Letak, & Hukum Kedekatan

Jarak mengikuti **Law of Proximity**: elemen yang berkaitan rapat, elemen yang terpisah fungsinya diberi jarak lebih besar.

```mermaid
graph TD
    subgraph Law of Proximity
        L1["Micro (4–8 px): label ke input, ikon ke teks, badge ke judul"]
        L2["Meso (12–16 px): antar field satu grup, tombol Simpan dan Batal"]
        L3["Macro (24–32 px): antar kartu, padding panel, grid gap"]
        L4["Global (48–64 px): antar seksi landing, header ke konten"]
        L1 --> L2 --> L3 --> L4
    end
```

### 4.1 Ukuran Spacing

| Tingkat | Ukuran | Kelas Tailwind | Pemakaian |
|:---|:---:|:---|:---|
| Micro | 4–8 px | `gap-1`, `gap-2`, `space-y-1.5` | Label ke input, ikon ke teks, judul kartu ke deskripsi |
| Meso | 12–16 px | `gap-3`, `gap-4` | Antar field satu grup, antar tombol |
| Component padding | 16–24 px | `p-4` (mobile), `p-6` (desktop) | Isi kartu, dialog, lembar berita acara |
| Macro | 24–32 px | `gap-6`, `gap-8`, `mb-8` | Antar komponen mandiri, peta ke daftar tiket |
| Global | 48–64 px | `py-12`, `py-16` | Antar seksi landing, margin kontainer utama |

### 4.2 Radius

`--radius` = 0,625 rem (10 px). Turunannya di `@theme inline`:

| Kelas | Nilai | Pemakaian |
|:---|:---:|:---|
| `rounded-sm` | 6 px | Chip kecil, tooltip |
| `rounded-md` | 8 px | Input, select, tombol kecil |
| `rounded-lg` | 10 px | Tombol, badge persegi |
| `rounded-xl` | 14 px | **Kartu**, popover, dialog |
| `rounded-2xl` | 18 px | Panel besar, bottom sheet |
| `rounded-full` | penuh | Badge status, avatar |

### 4.3 Tata Letak Responsif & PWA (NFR-OPS-03)

- **Mobile (360–639 px):** satu kolom. Target sentuh minimal **44 × 44 px**. Navigasi memakai `Sheet` dari samping. Ringkasan peta memakai `Sheet` dari bawah.
- **Tablet (640–1023 px):** grid 2 kolom untuk kartu metrik. Sidebar dapat diciutkan ke mode ikon.
- **Desktop (≥ 1024 px):** sidebar tetap (persistent layout Inertia). Antrean kerja: daftar tiket 40% di kiri, panel inspeksi 60% di kanan, tanpa pindah halaman.

---

## 5. Standar Komponen shadcn/ui

Jagains memakai komponen shadcn/ui (basis `@base-ui/react`). Dilarang membuat komponen dari nol bila shadcn menyediakan padanannya. Lokasi: `@/components/ui/*`.

```mermaid
flowchart TD
    A[Kejadian] --> B{Jenis}
    B -- Validasi field --> C[FieldError di bawah input]
    B -- Aksi permanen --> D[AlertDialog]
    B -- Aksi butuh isian --> E[Dialog dengan form]
    B -- Proses selesai / gagal jaringan --> F[Sonner toast]
    B -- Istilah tidak umum --> G[Teks bantu terlihat, Tooltip hanya tambahan]
    B -- Kondisi persisten halaman --> H[Alert di atas panel]
```

### 5.1 Notifikasi: Sonner (bukan Toast lama)

Komponen `Toast` lama sudah digantikan **Sonner** di shadcn. Pakai `@/components/ui/sonner` (`<Toaster />` di layout, `toast.success()`, `toast.error()`).

**Gunakan toast untuk:**
1. Proses di belakang layar selesai: *"Tautan verifikasi telah dikirim ke email Anda"* (FR-AKN-01), *"Tautan tiket disalin"* (FR-INT-02).
2. Aksi asinkron berhasil: *"Dukungan Anda untuk tiket JAG-2026-0001 dicatat"* (FR-INT-01), *"Kelurahan berhasil diganti"* (FR-AKN-04), *"Tiket dialihkan ke Dinas Perhubungan"* (FR-TIK-03).
3. Kegagalan jaringan atau server: *"Gagal menghubungi server. Mencoba lagi dalam 5 detik..."*

**Jangan gunakan toast untuk:**
- Validasi form. Pakai `FieldError` di bawah input.
- Konfirmasi aksi permanen. Pakai `AlertDialog`.
- Informasi yang harus tetap terlihat. Toast hilang sendiri, jadi pakai `Alert`.

### 5.2 Keterangan Pembantu: teks terlihat dulu, Tooltip sebagai tambahan

Aplikasi ini mobile-first dan **tooltip tidak muncul pada layar sentuh** (tidak ada hover). Karena itu:
- Penjelasan yang dibutuhkan untuk mengambil keputusan **harus tampil sebagai teks** (`text-body-sm text-muted-foreground`), bukan hanya di tooltip.
- Tooltip dipakai untuk detail tambahan di desktop. Di mobile, pasangkan ikon info dengan `Popover` yang terbuka saat disentuh.
- Bungkus aplikasi dengan `TooltipProvider`.
- Tulis dengan bahasa awam. Rumus dan istilah teknis cukup di halaman bantuan.

| Elemen | Teks yang terlihat | Tambahan (tooltip/popover) |
|:---|:---|:---|
| Bar kuorum | "Suara 1 dari 2 yang dibutuhkan" | K adalah jumlah suara warga kelurahan yang dibutuhkan agar tiket sah ditutup atau disengketakan. Rumus lengkap ada di halaman bantuan |
| Jalur A / B | Deskripsi di bawah label radio (lihat 5.3) | Tidak perlu |
| Jam kumulatif SLA | "Total hari kerja sejak pertama diteruskan" | Pengalihan tiket tidak menghentikan atau mengulang hitungan ini |
| Email | "Email Anda tidak disimpan" | Kami hanya menyimpan sidik acak (HMAC) dari email Anda, tidak alamat aslinya |
| Bounding box wilayah (admin) | "Batas koordinat kelurahan" | Dipakai untuk mendeteksi kelurahan otomatis dari lokasi |

### 5.3 Daftar Komponen

| Komponen | Berkas | Aturan Jagains |
|:---|:---|:---|
| `Button` | `button.tsx` | `default` = **primary oranye** untuk satu aksi utama. `secondary` untuk aksi pendukung dan kembali. `outline` untuk aksi sekunder pada latar kartu. `destructive` untuk tolak dan sanggah. `ghost` untuk aksi ikon. Tinggi bawaan shadcn (sekitar 32–36 px) kurang dari 44 px, jadi atur `size` default di `button.tsx` menjadi `h-11` pada mobile (`h-11 px-5 md:h-10`) |
| `Badge` | `badge.tsx` | Tambahkan varian `sla-safe`, `sla-warn`, `sla-late`, `stage-verify`, `stage-audit`, `closed` ke `cva` (kelas pada 2.3). Selalu sertakan ikon. Varian `default` (oranye) tidak dipakai untuk status |
| `Progress` | `progress.tsx` | Bar kuorum memakai warna `--stage-verify`. Bar sisa SLA memakai token SLA sesuai kondisi. Selalu tampilkan angka di dekatnya ("9 dari 14 hari") |
| `RadioGroup` | `radio-group.tsx` | Pilihan eksklusif: Jalur A atau B, sumber anggaran (APBD Kota, Provinsi, APBN), respons sengketa, putusan Auditor. Gunakan `Field` dengan deskripsi di bawah tiap pilihan |
| `Tabs` | `tabs.tsx` | Peta dan Daftar di beranda publik. Antarkecamatan dan Antarinstansi di dashboard |
| `Dialog` | `dialog.tsx` | Aksi yang **membutuhkan isian**: form sanggahan, usulan tolak beserta alasan, alasan membuka identitas pelapor |
| `AlertDialog` | `alert-dialog.tsx` | Konfirmasi aksi **permanen** tanpa isian, dan tombol konfirmasi bergaya `destructive` bila berisiko. Misalnya keputusan Auditor dan penutupan eskalasi |
| `Sheet` | `sheet.tsx` | Menu samping mobile dan ringkasan tiket saat pin peta disentuh (`side="bottom"`) |
| `Table` | `table.tsx` | Antrean Instansi dan Admin, audit log, komparasi dashboard. Kolom terurut, `truncate` pada teks panjang. Pada mobile, ubah baris menjadi daftar kartu |
| `Alert` | `alert.tsx` | Kondisi persisten di atas panel. Tambahkan varian `warning` (token `sla-warn`) dan `info` (token `stage-verify`). `destructive` bawaan untuk galat |
| `Card` | `card.tsx` | Permukaan kerja utama (`rounded-xl`, `border`, tanpa bayangan berat). Dilarang menumpuk kartu di dalam kartu |
| `Field`, `Input`, `Textarea`, `Select` | `field.tsx`, dll. | Semua form memakai `Field` (label, deskripsi, `FieldError`). Teks `text-body-base` agar iOS tidak memperbesar layar |
| `Sonner` | `sonner.tsx` | Lihat 5.1 |
| `Popover` | `popover.tsx` | Penjelasan tambahan yang bisa disentuh di mobile |
| `Skeleton` | `skeleton.tsx` | Keadaan memuat untuk peta, daftar tiket, dashboard |
| `Empty` | `empty.tsx` | Keadaan kosong: antrean kosong, "Data belum cukup" (kurang dari 20 tiket tertutup) |
| `Chart` | `chart.tsx` | Grafik dashboard dengan token chart (bagian 2.2) |
| `DropdownMenu`, `Breadcrumb`, `Pagination` | berkas masing-masing | Menu aksi baris, navigasi hierarki, halaman daftar panjang |

Catatan implementasi `@base-ui/react`:
- Komponen berbasis Base UI memakai prop **`render`** (bukan `asChild`) untuk mengganti elemen. Contoh: `<Button render={<Link href="..." />}>`.
- Setelah mengubah `button.tsx` atau `badge.tsx`, periksa semua pemakaian varian yang ada.

---

## 6. Implementasi di `resources/css/app.css`

Bagian ini hanya memuat **tambahan dan perubahan** terhadap `app.css`. Kelas tipografi (`font-display`, `text-display-*`, `text-body-*`, `text-caption-xs`) sudah ada di file dan tidak diulang di sini, supaya dokumen tidak menyimpan dua salinan yang bisa berbeda.

### 6.1 Perubahan token (`:root` dan `.dark`)

```css
:root {
    --primary: oklch(0.732 0.169 38.7);
    --primary-foreground: oklch(0.145 0 0);

    --chart-1: oklch(0.66 0.135 259.4);
    --chart-2: oklch(0.625 0.151 259.1);
    --chart-3: oklch(0.576 0.173 259.3);
    --chart-4: oklch(0.528 0.193 260.1);
    --chart-5: oklch(0.487 0.211 261);

    --sidebar-primary: oklch(0.732 0.169 38.7);
    --sidebar-primary-foreground: oklch(0.145 0 0);

    /* Status SLA dan tahap tiket (warna teks dan garis) */
    --sla-safe: oklch(0.45 0.12 150);
    --sla-warn: oklch(0.48 0.10 80);
    --sla-late: oklch(0.5 0.2 27);
    --stage-verify: oklch(0.487 0.211 261);
    --stage-audit: oklch(0.46 0.17 300);
}

.dark {
    --primary: oklch(0.732 0.169 38.7);
    --primary-foreground: oklch(0.145 0 0);

    --chart-1: oklch(0.8 0.1 259.5);
    --chart-2: oklch(0.725 0.13 259.5);
    --chart-3: oklch(0.65 0.15 259.5);
    --chart-4: oklch(0.6 0.17 259.5);
    --chart-5: oklch(0.55 0.19 259.5);

    --sidebar-primary: oklch(0.732 0.169 38.7);
    --sidebar-primary-foreground: oklch(0.145 0 0);

    --sla-safe: oklch(0.8 0.16 150);
    --sla-warn: oklch(0.86 0.15 95);
    --sla-late: oklch(0.704 0.191 22.216);
    --stage-verify: oklch(0.75 0.12 259.5);
    --stage-audit: oklch(0.76 0.13 300);
}
```

### 6.2 Daftarkan token baru ke Tailwind

Tambahkan di dalam blok `@theme inline` yang sudah ada:

```css
    --color-sla-safe: var(--sla-safe);
    --color-sla-warn: var(--sla-warn);
    --color-sla-late: var(--sla-late);
    --color-stage-verify: var(--stage-verify);
    --color-stage-audit: var(--stage-audit);
```

### 6.3 Varian badge (`badge.tsx`)

```ts
// tambahkan ke variants.variant pada cva
"sla-safe":
  "border-sla-safe/30 bg-sla-safe/10 text-sla-safe dark:bg-sla-safe/15",
"sla-warn":
  "border-sla-warn/30 bg-sla-warn/10 text-sla-warn dark:bg-sla-warn/15",
"sla-late":
  "border-sla-late/30 bg-sla-late/10 text-sla-late dark:bg-sla-late/15",
"stage-verify":
  "border-stage-verify/30 bg-stage-verify/10 text-stage-verify dark:bg-stage-verify/15",
"stage-audit":
  "border-stage-audit/30 bg-stage-audit/10 text-stage-audit dark:bg-stage-audit/15",
closed:
  "border-border bg-transparent text-muted-foreground",
```

### 6.4 Pembersihan `app.css` yang disarankan

1. **Definisi font ganda.** `--font-sans` didefinisikan dua kali (`'Instrument Sans'` di `@theme`, `'Inter Variable'` di `@theme inline`). Hapus blok `@theme` yang memuat Instrument Sans.
2. **`font-display` ganda.** `--font-display` ada di `@theme inline` dan `@utility font-display` ada di bawah. Pertahankan salah satu.
3. **Font heading lewat CDN.** `@import url('https://fonts.googleapis.com/...')` menunda render dan butuh internet. Untuk konsistensi dengan Inter, pakai `@import "@fontsource-variable/plus-jakarta-sans";` dan ganti nama keluarga di `--font-display` menjadi `'Plus Jakarta Sans Variable'`.
4. **Sudah dinilai dan tidak diubah:** `--ring` mode terang (`oklch(0.708 0 0)`) berkontras sekitar 2,6:1 terhadap putih, di bawah 3:1 yang diminta untuk indikator fokus. Token netral tetap sesuai permintaan, tetapi sebaiknya `--ring` diturunkan ke sekitar `oklch(0.6 0 0)` jika audit aksesibilitas dilakukan.

---

## 7. Aturan Pantangan (UI Anti-Patterns)

1. ❌ **Warna langsung atau palet Tailwind mentah di komponen.**
   - Dilarang: `bg-[#FF7D52]`, `bg-emerald-500/10`, `text-rose-700`.
   - Wajib: `bg-primary text-primary-foreground`, `bg-sla-safe/10 text-sla-safe`.
2. ❌ **`text-primary` untuk teks atau ikon kecil di latar terang.** Kontras 2,53:1. Pakai `text-foreground`.
3. ❌ **Komponen custom manual bila shadcn tersedia.** Dropdown dan modal berbasis `div` absolut dilarang. Pakai `DropdownMenu`, `Dialog`, `AlertDialog`.
4. ❌ **Teks paragraf utama di bawah 16 px.** `text-body-sm` hanya untuk metadata, `text-caption-xs` hanya untuk badge dan tooltip.
5. ❌ **Unggah dari galeri pada laporan warga.** Input laporan wajib memicu kamera langsung (`capture="environment"` atau API kamera peramban), sesuai **FR-LAP-02**.
6. ❌ **Aksi "Tutup Tiket" untuk akun Instansi.** Instansi paling jauh sampai "Ajukan Selesai" (FR-TIK-08). Penutupan hanya lewat kuorum warga atau putusan Auditor.
7. ❌ **Informasi penting yang hanya ada di tooltip.** Layar sentuh tidak punya hover.
8. ❌ **Status hanya dengan warna.** Wajib ada teks atau ikon.
9. ❌ **Toast untuk galat validasi atau konfirmasi permanen.** Lihat 5.1.
10. ❌ **Pin peta terpilih bergaya primary.** Gunakan cincin `foreground`, sebab oranye tidak boleh ambigu dengan status.

---

## 8. Ringkasan Perubahan dari v1.0

| Area | v1.0 | v1.1 | Alasan |
|:---|:---|:---|:---|
| Primary | Teal `oklch(0.511 0.096 186)` | Oranye `oklch(0.732 0.169 38.7)` (#FF7D52) | Permintaan: palet baru |
| `primary-foreground` | Hampir putih | `oklch(0.145 0 0)` | Putih di atas oranye hanya 2,53:1. Nilai baru 7,8:1 |
| Primary mode gelap | Teal lebih gelap | Sama dengan mode terang | Oranye terang sudah terbaca di latar gelap (7,1:1) |
| Sidebar primary | Teal | Oranye | Mengikuti primary |
| Chart | Tidak didefinisikan di dokumen | Deret biru dari #0052D4, dua set | Permintaan; set gelap dibedakan agar tanda grafik ≥ 3:1 |
| Token SLA/tahap | Kelas palet Tailwind mentah | Token semantik `--sla-*`, `--stage-*` | Memenuhi prinsip "zero hardcoded colors" yang sebelumnya dilanggar dokumen sendiri |
| Warna "waspada" | Amber (hue 75) | Kuning-cokelat (hue 80–95) | Menjauh dari oranye primary |
| Warna "verifikasi" | Indigo | Biru token chart | Selaras dengan deret chart |
| Warna "terlambat" | Rose 700 (≈ 3,99:1 pada tint) | Token `--sla-late` lebih gelap (≥ 5,0:1) | Memenuhi AA |
| Pin peta terpilih | Primary | Cincin foreground | Oranye ambigu dengan status |
| Toast | `@/components/ui/toast` | Sonner | Toast lama sudah digantikan Sonner di shadcn |
| Tooltip | Penjelasan kunci hanya di tooltip | Teks terlihat, tooltip tambahan, Popover untuk sentuh | Tidak ada hover di mobile |
| Dialog | Satu `Dialog` untuk semua | `Dialog` (butuh isian) dan `AlertDialog` (konfirmasi permanen) | Sesuai peran komponen shadcn |
| Komponen | 9 komponen | + Card, Field/Input/Select, Sonner, AlertDialog, Popover, Skeleton, Empty, Chart, dan lain-lain | Dipakai oleh alur di SRS |
| Tinggi tombol | `h-11` di mobile tanpa cara menerapkannya | Atur `size` default di `button.tsx` | Bawaan shadcn kurang dari 44 px |
| Radius | Tidak dibahas | Tabel radius | `--radius` sudah ada di tema |
| Skala tipografi | Rasio `Modular` tanpa angka | Dasar hitung ditulis, pembulatan dijelaskan | H4 21 px berasal dari 20,4 |
| Bagian 6 | Menyalin seluruh utilitas tipografi | Hanya tambahan dan perubahan | Mencegah dua salinan yang bisa berbeda |
| Temuan `app.css` | Tidak ada | Font ganda, `font-display` ganda, font lewat CDN, kontras `--ring` | Lihat 6.4 |
